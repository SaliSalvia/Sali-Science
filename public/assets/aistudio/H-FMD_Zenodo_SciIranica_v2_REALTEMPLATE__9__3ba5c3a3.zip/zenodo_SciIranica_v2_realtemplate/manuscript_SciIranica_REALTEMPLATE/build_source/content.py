# -*- coding: utf-8 -*-
# Content model for the Scientia Iranica manuscript body.
# Markup mini-language used in paragraph strings:
#   **bold**   *italic*   ^superscript^   ~subscript~
# Unicode used directly for Greek letters / math symbols.
# [[EQn]] marks where a standalone numbered equation image is inserted.
# [[FIGn]] / [[TABn]] are plain in-text citations rendered as "Figure n" / "Table n".

TITLE = ("A hybrid pulsed-induction and low-frequency electromagnetic architecture for deep "
         "subsurface metal detection and on-device material discrimination: a design and "
         "simulation study")

AUTHOR_NAME = "Salar Farzaneh"
AUTHOR_SUP = "a,*"
AFFIL_LINES = [
    "a. Independent Researcher, Electrical and Electronics Engineering, Karaj, Alborz, Iran",
]
CORR_LINE = "* Corresponding author: salar.farzaneh420@gmail.com (S. Farzaneh); ORCID: 0009-0008-7236-9241"

KEYWORDS = [
    "electromagnetic induction sensing",
    "pulsed induction",
    "eddy-current decay discrimination",
    "gradiometer coil",
    "on-device machine learning",
    "confirmation-gated learning",
]

ABSTRACT = (
"This paper presents H-FMD/HYBRID-X, a hybrid pulsed-induction (PI) and low-frequency "
"(sub-VLF) electromagnetic architecture for deep subsurface metal detection with on-device "
"two-tier material classification. Four elements are integrated into one signal chain: "
"(i) a ringing-elimination reset stage (RERS) with a closed-form design constraint "
"*t*~fall~·*V*~peak~ = π*LI*~pk~; (ii) a concentric anti-series bucking-gradiometer coil for "
"spatial soil-background rejection; (iii) a dual-domain (amplitude-decay and low-frequency "
"phase) target classifier; and (iv) a two-tier on-device learning system with a Confirmation "
"Anomaly Gate that bounds the damage mislabelled operator confirmations can do to the "
"adaptive tier. Every result is a closed-form calculation or a seeded Monte Carlo simulation, "
"independently reproduced from the archived script for this revision; none is a bench or "
"field measurement. Throughout, ρ = *V*~signal~/*V*~noise~ (an amplitude ratio) governs the "
"*r*^-6^ depth law, while SNR = ρ^2^ (a power ratio) is reserved for the Section 5 system-"
"margin budget; the discrimination-to-detection depth ratio is (ρ~th~/ρ~disc~)^1/6^ = "
"(3/33)^1/6^ ≈ 0.671. System-level budgets show the always-on 300 Hz operating point draws "
"≈33.6 W continuously and the full winding set weighs ≈8.2 kg in copper alone; an adaptive "
"30/300 Hz duty strategy and a reduced-turn receive winding are adopted, giving an estimated "
"8.6 kg ground-frame instrument with ≈10.4 h of mixed-mode runtime from a 100 Wh battery. No "
"claim in this paper should be read as asserting record, superior, or state-of-the-art depth "
"or discrimination performance; a pre-registered, bench-testable falsifiable target and a "
"three-phase validation roadmap are given instead."
)

# Each section: (number, title, [ (kind, payload), ... ])
# kind in {"p","p2","eq","fig","tab"} where p2 = subsection paragraph (same as p, kept flat)
SECTIONS = [
(1, "Introduction", None, [
("p", "Commercial metal detectors reliably locate near-surface targets, but detection depth "
 "and, separately, reliable material discrimination both fall steeply with range: received "
 "amplitude for a small conductive target scales approximately as *r*^-6^ for a fixed coil "
 "geometry (Section 3). Two device categories exist at the deep end of this market: physically "
 "grounded PI/low-frequency instruments constrained by the electromagnetic laws used here, and "
 "a long-documented category of unverified “long-range locator” products, most notably the "
 "Sandia National Laboratories evaluation of the DKL LifeGuard [1] and, in a security context, "
 "the ADE-651 fraud. Every depth or discrimination number in this paper is tied to an explicit "
 "model, a stated calibration assumption, and an evidence tag, precisely so the design cannot "
 "be mistaken for the second category."),
("p", "The contribution is a complete system design, not a single component, and is organised "
 "around six specific claims:"),
("p", "• a closed-form RERS design constraint that makes an internally consistent adopted "
 "design point explicit and shows why a previously circulated high-power variant is not "
 "achievable with realistic power semiconductors;"),
("p", "• a Monte Carlo tolerance analysis of the RERS clamp network reported at the "
 "percentile level, not as a single worst-case number;"),
("p", "• a concentric anti-series gradiometer with a first-order mechanical-tolerance-to-"
 "null-depth budget derived, not asserted;"),
("p", "• a two-tier on-device classifier extended with a Confirmation Anomaly Gate that "
 "bounds how much a stream of incorrect operator confirmations can corrupt the adaptive tier;"),
("p", "• explicit system-level power, mass, and thermal budgets (Section 4) that were "
 "entirely absent from the prior draft and materially change what a physical build requires; "
 "and"),
("p", "• a falsifiable, pre-registered depth-superiority target and a three-phase "
 "(design → benchtop → field) validation roadmap (Section 10), so the design's central "
 "hypotheses are checkable before any performance language stronger than “simulated” is used."),
("h2", "1.1. Related work"),
("p", "Individual subsystems considered here have substantial existing coverage: hybrid "
 "PI/induction-balance detectors and resonant PI variants are patented (e.g. US7710118B2, "
 "US8629677B2); concentric bucking-coil nulling for ground-mineralisation rejection is "
 "patented (US9989663B1, US6204667); and time-constant decay classification using generic "
 "machine-learning classifiers is claimed broadly (US9429674B2). This landscape means broad "
 "claims to any one of “dual-domain PI/VLF”, “bucking-gradiometer coil”, or “ML-based decay "
 "classification” in isolation are unlikely to constitute novel contribution; the defensible "
 "novelty pursued here is instead the specific combination, and in particular (i) the "
 "confirmation-gated experiential-learning schema coupled to a confidence weighting indexed "
 "by coherent-averaging count, (ii) the explicit architectural separation of detection-"
 "confidence from discrimination-confidence operating regimes, and (iii) the Confirmation "
 "Anomaly Gate mechanism of Section 8. On the physics side, the governing *r*^-6^ near-field "
 "depth law is the standard dipole-dipole model used throughout the peer-reviewed EMI/UXO-"
 "detection literature [2,3], not a proprietary relationship, which is the basis for treating "
 "this design as physically distinct from the unverified “long-range locator” category "
 "discussed above. The decay-based classification feature (Section 3.2) and the bounded "
 "on-device adaptation mechanism (Section 8) likewise sit within established, cited "
 "literature — canonical UXO decay-characterisation [9] and concept-drift/edge-ML adaptation "
 "[10,11] — rather than being presented as unprecedented."),
]),
(2, "System architecture", None, [
("p", "H-FMD/HYBRID-X is organised as nine functional blocks (Figure 1): blocks 100–200 "
 "generate and acquire the PI and low-frequency signal; block 300 fuses the amplitude-decay "
 "and phase features; block 400 performs dual-threshold classification; block 500 controls "
 "coherent pulse averaging and, in this revision, the adaptive pulse-repetition-frequency "
 "(PRF) mode (Section 4); block 600 is the confirmation-gated experiential learning loop, "
 "guarded by block 625, the Confirmation Anomaly Gate; block 700 is an operator-supervised "
 "calibration mode; block 800 is a conversational operator interface; block 900 monitors the "
 "bounded self-improvement trend. The PI and low-frequency channels use two physically "
 "separate coil assemblies: a 1.0 m × 1.0 m, 6-turn transmit coil driving the RERS-conditioned "
 "PI pulse, and a concentric anti-series bucking-gradiometer (1.2 m outer, 0.8 m bucking, "
 "0.4 m receive) carrying the sub-VLF channel and providing spatial soil rejection."),
("fig", 1, "Subsystem data-flow block diagram, blocks 100–900."),
]),
(3, "Governing physics and classification", None, [
("h2", "3.1. Depth attenuation and the ρ/SNR convention"),
("p", "For a small conductive target modelled as a magnetic-dipole re-radiator, received "
 "voltage falls with burial depth *r* approximately as *V*(*r*) ∝ *r*^-6^ for a coil diameter "
 "comparable to or larger than *r* (near-field dipole-dipole coupling) [calc]. All depth "
 "figures are built on this law, calibrated against a reference amplitude ratio assumed at "
 "*r* = 1.5 m — a value that must be replaced by a Test 5 bench measurement (Section 10)."),
("p", "**Convention, resolved in this revision.** The prior draft applied the *r*^-6^ exponent "
 "directly to a quantity it called “SNR” without stating whether that quantity was an "
 "amplitude or a power ratio — consequential, since if SNR is a power ratio and depth is "
 "governed by *V*(*r*) ∝ *r*^-6^, then *P*(*r*) ∝ *V*(*r*)^2^ ∝ *r*^-12^, not *r*^-6^, which would "
 "materially change every depth number in the paper. This revision resolves the ambiguity by "
 "using two distinct symbols rather than one overloaded one:"),
("eq", 1),
("eq", 2),
("p", "ρ is an amplitude ratio and is what the depth formula of Section 6 actually uses, "
 "with ρ~th~ ≈ 3 (detection) and ρ~disc~ ≈ 1/ε~A~ ≈ 33 for a target fractional amplitude "
 "noise ε~A~ = 3% (discrimination) — both stated in the original design as plain linear "
 "values, never as dB figures. SNR = ρ^2^, a power ratio, is reserved exclusively for the "
 "Section 5 system-margin budget, where detection-theory thresholds (Albersheim, Skolnik) are "
 "conventionally power-domain quantities; Section 5 shows a self-consistency check on this "
 "reading. No depth number in this paper changes as a result of this clarification: "
 "ρ~th~ = 3.0 and ρ~disc~ = 33.0 are the exact constants hard-coded in the archived simulation "
 "script's depth function, and re-executing that script against this revision reproduces the "
 "Section 6 depth figures to four significant figures, confirming the convention was already "
 "implicit in the code even though the prior text did not state it."),
("h2", "3.2. Eddy-current decay and phase discrimination"),
("p", "Eddy currents decay approximately exponentially after cutoff, *V*(*t*) = *V*(0)*e*^-t/τ^, "
 "with τ ≈ 3.6 ms (iron), ≈ 28.6 ms (bronze), ≈ 169–171 ms (gold/copper) [calc] — a "
 "single-exponential simplification of the more general dipole-polarizability decay model "
 "canonical to the UXO-discrimination literature [9]. The decay-"
 "ratio feature *R*~decay~ = *V*(G8)/*V*(G2) (gates at 100 μs, 8 ms) is combined with the sub-VLF "
 "phase shift Δφ into a two-dimensional feature space (Figure 2) that separates the four "
 "reference classes far better than either feature alone; iron and bronze classify at "
 "effectively 100% accuracy at both tested phase-noise levels, while gold and copper — "
 "separated by less than one noise standard deviation — remain the hard pair (Table 1) [sim]."),
("fig", 2, "Simulated dual-domain classification space, N = 400/class, 6.0° phase noise."),
("tab", 1, "Classification Monte Carlo, four-class nearest-centroid, N = 400/class, seed "
 "20260814 [sim].",
 ["Phase noise", "Gold acc.", "Copper acc.", "Overall error"],
 [["6.0° (primary)", "63.0%", "59.8%", "19.3%"],
  ["1.74° (matched)", "85.8%", "87.0%", "6.8%"]],
 None),
]),
(4, "Power electronics, coil design, and system budgets", None, [
("h2", "4.1. Ringing-elimination reset stage (RERS)"),
("p", "Cutting off an inductor carrying *I*~pk~ instantaneously would force the coil's stored "
 "energy through a parasitic *LC* ring; the RERS instead diverts that energy into a clamp "
 "capacitor *C*~clamp~, producing a fast but finite, controlled voltage ramp. Two quantities "
 "are fixed by the same *LC* transfer once *L*, *C*~clamp~, and *I*~pk~ are chosen:"),
("eq", 3),
("p", "which combine to the fixed design constraint *t*~fall~·*V*~peak~ = π*LI*~pk~, "
 "independent of *C*~clamp~ for a given coil and current. For the adopted 6-turn, 185.4 μH "
 "transmit coil (by Grover's formula [4]), 672 nF clamp, and *I*~pk~ = 30 A: *V*~clamp~ ≈ 498 V, "
 "*t*~fall~ ≈ 35.1 μs [calc]. This clamp is dissipative: the diverted energy is bled off "
 "resistively each cycle rather than returned to the DC bus (Section 4.3); an active/resonant "
 "energy-recovery variant was evaluated during design and found to require power-semiconductor "
 "voltage ratings well beyond what is realistically available at this current level, and was "
 "not adopted. A 1200 V/75 mΩ-class SiC MOSFET and a ±5%-tolerance clamp capacitor hold a "
 "7.3% margin to the 620 V gate-driver rating at the worst of 300,000 Monte Carlo draws "
 "(Table 2) [sim]. Current ramp-up to *I*~pk~ at a 14.8 V (4S-LiPo) bus takes "
 "*t*~ramp~ = *LI*~pk~/*V*~bus~ ≈ 0.38 ms [calc]."),
("tab", 2, "RERS clamp-voltage Monte Carlo, 300,000 draws [sim].",
 ["C tol.", "Nominal", "P95", "Worst-of-300k", "Margin"],
 [["±10%", "498 V", "549 V", "590 V", "4.9%"],
  ["±5% (adopted)", "498 V", "543 V", "575 V", "7.3%"]],
 None),
("h2", "4.2. Timing architecture"),
("p", "The 300 Hz PRF period (3.333 ms) is shorter than the 8 ms late-gate decay window; this "
 "is resolved as an intentional interleaved-pulse architecture (standard in commercial deep-PI "
 "instruments), with an analogue blanking window of ≈0.5–0.6 ms per pulse (≈15–19% duty) "
 "excluded from gate integration in firmware [design]."),
("h2", "4.3. System power, mass, and thermal budgets (new)"),
("p", "No system-level budget existed in the prior draft. The RERS clamp is dissipative (an "
 "active energy-recovery variant was evaluated and not adopted): *P*~RERS~ = "
 "½*LI*~pk~^2^×PRF ≈ 25.0 W at 300 Hz, giving ≈33.6 W system-wide — incompatible with "
 "handheld battery operation [calc]. An adaptive 30 Hz Scan / 300 Hz Deep-Search PRF strategy "
 "is adopted (Table 3). Separately, copper mass at the original 200-turn receive winding is "
 "≈3.2 kg alone (≈8.2 kg system-wide); since receive-coil SNR ∝ √*N*~rx~, cutting to 80 turns "
 "costs a (80/200)^1/12^ ≈ 0.93 depth factor (≈7%) for a ≈2.4 kg saving, giving an ≈8.6 kg "
 "total in a ground-frame (not handheld) form factor [calc] (open item: the accompanying "
 "wire-gauge thinning is not yet reflected in this depth-factor estimate). MOSFET junction "
 "temperature reaches ≈79°C worst case (96°C margin to the 175°C rating) [calc]."),
("tab", 3, "System feasibility budget (new in this revision) [calc].",
 ["", "Scan (30 Hz)", "Deep-Search (300 Hz)"],
 [["System power", "≈7.0 W", "≈33.6 W"],
  ["MOSFET TJ (margin)", "≈48°C (127°)", "≈79°C (96°)"],
  ["Runtime, 100 Wh", "14.3 h", "3.0 h"]],
 "Mixed 90/10 duty: ≈9.6 W, ≈10.4 h — System mass: ≈8.6 kg"),
]),
(5, "Noise and SNR budget", None, [
("p", "Input-referred AFE noise is budgeted bottom-up through an explicit receive-coil "
 "→ 1:10 step-up transformer → LSK489-class JFET headstage (*G*~1~ = 10) → AD8429-class "
 "instrumentation amplifier (*G*~2~ = 100) → ADS127L11 ADC chain, with each downstream "
 "device's own datasheet noise density referred back to the coil terminal by its cumulative "
 "gain:"),
("eq", 4),
("p", "giving traceable referred terms of 0.14 (coil Johnson), 0.02 (transformer insertion "
 "loss), 0.180 nV/√Hz (JFET, 1.8/10), 0.010 (InAmp, 1.0/100), and 0.0004 (ADC, 4.0/10,000): "
 "RSS total ≈0.229 nV/√Hz [calc]. This is above the prior draft's 0.191 figure, whose "
 "referral path (which transformer ratio, which inter-stage gains) was not stated and was "
 "accordingly unverifiable; it remains below the ≈0.75 nV/√Hz documented real-world benchmark "
 "for a comparable discrete JFET-array front end. The 1:10 transformer ratio and the two stage "
 "gains are a self-consistent design point chosen so each downstream noise source is small "
 "once referred to the input; they are not the result of a bench-optimised source/load "
 "noise-matching calculation, and should be re-derived once the as-built coil's source "
 "impedance is measured."),
("p", "The end-to-end system SNR budget is broken into six named, non-overlapping "
 "contributions so that coherent-integration gain — the single largest term — is counted "
 "exactly once: baseline soil-limited detection −10 dB, RERS de-ringing efficiency +8 dB, "
 "gradiometer spatial soil rejection +13 dB, AFE noise floor +20 dB, coherent integration "
 "+36 dB at N = 4000, and a coupling/soil-viscosity discount −15 dB, for a net +52 dB (power "
 "convention) against a detection threshold on the order of 12–13 dB (Albersheim's closed-form "
 "approximation for *P*~d~ = 0.9, *P*~fa~ = 10^-6^ single-look non-coherent detection gives "
 "≈13 dB [5,6]) [calc]. As a self-consistency check on the power-domain reading of SNR = ρ^2^: "
 "10log~10~(4000) = 36.02 dB matches the stated +36 dB coherent-integration term exactly, "
 "confirming that term was already computed power-domain even though the prior draft never "
 "stated the convention. The exact detector-model assumptions behind the ≈12–13 dB detection "
 "threshold specifically (detector type, coherent vs. non-coherent combining, whether a design "
 "margin is already netted in) are not shown in the text that produced it and remain the "
 "highest-priority open item pending the author's underlying derivation — resolving the "
 "labelling ambiguity above does not by itself validate this one component of the budget."),
]),
(6, "Discrimination-reliable depth", None, [
("p", "Detection depth (ρ~th~ ≈ 3) and discrimination-reliable depth (ρ~disc~ ≈ 33, "
 "back-calculated from ε~A~ = 3%) follow *r* = 1.5(ρ~ref~√*N*/ρ~threshold~)^1/6^ [m] at a "
 "300 Hz PRF, evaluated in Figure 3 for N ∈ {1,…,423} and ρ@1.5m = 50 (illustrative; the full "
 "six-value ρ-grid is Supplementary Table S1). At every (N,ρ) cell, discrimination depth is a "
 "fixed (ρ~th~/ρ~disc~)^1/6^ = (3/33)^1/6^ ≈ 0.671 of detection depth [calc] — re-derived and "
 "confirmed unchanged in this revision from the archived script's hard-coded ρ~th~ = 3.0, "
 "ρ~disc~ = 33.0. A ±2-exponent sensitivity band around the adopted 6th-power law shifts "
 "detection depth by +12 to +53% (p = 4) or −6 to −19% (p = 8) relative to p = 6 across the "
 "same ρ grid (Supplementary Table S2) — smaller than the spread across the SNR-calibration "
 "axis itself, reinforcing that measuring ρ@1.5m (Test 5, Section 10) is the higher-priority "
 "open measurement of the two."),
("h2", "6.1. First-principles cross-check of the assumed ρ@1.5m range"),
("p", "The ρ@1.5m range of 5–200 used above was, in every prior revision, an unjustified "
 "assumption. This revision adds an independent, closed-form physics estimate — not a bench "
 "measurement, but a genuine calculation rather than a guess — using only quantities already "
 "fixed elsewhere in this paper: the transmit coil (Section 4.1: 6-turn, 1.0 m × 1.0 m, "
 "*I*~pk~ = 30 A), the target eddy-current decay constants τ already stated in Section 3, and "
 "the AFE noise floor of Section 5. Modelling the target as a conducting sphere, its "
 "dominant-mode decay constant is τ~1~ = μ~0~σ*a*^2^/π^2^ [7], which inverted against this "
 "paper's own stated τ values implies a reference-target radius of *a* ≈ 15.0 cm for copper "
 "and bronze (independently, from two different conductivities, to within rounding) and "
 "≈18.0 cm for gold. Using the same near-field dipole coupling the *r*^-6^ law itself is built "
 "on, the transmit field at *r* = 1.5 m is *B*~1~ ≈ 10.7 μT, giving an instantaneous induced "
 "target moment *m*(0^+^) = 2π*a*^3^*B*~1~/μ~0~ [7] and a monostatic received EMF at the "
 "G2 = 100 μs gate of 370–2200 nV depending on material (bronze responds most strongly, since "
 "lower conductivity gives a shorter τ and hence a larger *dm*/*dt* at fixed radius). Against "
 "the 0.229 nV/√Hz noise floor, this gives ρ@1.5m ≈ 16–52 for copper, ≈ 28–90 for gold, and "
 "≈ 97–307 for bronze at plausible effective bandwidths (1–10 kHz) [calc]; copper — the most "
 "conservative material — lands inside the previously unjustified assumed range (5–200), while "
 "gold and bronze land within or above it. Taken together this is a meaningful, if partial, "
 "validation of the assumed range's lower portion rather than a tight confirmation of its full "
 "span, since no single material's estimate spans the whole 5–200 range on its own. This "
 "estimate is sensitive to target size (a 1 cm "
 "reference target rather than 15 cm gives ρ ≈ 3–5 at 1 kHz, still order-consistent) and does "
 "not model soil coupling, coil resistive loss, or non-spherical target geometry; it narrows, "
 "but explicitly does not close, this section's single largest open item — Test 5 remains "
 "required before any depth number here is more than a calculation."),
("fig", 3, "Detection vs. discrimination-reliable depth vs. coherently averaged pulses N "
 "(illustrative ρ@1.5m = 50; full grid in Supplementary Table S1)."),
]),
(7, "Gradiometer coil geometry", None, [
("p", "The anti-series bucking-gradiometer (Figure 4) rejects spatially broad soil background "
 "— which couples similarly into the bucking and receive windings and largely cancels — "
 "while a small, localised target couples asymmetrically and survives the subtraction; this is "
 "complementary to, not a substitute for, the time-gating of Section 3 and the coherent "
 "averaging of Section 4. Following the first-order treatment standard in bucking-coil "
 "geophysical instrument design, where mutual coupling scales approximately with the cube of "
 "coil diameter, *M* ∝ *D*^3^ [8], a fractional diameter perturbation ε = Δ*D*/*D* produces a "
 "fractional coupling perturbation"),
("eq", 5),
("p", "to first order (the logarithmic derivative of the cube-law scaling; the factor of 3 is "
 "exactly the exponent of the *D*^3^ law and not an independently fitted constant) [calc]. A "
 "40 dB Test 7 target implies ≈0.33% (≈4 mm) mechanical tolerance on the 1.2 m coil (Table 4) "
 "— a specification for the coil former and winding jig, not merely the electrical design. "
 "This budget assumes static, temperature-stable geometry; thermal expansion and field-"
 "handling flex are separate, currently unbudgeted risk factors. The bucking winding's "
 "45-turn count follows from a distinct, first-order area-balance condition for a spatially "
 "*uniform* background field (as opposed to the compact-source coupling law above), "
 "*N*~buck~ = *N*~outer~(*A*~outer~/*A*~buck~) = 20×(0.6/0.4)^2^ = 45 [calc]; the two models "
 "should not be assumed interchangeable without bench confirmation."),
("fig", 4, "Anti-series concentric bucking-gradiometer (top view, coplanar)."),
("tab", 4, "Gradiometer null depth vs. mechanical tolerance [calc].",
 ["ε", "0.2%", "0.5%", "2.0%"],
 [["Null depth", "44.4 dB", "36.5 dB", "24.4 dB"]],
 None),
]),
(8, "On-device learning and the Confirmation Anomaly Gate", None, [
("p", "A fixed Tier-1 model blends with a locally adaptive Tier-2 model as a confidence-"
 "weighted average,"),
("eq", 6),
("p", "with α rising from 0 toward an asymptote as confirmed field samples accumulate at a "
 "site, so the adaptive tier's influence is bounded and saturating rather than allowed to "
 "drift arbitrarily far from the factory-trained baseline on the strength of a handful of "
 "confirmations — a conservative, bounded-adaptation stance consistent with the "
 "concept-drift literature's caution against unconstrained online updates [10], implemented "
 "within the memory and compute envelope of a microcontroller-class on-device learner as "
 "surveyed in the TinyML literature [11]. Block 625, the Confirmation Anomaly Gate, guards "
 "the update path itself: it "
 "withholds a Tier-2 update whose feature vector lies farther than a configurable threshold "
 "from the confirmed class's current Tier-2 reference position, so a single implausible "
 "operator confirmation — from error, a confusing dig site, or deliberate mislabelling — "
 "cannot disproportionately steer the adaptive model. This is a proxy defensive mechanism "
 "evaluated on the same simulated feature space as Section 3, not a claim about any deployed "
 "production classifier."),
("p", "Across a 25-trial/condition Monte Carlo with uniformly random label contamination, the "
 "gate recovers the large majority (≈85–100%) of contamination-induced error at every tested "
 "level (Table 5) and holds performance near the clean-data baseline at low contamination "
 "[sim]. Trial-to-trial standard deviation is genuinely large (up to ±5.1 points at 10% "
 "contamination without the gate) and a robustness check at 200 trials/condition (independent "
 "seeds) reproduced the same qualitative recovery but did not shrink this spread materially, "
 "indicating the variability is intrinsic to the 400-sample online-learning process itself "
 "rather than an artefact of too few trials; the “≈85–100% recovered” figure should "
 "accordingly be read as a directional finding robust in sign and rough magnitude, not a "
 "precise point estimate. The gate does not eliminate the effect of bad confirmations — a "
 "system that refused to learn from any confirmation would be immune to contamination but "
 "also to correction — and its figures are a directional finding motivating the mechanism, "
 "not a deployment-ready accuracy guarantee."),
("tab", 5, "Confirmation Anomaly Gate benefit, mean±std, 25 trials/condition [sim].",
 ["Contam.", "No gate", "With gate", "Benefit"],
 [["10%", "22.9±5.1%", "18.3±2.9%", "−4.6 pts"],
  ["20%", "25.1±3.1%", "18.6±3.2%", "−6.5 pts"]],
 None),
]),
(9, "Consolidated results, discussion, and limitations", None, [
("p", "Table 6 summarises every quantitative claim in this paper with its evidence class, so "
 "a reviewer does not have to reconstruct this from prose scattered across Sections 3–8. "
 "Reading it as a whole: the design's internal physics and tolerance analyses are, to the "
 "extent closed-form circuit and field theory allow, self-consistent and independently "
 "re-derivable — every calc/sim row was recomputed from the equations and the archived script "
 "during preparation of this revision. What the table cannot show is whether the physical "
 "world behaves as these models predict; that gap is exactly what the Section 10 roadmap "
 "exists to close."),
("tab", 6, "Consolidated claims and evidence classes.",
 ["Claim", "Class", "Headline"],
 [["RERS clamp voltage", "sim", "575 V, worst-of-300k"],
  ["Detection/discrim. depth", "calc", "1.1–5.0 m"],
  ["Gradiometer null depth", "calc", "40 dB → 0.33% tol."],
  ["System SNR budget", "calc", "net +52 dB"],
  ["Classification error", "sim", "19.3% / 6.8%"],
  ["Anomaly-gate benefit @20%", "sim", "25.1→18.6%"],
  ["System power (deep/scan)", "calc", "33.6 W / 7.0 W"],
  ["System mass", "calc", "≈8.6 kg"],
  ["Bench/field validation", "TBD-bench", "none performed"]],
 None),
("p", "The single overriding limitation is that no physical prototype exists; every number in "
 "this paper is a calculation or a simulation, and this is not diluted by any item below it. "
 "Beyond that:"),
("p", "1. **SNR@1.5 m is assumed, not measured** (Section 6), though now cross-checked against "
 "an independent first-principles calculation (Section 6.1) that lands inside the previously "
 "unjustified assumed range; it remains the dominant source of uncertainty in every depth "
 "figure reported, and Test 5 (Section 10) remains the highest-priority bench item overall, "
 "ahead of every other open item on this list."),
("p", "2. **The revised gradiometer winding's wire-gauge thinning is not yet reflected in its "
 "own depth-penalty estimate** (Section 4.3): the ≈7% figure assumes fixed wire gauge and "
 "only accounts for the receive-turn reduction; thinner wire on all three windings raises "
 "*R*~coil~ (and Johnson noise) beyond what pure turn-count scaling predicts, so this figure "
 "should be re-derived with gauge-dependent resistance before being treated as validated."),
("p", "3. **The AFE transformer ratio is a self-consistent, not a bench-optimised, design "
 "point** (Section 5); a real source/load noise-matching calculation against the as-built "
 "coil's impedance may indicate a different ratio."),
("p", "4. **The exact detector-model derivation behind the detection-theory margin is "
 "unstated** (Section 5): Albersheim's approximation gives the right order of magnitude but "
 "not an exact match, and no fabricated derivation is substituted for the missing one."),
("p", "5. **The classification Monte Carlo uses assumed Gaussian noise around assumed "
 "centroids for four reference materials**, not any real target-signature dataset; real "
 "target and soil variability (shape, orientation, corrosion, adjacent-object clutter) is not "
 "modelled, and the reported error rates should not be read as predictions of real-world "
 "classification accuracy."),
("p", "6. **Cost, weight ergonomics beyond the Section 4.3 mass estimate, RF/EMC compliance, "
 "environmental sealing, and battery cycle life are out of scope** for this paper and are not "
 "modelled at all."),
("p", "None of these items is disqualifying for a design-and-simulation study; each is "
 "disqualifying for a ready-to-build claim, which this paper does not make, and each maps "
 "directly onto a numbered Phase-2 bench test in Section 10."),
]),
(10, "Three-phase validation roadmap", None, [
("p", "This manuscript constitutes Phase 1 of a three-phase development programme for the "
 "H-FMD/HYBRID-X instrument, structured as follows. **Phase 1** (the present contribution): "
 "the precise system architecture and engineering design, comprising "
 "closed-form and simulated design only, gated on six criteria all satisfied in this revision "
 "(amplitude/power convention declared; AFE referral path stated; PRF/decay-window conflict "
 "resolved; bucking turns specified; power/mass/thermal budgets defined; every [calc]/[sim] "
 "figure reproducible from the archived script). **Phase 2** (future work): laboratory "
 "validation, beginning with reduced-scale benchtop prototyping — including a coil wound at "
 "approximately one-tenth of the full design scale — to confirm basic functional behaviour "
 "ahead of the quantitative bench programme, which proceeds "
 "in priority order: Test 5 (SNR@1.5 m, anchors every depth table), an AFE noise "
 "bench test, RERS transient verification, gradiometer null-depth measurement, and a "
 "power/thermal bench test. **Phase 3** (future work): full-scale instrument construction and "
 "integration, a comparative "
 "field trial, EMC pre-compliance, and mechanical/environmental qualification. A "
 "pre-registered falsifiable target states that, at the measured SNR@1.5 m and N = 120, "
 "discrimination-reliable depth should fall within the 1.63–2.69 m band (Figure 3, "
 "Supplementary Table S1) for a plausible ρ@1.5m range of 5–100; a result materially below "
 "this band, or a measured attenuation exponent outside 5–7, would falsify the depth model as "
 "specified."),
]),
(11, "Conclusion", None, [
("p", "H-FMD/HYBRID-X is presented as a complete, internally consistent design-and-simulation "
 "study: a closed-form power stage, a gradiometer coil with a derived (not asserted) "
 "tolerance budget, a dual-domain classifier with explicit uncertainty reporting, a bounded "
 "on-device learning system with a Confirmation Anomaly Gate, and system-level power, mass, "
 "and thermal budgets that surface a real feasibility constraint (continuous 300 Hz operation "
 "draws ≈34 W and the original winding set weighs over 8 kg) together with an engineered "
 "mitigation. No number here should be read as a record, superior, or state-of-the-art claim; "
 "the three-phase roadmap of Section 10 states explicitly what would need to be measured "
 "before such language could be used responsibly."),
]),
]

NOMENCLATURE = [
("ρ", "amplitude signal-to-noise ratio, V_signal/V_noise (dimensionless)"),
("SNR", "power signal-to-noise ratio, ρ² (dimensionless)"),
("ρ~th~, ρ~disc~", "detection and discrimination amplitude-ratio thresholds (3.0, 33.0)"),
("τ", "eddy-current dominant-mode decay time constant [s]"),
("L", "transmit-coil inductance [H]"),
("C~clamp~", "RERS clamp capacitance [F]"),
("I~pk~", "peak transmit current [A]"),
("V~clamp~, t~fall~", "RERS clamp voltage [V] and current fall time [s]"),
("N", "number of coherently averaged pulses (dimensionless)"),
("ε", "fractional mechanical diameter tolerance (dimensionless)"),
("α", "Tier-2 confidence weight in the on-device learning blend (dimensionless)"),
]

# (author_block, journal/book, vol_issue, pages, year, doi_or_None)
REFERENCES = [
dict(n=1, text="Murray, D.W., Spencer, F.W., and Spencer, D.D. “Double-blind evaluation of "
     "the DKL LifeGuard Model 2”, Sandia National Laboratories Report SAND98-0977 (1998).",
     doi=None),
dict(n=2, text="Das, Y. “Effects of soil electromagnetic properties on metal detectors”, "
     "IEEE Trans. Geosci. Remote Sens., 44(6), pp. 1444-1453 (2006).",
     doi="10.1109/TGRS.2006.870401"),
dict(n=3, text="Dabas, M., Jolivet, A., and Tabbagh, A. “Magnetic susceptibility and "
     "viscosity of soils in a weak time-varying field”, Geophys. J. Int., 108(1), "
     "pp. 101-109 (1992).",
     doi="10.1111/j.1365-246X.1992.tb00841.x"),
dict(n=4, text="Grover, F.W. Inductance Calculations: Working Formulas and Tables, Dover, "
     "New York, NY, USA (1946).",
     doi=None),
dict(n=5, text="Albersheim, W.S. “A closed-form approximation to Robertson's detection "
     "characteristics”, Proc. IEEE, 69(7), p. 839 (1981).",
     doi="10.1109/PROC.1981.12082"),
dict(n=6, text="Richards, M.A. Fundamentals of Radar Signal Processing, McGraw-Hill, "
     "New York, NY, USA (2005).",
     doi=None),
dict(n=7, text="Rushton, L.M., Pyragius, T., Meraki, A., et al. “Unshielded portable "
     "optically pumped magnetometer for the remote detection of conductive objects using "
     "eddy current measurements”, Rev. Sci. Instrum., 93(12), p. 125103 (2022).",
     doi="10.1063/5.0102402"),
dict(n=8, text="Earle, J.L. “Auto Nulling of Induction Balance Metal Detector Coils”, "
     "US Patent 9,989,663 B1 (2018).",
     doi=None),
dict(n=9, text="Pasion, L.R. and Oldenburg, D.W. “A discrimination algorithm for UXO using "
     "time domain electromagnetics”, J. Environ. Eng. Geophys., 6(2), pp. 91-102 (2001).",
     doi="10.4133/JEEG6.2.91"),
dict(n=10, text="Gama, J., Žliobaitė, I., Bifet, A., Pechenizkiy, M., and Bouchachia, A. "
     "“A survey on concept drift adaptation”, ACM Comput. Surv., 46(4), Article 44 (2014).",
     doi="10.1145/2523813"),
dict(n=11, text="Sanchez-Iborra, R. and Skarmeta, A.F. “TinyML-enabled frugal smart "
     "objects: challenges and opportunities”, IEEE Circuits Syst. Mag., 20(3), pp. 4-18 "
     "(2020).",
     doi="10.1109/MCAS.2020.3005467"),
]

GENAI_NOTE = (
"Large-language-model assistance (Claude, Anthropic) was used throughout preparation of this "
"manuscript for: (i) independently re-executing the archived simulation script to verify "
"every published numerical figure against source code rather than transcription; "
"(ii) identifying and correcting a metric-definition error, a component-value transcription "
"error, and an internally inconsistent depth-ratio revision proposed during drafting; "
"(iii) drafting prose, tables, and the formatting of this revision from author-supplied "
"technical content and decisions; and (iv) cross-checking named commercial components "
"against manufacturer datasheets. All quantitative claims were independently verified by "
"code execution or closed-form re-derivation rather than accepted from either the author's "
"draft or the AI's output alone; the author takes full responsibility for the content. No "
"generative AI tool is credited as an author."
)

ACKNOWLEDGMENTS = (
"This work received no external funding and no institutional or corporate support of any "
"kind; it was conducted independently by the author."
)

CREDIT = (
"Salar Farzaneh: Conceptualization, Methodology, Software, Validation, Formal analysis, "
"Investigation, Data Curation, Writing – Original Draft, Writing – Review & Editing, "
"Visualization."
)

BIOGRAPHY = (
"Salar Farzaneh is an independent researcher working across electrical and electronics "
"engineering and AI security, based in Karaj, Alborz, Iran, with a technical background "
"reinforced by numerous international professional certifications. His work sits at the "
"boundary of electromagnetic sensor hardware design and AI safety research, spanning "
"electromagnetic induction sensing, embedded signal-processing systems, and defenses "
"against large-language-model jailbreak attacks. This manuscript is Phase 1 of a "
"self-directed, three-phase development "
"programme for the H-FMD/HYBRID-X subsurface metal-detection architecture, covering design "
"and simulation (this paper), benchtop validation, and field integration. A provisional "
"patent application covering aspects of the system described here is in preparation."
)

FIGURES = [
(1, "fig_block_diagram.png", "Subsystem data-flow block diagram, blocks 100–900."),
(2, "fig_classification_space.png", "Simulated dual-domain classification space, "
    "N = 400/class, 6.0° phase noise."),
(3, "fig_depth_vs_N.png", "Detection vs. discrimination-reliable depth vs. coherently "
    "averaged pulses N (illustrative ρ@1.5m = 50; full grid in Supplementary Table S1)."),
(4, "fig_gradiometer_geometry.png", "Anti-series concentric bucking-gradiometer "
    "(top view, coplanar)."),
]
