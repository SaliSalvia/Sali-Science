# -*- coding: utf-8 -*-
import re, html, sys
sys.path.insert(0, "/home/claude/work/docx_build")
import content as C

def esc(s):
    return html.escape(s, quote=False).replace("'", "&apos;")

TOKEN_RE = re.compile(r'(\*\*[^*]+\*\*|\*[^*]+\*|\^[^^]+\^|~[^~]+~)')

def parse_markup(text):
    """Return list of (text, bold, italic, vert) where vert in (None,'superscript','subscript')."""
    parts = TOKEN_RE.split(text)
    out = []
    for part in parts:
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            out.append((part[2:-2], True, False, None))
        elif part.startswith('*') and part.endswith('*'):
            out.append((part[1:-1], False, True, None))
        elif part.startswith('^') and part.endswith('^'):
            out.append((part[1:-1], False, False, 'superscript'))
        elif part.startswith('~') and part.endswith('~'):
            out.append((part[1:-1], False, False, 'subscript'))
        else:
            out.append((part, False, False, None))
    return out

def run_xml(text, bold=False, italic=False, vert=None, force_no_bold=False):
    rpr = []
    if bold:
        rpr.append('<w:b/><w:bCs/>')
    elif force_no_bold:
        rpr.append('<w:b w:val="0"/><w:bCs w:val="0"/>')
    if italic:
        rpr.append('<w:i/><w:iCs/>')
    if vert:
        rpr.append('<w:vertAlign w:val="%s"/>' % vert)
    rprxml = ('<w:rPr>%s</w:rPr>' % ''.join(rpr)) if rpr else ''
    return '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r>' % (rprxml, esc(text))

def runs_from_markup(text, force_no_bold=False, force_italic=False):
    return ''.join(
        run_xml(t, b, (i or force_italic), v, force_no_bold=force_no_bold)
        for (t, b, i, v) in parse_markup(text)
    )

def para(style, text, extra_ppr=''):
    ppr = '<w:pStyle w:val="%s"/>%s' % (style, extra_ppr) if style else extra_ppr
    pprxml = ('<w:pPr>%s</w:pPr>' % ppr) if ppr else ''
    return '<w:p>%s%s</w:p>' % (pprxml, runs_from_markup(text))

def heading1(text):
    return para('Heading1', text)

def heading1_blank():
    return '<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr></w:p>'

def heading2(text):
    return para('Heading2', text)

def normal(text):
    return para('Normaltext', text, extra_ppr='<w:ind w:firstLine="0"/>')

def plain_empty():
    return '<w:p/>'

# ---------------------------------------------------------------- equations
EQ_DXA = {1: 3600, 2: 3200, 3: 5200, 4: 4600, 5: 5300, 6: 5700}  # display widths (EMU-ish via DXA scale below)
EQ_PIXSIZE = {
    1: (1015, 136), 2: (899, 135), 3: (1639, 186),
    4: (1438, 186), 5: (1661, 233), 6: (1782, 183),
}

def emu(px, dpi=600):
    return int(px / dpi * 914400)

EQ_SCALE_IN_PER_PX = 2.6 / 1015.0  # fixed so font size is visually consistent across equations

def equation_block(rels, n):
    rid = rels.add_image("media/eq%d.png" % n)
    w_px, h_px = EQ_PIXSIZE[n]
    cx, cy = int(w_px * EQ_SCALE_IN_PER_PX * 914400), int(h_px * EQ_SCALE_IN_PER_PX * 914400)
    drawing = (
        '<w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
        '<wp:extent cx="%d" cy="%d"/>'
        '<wp:docPr id="%d" name="Equation %d"/>'
        '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:nvPicPr><pic:cNvPr id="0" name="eq%d.png"/><pic:cNvPicPr/></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
        '</a:graphicData></a:graphic></wp:inline></w:drawing>'
    ) % (cx, cy, 100 + n, n, n, rid, cx, cy)
    tab = '<w:tabs><w:tab w:val="right" w:pos="9638"/></w:tabs>'
    ppr = '<w:pPr>%s</w:pPr>' % tab
    body = '<w:r>%s</w:r><w:r><w:tab/><w:t>(%d)</w:t></w:r>' % (drawing, n)
    return '<w:p>%s%s</w:p>' % (ppr, body)

# ---------------------------------------------------------------- figures/tables (end matter)
def figure_block(rels, num, filename, caption, px_size):
    rid = rels.add_image("media/%s" % filename)
    w_px, h_px = px_size
    target_w_in = 3.1  # ~8cm, within the 5-8cm single-column guidance
    scale = target_w_in * 914400 / w_px
    cx, cy = int(w_px * scale), int(h_px * scale)
    drawing = (
        '<w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
        '<wp:extent cx="%d" cy="%d"/>'
        '<wp:docPr id="%d" name="%s"/>'
        '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:nvPicPr><pic:cNvPr id="0" name="%s"/><pic:cNvPicPr/></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
        '</a:graphicData></a:graphic></wp:inline></w:drawing>'
    ) % (cx, cy, 200 + num, filename, filename, rid, cx, cy)
    fig_p = '<w:p><w:pPr><w:pStyle w:val="Figure"/></w:pPr><w:r>%s</w:r></w:p>' % drawing
    cap_p = ('<w:p><w:pPr><w:pStyle w:val="FigureCaption"/></w:pPr>'
             '<w:r><w:rPr><w:b/><w:bCs/></w:rPr><w:t>Figure %d.</w:t></w:r>'
             '<w:r><w:t xml:space="preserve"> %s</w:t></w:r></w:p>') % (num, esc(caption))
    return fig_p + cap_p

def table_block(num, caption, header, rows, footnote):
    cap_p = ('<w:p><w:pPr><w:pStyle w:val="TableCaption"/></w:pPr>'
              '<w:r><w:rPr><w:b/><w:bCs/></w:rPr><w:t>Table %d.</w:t></w:r>'
              '<w:r><w:t xml:space="preserve"> %s</w:t></w:r></w:p>') % (num, esc(caption))
    ncols = len(header)
    colw = max(1200, 9638 // ncols)
    grid = ''.join('<w:gridCol w:w="%d"/>' % colw for _ in range(ncols))

    def cell(text, bold, top=None, bottom=None):
        borders = ''
        if top is not None:
            borders += '<w:top w:val="%s" w:sz="4" w:space="0" w:color="auto"/>' % top
        if bottom is not None:
            borders += '<w:bottom w:val="%s" w:sz="4" w:space="0" w:color="auto"/>' % bottom
        tcborders = ('<w:tcBorders>%s</w:tcBorders>' % borders) if borders else ''
        bxml = '' if bold else '<w:b w:val="0"/><w:bCs w:val="0"/>'
        rpr = ('<w:rPr>%s</w:rPr>' % bxml) if bxml else ''
        return ('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s</w:tcPr>'
                '<w:p><w:pPr><w:pStyle w:val="TableofAuthorities"/></w:pPr>%s'
                '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r></w:p></w:tc>'
                ) % (colw, tcborders, '', rpr, esc(text))

    rows_xml = []
    # header row: bold, top+bottom single rule
    hcells = ''.join(cell(h, True, top='single', bottom='single') for h in header)
    rows_xml.append('<w:tr><w:trPr><w:jc w:val="center"/></w:trPr>%s</w:tr>' % hcells)
    for i, r in enumerate(rows):
        is_last = (i == len(rows) - 1)
        bcells = ''.join(cell(c, False, bottom=('single' if is_last else None)) for c in r)
        rows_xml.append('<w:tr><w:trPr><w:jc w:val="center"/></w:trPr>%s</w:tr>' % bcells)

    tbl = ('<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/>'
           '<w:jc w:val="center"/>'
           '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" '
           'w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'
           '<w:tblGrid>%s</w:tblGrid>%s</w:tbl>') % (grid, ''.join(rows_xml))

    out = cap_p + tbl
    if footnote:
        fn = ('<w:p><w:pPr><w:pStyle w:val="TableofAuthorities"/><w:jc w:val="left"/>'
              '<w:rPr><w:b w:val="0"/><w:bCs w:val="0"/><w:i/><w:iCs/></w:rPr></w:pPr>'
              '<w:r><w:rPr><w:b w:val="0"/><w:bCs w:val="0"/><w:i/><w:iCs/></w:rPr>'
              '<w:t xml:space="preserve">%s</w:t></w:r></w:p>') % esc(footnote)
        out += fn
    out += plain_empty()
    return out

class Rels:
    """Tracks media relationships to append to document.xml.rels."""
    def __init__(self, start_id=1000):
        self.items = []  # (rid, target)
        self._next = start_id
        self._cache = {}

    def add_image(self, target):
        if target in self._cache:
            return self._cache[target]
        rid = "rIdImg%d" % self._next
        self._next += 1
        self.items.append((rid, target))
        self._cache[target] = rid
        return rid

# ---------------------------------------------------------------- assemble body

def build_front_matter():
    out = []
    out.append('<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr>%s</w:p>' % runs_from_markup(C.TITLE))
    # Subtitle: author with superscript
    sub_runs = run_xml(C.AUTHOR_NAME + " ") + run_xml(C.AUTHOR_SUP, vert='superscript')
    out.append('<w:p><w:pPr><w:pStyle w:val="Subtitle"/></w:pPr>%s</w:p>' % sub_runs)
    for line in C.AFFIL_LINES:
        out.append(para('Affiliation', line))
    out.append(para('Date', C.CORR_LINE))
    out.append(plain_empty())
    return ''.join(out)

def build_keyword_abstract_table():
    kw_cells = ''.join(
        '<w:p><w:pPr><w:pStyle w:val="Keyword"/></w:pPr><w:r><w:t xml:space="preserve">%s%s</w:t></w:r></w:p>'
        % (esc(k), ';' if i < len(C.KEYWORDS) - 1 else '.')
        for i, k in enumerate(C.KEYWORDS)
    )
    abstract_runs = runs_from_markup(C.ABSTRACT)
    tbl = (
        '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="10205" w:type="dxa"/>'
        '<w:jc w:val="center"/><w:tblBorders>'
        '<w:top w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto"/></w:tblBorders>'
        '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" '
        'w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'
        '<w:tblGrid><w:gridCol w:w="2268"/><w:gridCol w:w="283"/><w:gridCol w:w="7654"/></w:tblGrid>'
        '<w:tr><w:trPr><w:trHeight w:val="340"/><w:jc w:val="center"/></w:trPr>'
        '<w:tc><w:tcPr><w:tcW w:w="2268" w:type="dxa"/><w:tcBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tcBorders>'
        '<w:shd w:val="clear" w:color="auto" w:fill="FFFFFF"/><w:vAlign w:val="center"/></w:tcPr>'
        '<w:p><w:pPr><w:jc w:val="left"/><w:rPr><w:b/><w:bCs/></w:rPr></w:pPr>'
        '<w:r><w:rPr><w:b/><w:bCs/></w:rPr><w:t>Keywords</w:t></w:r></w:p></w:tc>'
        '<w:tc><w:tcPr><w:tcW w:w="283" w:type="dxa"/><w:tcBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tcBorders>'
        '<w:vAlign w:val="center"/></w:tcPr><w:p/></w:tc>'
        '<w:tc><w:tcPr><w:tcW w:w="7654" w:type="dxa"/><w:tcBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tcBorders>'
        '<w:vAlign w:val="center"/></w:tcPr>'
        '<w:p><w:pPr><w:jc w:val="left"/><w:rPr><w:b/><w:bCs/></w:rPr></w:pPr>'
        '<w:r><w:rPr><w:b/><w:bCs/></w:rPr><w:t>Abstract</w:t></w:r></w:p></w:tc></w:tr>'
        '<w:tr><w:trPr><w:jc w:val="center"/></w:trPr>'
        '<w:tc><w:tcPr><w:tcW w:w="2268" w:type="dxa"/><w:tcBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tcBorders>'
        '<w:shd w:val="clear" w:color="auto" w:fill="D9D9D9"/></w:tcPr>' + kw_cells +
        '</w:tc>'
        '<w:tc><w:tcPr><w:tcW w:w="283" w:type="dxa"/></w:tcPr><w:p/></w:tc>'
        '<w:tc><w:tcPr><w:tcW w:w="7654" w:type="dxa"/><w:tcBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tcBorders></w:tcPr>'
        '<w:p><w:pPr><w:pStyle w:val="Abstract"/></w:pPr>' + abstract_runs + '</w:p>'
        '</w:tc></w:tr></w:tbl>'
    )
    return tbl + plain_empty()

def build_sections(rels):
    out = []
    for (num, title, _unused, items) in C.SECTIONS:
        out.append(heading1("%d. %s" % (num, title)))
        for item in items:
            kind = item[0]
            if kind == "p":
                out.append(normal(item[1]))
            elif kind == "h2":
                out.append(heading2(item[1]))
            elif kind == "eq":
                out.append(equation_block(rels, item[1]))
            elif kind in ("fig", "tab"):
                continue  # moved to end matter
        out.append(plain_empty())
    return ''.join(out)

def build_note_genai():
    out = []
    out.append(heading1("Note:"))
    out.append(heading2("* GenAI"))
    out.append(normal(C.GENAI_NOTE))
    out.append(plain_empty())
    return ''.join(out)

def build_nomenclature():
    out = [heading1("Nomenclature")]
    rows_xml = []
    for sym, meaning in C.NOMENCLATURE:
        sruns = runs_from_markup(sym, force_no_bold=True, force_italic=True)
        scell = ('<w:tc><w:tcPr><w:tcW w:w="1600" w:type="dxa"/></w:tcPr>'
                 '<w:p><w:pPr><w:pStyle w:val="TableofAuthorities"/>'
                 '<w:rPr><w:b w:val="0"/><w:bCs w:val="0"/></w:rPr></w:pPr>' + sruns + '</w:p></w:tc>')
        mcell = ('<w:tc><w:tcPr><w:tcW w:w="7000" w:type="dxa"/></w:tcPr>'
                 '<w:p><w:pPr><w:pStyle w:val="TableofAuthorities"/><w:jc w:val="left"/>'
                 '<w:rPr><w:b w:val="0"/><w:bCs w:val="0"/></w:rPr></w:pPr>'
                 '<w:r><w:rPr><w:b w:val="0"/><w:bCs w:val="0"/></w:rPr>'
                 '<w:t xml:space="preserve">%s</w:t></w:r></w:p></w:tc>') % esc(meaning)
        rows_xml.append('<w:tr><w:trPr><w:jc w:val="center"/></w:trPr>%s%s</w:tr>' % (scell, mcell))
    tbl = ('<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/>'
           '<w:jc w:val="center"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" '
           'w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'
           '<w:tblGrid><w:gridCol w:w="1600"/><w:gridCol w:w="7000"/></w:tblGrid>%s</w:tbl>'
           ) % ''.join(rows_xml)
    out.append(tbl)
    out.append(plain_empty())
    return ''.join(out)

def build_ack_credit_funding_coi():
    out = []
    out.append(heading1("Acknowledgments"))
    out.append(normal(C.ACKNOWLEDGMENTS))
    out.append(plain_empty())
    out.append(heading1("Authors’ Credit"))
    out.append(normal(C.CREDIT))
    out.append(plain_empty())

    def checkbox(checked, text):
        box = '☒' if checked else '☐'
        return ('<w:p><w:pPr><w:ind w:left="510" w:right="170" w:hanging="340"/></w:pPr>'
                '<w:r><w:rPr><w:rFonts w:ascii="Segoe UI Symbol" w:hAnsi="Segoe UI Symbol" '
                'w:cs="Segoe UI Symbol"/></w:rPr><w:t>%s</w:t></w:r>'
                '<w:r><w:t xml:space="preserve"> %s</w:t></w:r></w:p>') % (box, esc(text))

    out.append(heading1("Funding"))
    out.append(normal("This work received no external funding."))
    out.append(checkbox(True,
        "The authors declare that they have no known competing financial interests or "
        "personal relationships that could have appeared to influence the work reported in "
        "this paper."))
    out.append(checkbox(False,
        "The author is an Editorial Board Member/Editor-in-Chief/Associate Editor/Guest "
        "Editor for Scientia Iranica and was not involved in the editorial review or the "
        "decision to publish this article."))
    out.append(checkbox(False,
        "The authors declare the following financial interests/personal relationships which "
        "may be considered as potential competing interests."))
    out.append(plain_empty())

    out.append(heading1("Conflicts of interest"))
    out.append(checkbox(False,
        "The authors declare that they have no known competing financial interests or "
        "personal relationships that could have appeared to influence the work reported in "
        "this paper."))
    out.append(checkbox(True,
        "The authors declare the following financial interests/personal relationships which "
        "may be considered as potential competing interests."))
    out.append(normal(
        "A provisional patent application covering aspects of the system described in this "
        "manuscript is in preparation by the author (see the companion Patent Blueprint "
        "document, archived separately and not submitted as part of this manuscript)."))
    out.append(plain_empty())
    return ''.join(out)

def build_references():
    out = [heading1("References")]
    for r in C.REFERENCES:
        body = r["text"]
        if r["doi"]:
            doi_url = "https://doi.org/%s" % r["doi"]
            runs = ('<w:r><w:t xml:space="preserve">%d. %s </w:t></w:r>'
                    '<w:hyperlink r:id="%s"><w:r><w:rPr><w:rStyle w:val="Hyperlink"/></w:rPr>'
                    '<w:t xml:space="preserve">%s</w:t></w:r></w:hyperlink>'
                    ) % (r["n"], esc(body), "rIdDoi%d" % r["n"], esc(doi_url))
        else:
            runs = '<w:r><w:t xml:space="preserve">%d. %s</w:t></w:r>' % (r["n"], esc(body))
        out.append('<w:p><w:pPr><w:pStyle w:val="References"/></w:pPr>%s</w:p>' % runs)
    out.append(heading1_blank())
    return ''.join(out)

def build_biographies():
    out = [heading1("Biographies")]
    out.append(normal(C.BIOGRAPHY))
    out.append(plain_empty())
    return ''.join(out)

def collect_tables():
    tabs = []
    for (num, title, _u, items) in C.SECTIONS:
        for item in items:
            if item[0] == "tab":
                tabs.append(item[1:])  # (num, caption, header, rows, footnote)
    return tabs

def build_captions_list():
    out = [heading1("List of Figure and Table Captions")]
    for (num, fname, caption) in C.FIGURES:
        out.append(normal("**Figure %d.** %s" % (num, caption)))
    for (num, caption, header, rows, footnote) in collect_tables():
        out.append(normal("**Table %d.** %s" % (num, caption)))
    out.append(plain_empty())
    return ''.join(out)

def build_figures_and_tables(rels):
    out = [heading1_blank()]
    out.append(heading2("Figures"))
    for (num, fname, caption) in C.FIGURES:
        out.append(figure_block(rels, num, fname, caption, EQ_PIXSIZE_FIG[num]))
    out.append(heading2("Tables"))
    for (num, caption, header, rows, footnote) in collect_tables():
        out.append(table_block(num, caption, header, rows, footnote))
    return ''.join(out)

# figure pixel sizes at 300dpi render (filled in main() after checking files)
EQ_PIXSIZE_FIG = {}

def main():
    from PIL import Image
    import os
    media_dir = "/home/claude/work/docx_build/media"
    for (num, fname, caption) in C.FIGURES:
        with Image.open(os.path.join(media_dir, fname)) as im:
            EQ_PIXSIZE_FIG[num] = im.size

    rels = Rels()
    body = []
    body.append(build_front_matter())
    body.append(build_keyword_abstract_table())
    body.append(build_sections(rels))
    body.append(build_note_genai())
    body.append(build_nomenclature())
    body.append(build_ack_credit_funding_coi())
    body.append(build_references())
    body.append(build_biographies())
    body.append(build_captions_list())
    body.append(build_figures_and_tables(rels))

    sectpr = (
        '<w:sectPr><w:headerReference w:type="even" r:id="rId9"/>'
        '<w:headerReference w:type="default" r:id="rId10"/>'
        '<w:footerReference w:type="even" r:id="rId11"/>'
        '<w:footerReference w:type="default" r:id="rId12"/>'
        '<w:headerReference w:type="first" r:id="rId13"/>'
        '<w:footerReference w:type="first" r:id="rId14"/>'
        '<w:type w:val="continuous"/><w:pgSz w:w="11907" w:h="16839" w:code="9"/>'
        '<w:pgMar w:top="567" w:right="851" w:bottom="567" w:left="851" '
        'w:header="709" w:footer="709" w:gutter="0"/>'
        '<w:pgNumType w:start="1"/><w:cols w:space="567"/><w:titlePg/>'
        '<w:docGrid w:linePitch="360"/></w:sectPr>'
    )

    doc_body = ''.join(body) + sectpr

    with open("/home/claude/work/sci_template_inspect/unpacked/word/document.xml", encoding="utf-8") as f:
        template_doc = f.read()

    head_match = re.match(r'^(.*<w:body>)', template_doc, re.S)
    header_xml = head_match.group(1)
    new_doc = header_xml + doc_body + '</w:body></w:document>'

    out_dir = "/home/claude/work/docx_build/unpacked"
    import shutil
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    shutil.copytree("/home/claude/work/sci_template_inspect/unpacked", out_dir)

    with open(os.path.join(out_dir, "word", "document.xml"), "w", encoding="utf-8") as f:
        f.write(new_doc)

    # --- update relationships: add image + hyperlink rels, copy media files
    rels_path = os.path.join(out_dir, "word", "_rels", "document.xml.rels")
    with open(rels_path, encoding="utf-8") as f:
        rels_xml = f.read()

    os.makedirs(os.path.join(out_dir, "word", "media"), exist_ok=True)
    extra_rel_entries = []
    for (rid, target) in rels.items:
        fname = target.split("/")[-1]
        shutil.copy(os.path.join(media_dir, fname), os.path.join(out_dir, "word", "media", fname))
        ext = fname.rsplit(".", 1)[-1]
        extra_rel_entries.append(
            '<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/%s"/>'
            % (rid, fname))

    for r in C.REFERENCES:
        if r["doi"]:
            extra_rel_entries.append(
                '<Relationship Id="rIdDoi%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://doi.org/%s" TargetMode="External"/>'
                % (r["n"], r["doi"]))

    rels_xml = rels_xml.replace("</Relationships>", ''.join(extra_rel_entries) + "</Relationships>")
    with open(rels_path, "w", encoding="utf-8") as f:
        f.write(rels_xml)

    # ensure Hyperlink character style exists (template may already define it); add if missing
    styles_path = os.path.join(out_dir, "word", "styles.xml")
    with open(styles_path, encoding="utf-8") as f:
        styles_xml = f.read()
    if 'w:styleId="Hyperlink"' not in styles_xml:
        hyperlink_style = ('<w:style w:type="character" w:styleId="Hyperlink">'
                            '<w:name w:val="Hyperlink"/><w:basedOn w:val="DefaultParagraphFont"/>'
                            '<w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>')
        styles_xml = styles_xml.replace("</w:styles>", hyperlink_style + "</w:styles>")
        with open(styles_path, "w", encoding="utf-8") as f:
            f.write(styles_xml)

    # content types: ensure png default extension present
    ct_path = os.path.join(out_dir, "[Content_Types].xml")
    with open(ct_path, encoding="utf-8") as f:
        ct_xml = f.read()
    if 'Extension="png"' not in ct_xml:
        ct_xml = ct_xml.replace("</Types>",
            '<Default Extension="png" ContentType="image/png"/></Types>')
        with open(ct_path, "w", encoding="utf-8") as f:
            f.write(ct_xml)

    # --- replace stale template document properties (core.xml / app.xml) with the
    # manuscript's own: the template ships with its own author/date/word-count
    # metadata baked in (e.g. dc:creator "pc", a January-2026 template-creation date,
    # and word/page counts from the empty template), which would otherwise leak into
    # File > Properties on every build.
    import datetime
    now_iso = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:00Z")
    core_path = os.path.join(out_dir, "docProps", "core.xml")
    core_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        '<dc:title>%s</dc:title><dc:creator>%s</dc:creator><cp:lastModifiedBy>%s</cp:lastModifiedBy>'
        '<cp:revision>1</cp:revision>'
        '<dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created>'
        '<dcterms:modified xsi:type="dcterms:W3CDTF">%s</dcterms:modified>'
        '</cp:coreProperties>'
    ) % (esc(C.TITLE), esc(C.AUTHOR_NAME), esc(C.AUTHOR_NAME), now_iso, now_iso)
    with open(core_path, "w", encoding="utf-8") as f:
        f.write(core_xml)

    app_path = os.path.join(out_dir, "docProps", "app.xml")
    with open(app_path, encoding="utf-8") as f:
        app_xml = f.read()
    app_xml = re.sub(r"<vt:lpstr></vt:lpstr>", "<vt:lpstr>%s</vt:lpstr>" % esc(C.TITLE), app_xml)
    # rough but non-stale word/character counts, computed from the actual body text
    # (Word recalculates these on open regardless; this just avoids shipping the
    # empty template's own stale 5-page/2345-word stats in the meantime)
    plain_text = re.sub(r"<[^>]+>", " ", doc_body)
    plain_text = html.unescape(plain_text)
    word_count = len(plain_text.split())
    chars_nospace = len(plain_text.replace(" ", "").replace("\n", ""))
    chars_space = len(plain_text)
    app_xml = re.sub(r"<Words>\d+</Words>", "<Words>%d</Words>" % word_count, app_xml)
    app_xml = re.sub(r"<Characters>\d+</Characters>", "<Characters>%d</Characters>" % chars_nospace, app_xml)
    app_xml = re.sub(r"<CharactersWithSpaces>\d+</CharactersWithSpaces>",
                      "<CharactersWithSpaces>%d</CharactersWithSpaces>" % chars_space, app_xml)
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(app_xml)

    print("Body length:", len(doc_body))
    print("Images embedded:", len(rels.items))

if __name__ == "__main__":
    main()
