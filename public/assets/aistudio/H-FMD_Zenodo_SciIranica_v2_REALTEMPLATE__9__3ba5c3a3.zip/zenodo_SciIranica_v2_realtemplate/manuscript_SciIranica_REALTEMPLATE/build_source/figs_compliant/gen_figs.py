import sys, importlib.util
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle
from matplotlib.lines import Line2D

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
    "font.size": 10,
    "text.color": "black",
    "axes.labelcolor": "black",
    "axes.edgecolor": "black",
    "xtick.color": "black",
    "ytick.color": "black",
    "axes.titlesize": 10,
    "axes.titleweight": "normal",
    "pdf.fonttype": 42,
    "svg.fonttype": "none",
})

_spec = importlib.util.spec_from_file_location(
    "hfmd_sim",
    "/home/claude/work/H-FMD_FINAL-v1_3/05_core_simulation/H-FMD_final_reproducible_simulation_FINAL_v1.py")
hfmd_sim = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(hfmd_sim)
CENTROIDS = hfmd_sim.CENTROIDS
CLASSES = hfmd_sim.CLASSES
DEFAULT_SEED = hfmd_sim.DEFAULT_SEED
RHO_DET = hfmd_sim.RHO_DET
RHO_DISC = hfmd_sim.RHO_DISC
depth_at_threshold = hfmd_sim.depth_at_threshold

# accent colors for NON-text graphical elements only (fills/lines/markers) --
# lettering itself is forced black everywhere below, per journal figure rules.
NAVY   = "#1B3A6B"
BLUE   = "#5B82B5"
GREEN  = "#5E8C6A"
GOLD   = "#C9971F"
RED    = "#A6443A"
SLATE  = "#4A5568"
BLACK  = "#000000"

# ---------------------------------------------------------------- Figure 1
fig, ax = plt.subplots(figsize=(5.4, 5.6))
ax.set_xlim(0, 10); ax.set_ylim(0, 11); ax.axis("off")

boxes = {
    "100": (1, 9.2, "100\nSignal\nGeneration", NAVY),
    "200": (4, 9.2, "200\nAcquisition\n(dual-ADC)", BLUE),
    "300": (7, 9.2, "300\nFusion /\nFeature Extract.", GREEN),
    "400": (7, 6.6, "400\nClassification\n(dual-threshold)", GREEN),
    "500": (7, 4.0, "500\nCoherent-\nAveraging Ctrl", GREEN),
    "600": (4, 4.0, "600\nExperiential\nLearning Loop", GOLD),
    "625": (4, 1.4, "625\nConfirmation\nAnomaly Gate", RED),
    "700": (1.3, 1.4, "700\nCalibration\n(\"Feeding\" Mode)", GOLD),
    "800": (1.3, -1.2 + 2.6, "800\nConversational\nInterface", BLUE),
}
# place 800 and 900 explicitly (clearer than the expr above)
boxes["800"] = (1.3, 1.4 - 2.6, "800\nConversational\nInterface", BLUE)
boxes["900"] = (1.3, 1.4 - 5.2, "900\nSelf-Improve.\nMonitor & Report", BLUE)

w, h = 2.0, 1.25
patches = {}
for key, (x, y, label, color) in boxes.items():
    box = FancyBboxPatch((x - w/2, y - h/2), w, h,
                          boxstyle="round,pad=0.05,rounding_size=0.12",
                          linewidth=1.4, edgecolor=color, facecolor="white", zorder=3)
    ax.add_patch(box)
    ax.text(x, y, label, ha="center", va="center", fontsize=8.6, color=BLACK, zorder=4)
    patches[key] = (x, y)

def arrow(a, b, **kw):
    x1, y1 = patches[a]; x2, y2 = patches[b]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=BLACK, lw=1.1,
                                 shrinkA=18, shrinkB=18), zorder=2, **kw)

for a, b in [("100","200"),("200","300"),("300","400"),("400","500"),
             ("500","600"),("600","625"),("625","700"),("700","800"),("800","900")]:
    arrow(a, b)

legend_items = [
    ("Real-time sensing (MCU)", NAVY), ("Edge-AI SoC", BLUE),
    ("Anomaly gate", RED), ("Confirmation-gated learning", GOLD),
    ("Classification / averaging", GREEN),
]
handles = [FancyBboxPatch((0,0), 1, 1, facecolor="white", edgecolor=c, linewidth=1.4) for _, c in legend_items]
ax.legend(handles, [l for l, _ in legend_items], loc="upper left",
          bbox_to_anchor=(-0.04, 1.05), ncol=1, frameon=False, fontsize=8,
          labelcolor=BLACK, handlelength=1.1, handleheight=1.1)

fig.tight_layout()
fig.savefig("/home/claude/work/figs_compliant/fig_block_diagram.pdf", bbox_inches="tight")
plt.close(fig)
print("fig1 done")

# ---------------------------------------------------------------- Figure 2 (classification space)
rng = np.random.default_rng(DEFAULT_SEED)
sigma_r, sigma_phi = 0.03, 6.0
fig, ax = plt.subplots(figsize=(5.2, 4.3))
colors = {"Iron": NAVY, "Bronze": GOLD, "Gold": "#D4A72C", "Copper": RED}
ax.axvspan(0, 0.30, color="0.90", zorder=0)
ax.text(0.15, -78, "ferrous zone", ha="center", va="center", fontsize=8,
        style="italic", color=BLACK)
for cls in CLASSES:
    r0, p0 = CENTROIDS[cls]
    rr = rng.normal(r0, sigma_r, 400)
    pp = rng.normal(p0, sigma_phi, 400)
    ax.scatter(rr, pp, s=7, alpha=0.55, color=colors[cls], label=cls,
               edgecolors="none")
ax.set_xlabel(r"$R_{decay} = V(G8)/V(G2)$", color=BLACK)
ax.set_ylabel("Phase shift " + r"$\Delta\varphi$" + " (degrees)", color=BLACK)
ax.set_xlim(0, 1.05); ax.set_ylim(-85, 85)
ax.tick_params(colors=BLACK)
for spine in ax.spines.values():
    spine.set_color(BLACK)
ax.grid(alpha=0.25, color="0.8")
leg = ax.legend(loc="lower right", frameon=False, fontsize=8.5, labelcolor=BLACK)
fig.tight_layout()
fig.savefig("/home/claude/work/figs_compliant/fig_classification_space.pdf", bbox_inches="tight")
plt.close(fig)
print("fig2 done")

# ---------------------------------------------------------------- Figure 3 (depth vs N)
Ns = [1, 6, 30, 126, 423]
rho_ref = 50.0
det = [depth_at_threshold(rho_ref, 6, RHO_DET, n) for n in Ns]
disc = [depth_at_threshold(rho_ref, 6, RHO_DISC, n) for n in Ns]
fig, ax = plt.subplots(figsize=(5.2, 4.0))
ax.plot(Ns, det, "o-", color=NAVY, lw=1.6, ms=5, label=r"Detection depth ($\rho_{th}=3$)")
ax.plot(Ns, disc, "s--", color=GOLD, lw=1.6, ms=5, label=r"Discrimination-reliable depth ($\rho_{disc}=33$)")
for n, d in zip(Ns, det):
    ax.annotate(f"{d:.2f}m", (n, d), textcoords="offset points", xytext=(0, 7),
                ha="center", fontsize=8, color=BLACK)
for n, d in zip(Ns, disc):
    ax.annotate(f"{d:.2f}m", (n, d), textcoords="offset points", xytext=(0, -13),
                ha="center", fontsize=8, color=BLACK)
ax.set_xscale("log")
ax.set_xlabel("Coherently averaged pulses, N (log scale)", color=BLACK)
ax.set_ylabel("Depth (m)", color=BLACK)
ax.tick_params(colors=BLACK)
for spine in ax.spines.values():
    spine.set_color(BLACK)
ax.grid(alpha=0.25, color="0.8")
ax.legend(loc="upper left", frameon=False, fontsize=8.5, labelcolor=BLACK)
fig.tight_layout()
fig.savefig("/home/claude/work/figs_compliant/fig_depth_vs_N.pdf", bbox_inches="tight")
plt.close(fig)
print("fig3 done")

# ---------------------------------------------------------------- Figure 4 (gradiometer geometry)
fig, ax = plt.subplots(figsize=(4.6, 5.0))
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Circle((0,0), 0.60, fill=False, edgecolor=NAVY, lw=2.0))
ax.add_patch(Circle((0,0), 0.40, fill=False, edgecolor=GOLD, lw=2.0, linestyle="--"))
ax.add_patch(Circle((0,0), 0.20, fill=False, edgecolor=GREEN, lw=2.0))
ax.plot(0, 0, marker="+", color=BLACK, ms=12, mew=1.6)
ax.text(0.01, 0.075, "null point", ha="center", va="bottom", fontsize=8.5,
        style="italic", color=BLACK)
ax.set_xlim(-0.75, 0.75); ax.set_ylim(-0.95, 0.75)
legend_lines = [
    Line2D([0], [0], color=NAVY, lw=2.0, label="Tx (1.2 m dia., 20T)"),
    Line2D([0], [0], color=GOLD, lw=2.0, linestyle="--", label="Bucking (0.8 m dia.)"),
    Line2D([0], [0], color=GREEN, lw=2.0, label="Rx (0.4 m dia., 200T)"),
]
ax.legend(handles=legend_lines, loc="lower center", bbox_to_anchor=(0.5, -0.06),
          frameon=False, fontsize=8.5, labelcolor=BLACK)
fig.tight_layout()
fig.savefig("/home/claude/work/figs_compliant/fig_gradiometer_geometry.pdf", bbox_inches="tight")
plt.close(fig)
print("fig4 done")
