import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
    "font.size": 10, "text.color": "black",
    "pdf.fonttype": 42,
})

NAVY="#1B3A6B"; BLUE="#5B82B5"; GREEN="#5E8C6A"; GOLD="#C9971F"; RED="#A6443A"; BLACK="#000000"

fig, ax = plt.subplots(figsize=(6.0, 6.6))
ax.axis("off")
ax.set_xlim(0, 10)
ax.set_ylim(0, 12.6)
ax.set_autoscale_on(False)
ax.set_aspect("auto")

# legend strip at the very top, clear of all boxes
legend_items = [
    ("Real-time sensing (MCU)", NAVY), ("Edge-AI SoC", BLUE),
    ("Classification / averaging", GREEN),
    ("Confirmation-gated learning", GOLD), ("Anomaly gate", RED),
]
lx, ly = 0.3, 12.1
for i, (label, color) in enumerate(legend_items):
    row, col = divmod(i, 2)
    yy = ly - row * 0.55
    xx = lx + col * 5.1
    ax.add_patch(FancyBboxPatch((xx, yy - 0.16), 0.34, 0.26,
                 boxstyle="round,pad=0.02,rounding_size=0.05",
                 linewidth=1.3, edgecolor=color, facecolor="white", clip_on=False))
    ax.text(xx + 0.5, yy - 0.03, label, ha="left", va="center", fontsize=8.3, color=BLACK)

boxes = {
    "100": (1.3, 9.9,  "100\nSignal\nGeneration", NAVY),
    "200": (4.3, 9.9,  "200\nAcquisition\n(dual-ADC)", BLUE),
    "300": (7.3, 9.9,  "300\nFusion /\nFeature Extract.", GREEN),
    "400": (7.3, 7.6,  "400\nClassification\n(dual-threshold)", GREEN),
    "500": (7.3, 5.3,  "500\nCoherent-\nAveraging Ctrl", GREEN),
    "600": (4.3, 5.3,  "600\nExperiential\nLearning Loop", GOLD),
    "625": (4.3, 3.0,  "625\nConfirmation\nAnomaly Gate", RED),
    "700": (1.3, 3.0,  "700\nCalibration\n(\"Feeding\" Mode)", GOLD),
    "800": (1.3, 0.7,  "800\nConversational\nInterface", BLUE),
    "900": (4.3, 0.7,  "900\nSelf-Improve.\nMonitor & Report", BLUE),
}
w, h = 2.3, 1.3
pos = {}
for key, (x, y, label, color) in boxes.items():
    ax.add_patch(FancyBboxPatch((x - w/2, y - h/2), w, h,
                 boxstyle="round,pad=0.05,rounding_size=0.12",
                 linewidth=1.4, edgecolor=color, facecolor="white", clip_on=False, zorder=3))
    ax.text(x, y, label, ha="center", va="center", fontsize=8.6, color=BLACK, zorder=4)
    pos[key] = (x, y)

def arrow(a, b):
    x1, y1 = pos[a]; x2, y2 = pos[b]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=BLACK, lw=1.1,
                                 shrinkA=20, shrinkB=20), zorder=2,
                annotation_clip=False)

for a, b in [("100","200"),("200","300"),("300","400"),("400","500"),
             ("500","600"),("600","625"),("625","700"),("700","800"),("800","900")]:
    arrow(a, b)

fig.savefig("/home/claude/work/figs_compliant/fig_block_diagram.pdf", bbox_inches="tight")
print("ok")
