# Build notes for H-FMD_Manuscript_SciIranica.docx

This manuscript is built as native OOXML directly on the official **Template_Scientia_Iranica**
Word file the author supplied (not an emulation, and not the earlier LaTeX draft one level up in
`../superseded_LaTeX_emulation/`). All of the template's own `styles.xml`, headers/footers, theme,
and section properties are reused byte-for-byte; only the body content was replaced.

## How it was built

1. The official template was unzipped and its structure reverse-engineered directly from the XML
   (`word/document.xml`, `word/styles.xml`) plus a full visual read of all 4 rendered pages, to
   recover every named style actually used (`Title`, `Subtitle`, `Affiliation`, `Date`, `Keyword`,
   `Abstract`, `Heading1/2/3`, `Normaltext`, `Figure`, `FigureCaption`, `TableCaption`,
   `References`, `TableofAuthorities`, `TableGrid`, etc.) and every structural rule (single-column;
   Times New Roman 10 pt; 3-level heading numbering; no footnotes; figures/tables moved out of the
   flow to the end of the document after References/Biographies, with a consolidated list of
   captions; black, non-bold, Times New Roman 10 figure lettering; horizontal-only table borders;
   `☐`/`☒` funding/COI checkboxes; mandatory Note:/`* GenAI` disclosure pair; ~100-word
   Biographies; CRediT "Authors' Credit"; optional Nomenclature).
2. `content.py` holds every piece of manuscript content (title, authors, abstract, 11 numbered
   sections, nomenclature, 11 references with verified DOIs, GenAI/funding/COI declarations, CRediT,
   biography, and the 4-figure + 6-table list) as plain Python data — no formatting logic lives
   here.
3. `build.py` reads `content.py`, generates the OOXML body (`word/document.xml`) re-using the
   template's own style IDs, embeds the 4 regenerated figures and 6 rendered equation images from
   `build_source/media/`, and re-zips the result into the final `.docx`.
4. Figures (`build_source/figs_compliant/`) were regenerated from the project's real, seeded
   simulation script — not redrawn by hand — with text forced pure black (Liberation Serif, a
   Times-metric-compatible font) and color reserved only for non-text graphical elements, per the
   template's explicit figure-lettering rule.
5. The 6 numbered display equations (`build_source/eqn_render/eq_1.tex` … `eq_6.tex`) were each
   compiled as a standalone `mathptmx` (Times-compatible math) LaTeX document and rendered to a
   600 dpi PNG, so equation glyphs visually match the Times New Roman body text.
6. The built `.docx` was validated with the standard docx-validation tooling (277 paragraphs, all
   checks passed) and every one of its 9 rendered pages was visually inspected against the
   template's own layout rules before delivery.
7. A later revision pass added three further references (UXO decay-characterisation and
   concept-drift/TinyML literature, cited in Sections 1.1, 3.2, and 8), refined the ρ@1.5m
   first-principles cross-check in Section 6.1 to report a per-material breakdown rather than a
   single pooled range, refined the Section 10 roadmap's Phase-2 description, and replaced the
   Biography placeholder with the author's own text. All three new references were independently
   checked against their publishers (Crossref-adjacent sources) before being added — none is
   fabricated.

## Re-running the build

```
cd build_source
python3 build.py        # regenerates ../H-FMD_Manuscript_SciIranica.docx
```

(Requires the unzipped official template tree, referenced inside `build.py`, and the images already
staged in `build_source/media/`.)

## Status

No placeholders remain. The Biography section carries the author's own text, all 11 references
carry verified DOIs (hyperlinked where one exists) in true citation order, and every figure/table
compliance rule noted above has been visually re-confirmed on this revision's 9 pages. The file's
own internal metadata (File > Properties in Word) was also corrected — the official template ships
with its own baked-in author ("pc") and a January-2026 creation date, both now replaced with the
real author name and an accurate creation date, so nothing of the template's authoring history
leaks into the submitted file. This is the submission-ready version.
