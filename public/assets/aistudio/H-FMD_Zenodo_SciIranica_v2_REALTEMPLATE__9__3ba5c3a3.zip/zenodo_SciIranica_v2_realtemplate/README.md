# H-FMD FINAL-v1/3
## Step 1 of 3: Design and Engineered Architecture

This package is the finalized, submission-formatted output of the H-FMD/HYBRID-X design-and-
simulation study — Phase 1 of the project's three-phase programme (Phase 2: benchtop validation;
Phase 3: field integration — see Section 10 of the manuscript). It synthesizes and finalizes work
from prior passes rather than starting over; `H-FMD_FINAL-v1_3_Synthesis_Log.md` documents exactly
what was kept, restored, merged, or newly built, and why.

## CURRENT submission target: Scientia Iranica — go to `07_scientia_iranica/` first

The project's submission target changed to **Scientia Iranica** (Sharif University of Technology,
Transactions D), which runs **single-blind** review — the author's name appears on the manuscript
itself, unlike the double-blind venue this project was originally formatted for. Everything in
`01_manuscript_LaTeX/` through `04_submission_package/` below, and one of the two Zenodo zips, was
built for that earlier, different target and is kept only for provenance.

The author subsequently supplied the journal's **actual official Word template**
(`Template_Scientia_Iranica.docx`). The manuscript was rebuilt as native OOXML directly on that
real template — reusing its own styles, headers/footers, and every structural rule (figure/table
placement at the end of the document, heading numbering, checkbox-style funding/COI declarations,
etc.) — superseding the earlier, independently-researched LaTeX emulation.

For the current, real-template-built submission materials, use:

| If you want to... | Open this |
|---|---|
| Read/submit the paper | `07_scientia_iranica/REAL_TEMPLATE_DOCX/H-FMD_Manuscript_SciIranica.docx` + `.pdf` — built directly on the journal's own official template, author identity shown, 9 pages, 11 verified references, validated and visually QA'd page-by-page — no placeholders remain |
| See exactly how it was built | `07_scientia_iranica/REAL_TEMPLATE_DOCX/README_BUILD.md` |
| Read what's confirmed about the journal's requirements and what changed once the real template arrived | `07_scientia_iranica/SCIENTIA_IRANICA_ADAPTATION_NOTES.md` |
| Submit the cover letter / highlights | `07_scientia_iranica/Cover_Letter_SciIranica.txt`, `07_scientia_iranica/Highlights_CRediT_COI_AIdisclosure_SciIranica.txt` |
| Upload to Zenodo | `07_scientia_iranica/H-FMD_Zenodo_SciIranica_v2_REALTEMPLATE.zip` — **one** record (single-blind means no blind/full split is needed) |
| See the superseded, pre-real-template LaTeX draft (kept for provenance only) | `07_scientia_iranica/superseded_LaTeX_emulation/` |
| Everything else (supplementary material, patent blueprint, simulation code, results) | unchanged, journal-agnostic — see below, same paths |

## Start here (earlier, double-blind-venue-targeted materials — superseded, kept for provenance)

| If you want to... | Open this |
|---|---|
| Read the paper | `01_manuscript_LaTeX/manuscript_body.pdf` |
| Submit to the journal | `01_manuscript_LaTeX/*.tex` + `04_submission_package/*` — read `01_manuscript_LaTeX/COMPILE_NOTES.txt` first |
| See full derivations condensed out of the main text | `02_supplementary_material/` |
| Read the patent/IP strategy document | `03_patent_blueprint/H-FMD_Patent_Blueprint_FINAL_v1.pdf` |
| Reproduce every [calc]/[sim] number | `05_core_simulation/H-FMD_final_reproducible_simulation_FINAL_v1.py` |
| Upload to Zenodo | `zenodo_packages/` — **two** zips, deposit as **two separate records** |
| See exactly what changed and why | `H-FMD_FINAL-v1_3_Synthesis_Log.md` |

## What's inside

```
01_manuscript_LaTeX/        Main paper: LaTeX source, compiled PDF (6 pages, 10 exhibits,
                             267-word abstract — verified inside TJEECS's stated limits),
                             separate title page, 4 figures (PDF), compile notes
02_supplementary_material/  Full depth grids, mass/power/thermal derivations, appendix
                             traceability matrix and risk register (Word + PDF)
03_patent_blueprint/        Document 1, synced to this revision (Word + PDF)
04_submission_package/      Cover letter, Highlights/CRediT/COI/AI-disclosure
05_core_simulation/         The reproducible script (rho/SNR-consistent notation)
06_results/                 Output of the last run of the script above
zenodo_packages/            Two ready-to-upload zips — blind-review and full-archive
```

## The two Zenodo packages below — superseded; see `07_scientia_iranica/` for the current one

The split described in this section existed to satisfy a double-blind reviewer process. Scientia
Iranica is single-blind, so this split is not needed for that target — use
`07_scientia_iranica/H-FMD_Zenodo_SciIranica_v2_REALTEMPLATE.zip` (one record) instead. Kept here
for provenance / in case of a future double-blind target:

`zenodo_packages/H-FMD_Zenodo_FINALv1_BLIND_REVIEW.zip` contains only anonymized material
(independently verified: zero identity hits across every file). `..._FULL_ARCHIVE.zip` contains
everything, including the patent blueprint and cover letter. **Only the blind-review record's DOI
belongs anywhere a journal's double-blind review process might see it.**

## Before you actually submit (to Scientia Iranica)

1. Deposit `07_scientia_iranica/H-FMD_Zenodo_SciIranica_v2_REALTEMPLATE.zip`, get its DOI, and
   fill it into the manuscript's Data Availability statement and the cover letter.
2. Read `H-FMD_FINAL-v1_3_Synthesis_Log.md`, section "Open items carried forward" — several
   engineering items (SNR@1.5 m calibration, wire-gauge/SNR-penalty recheck, AFE transformer
   bench-optimisation, the detection-threshold derivation) remain genuinely open and are stated
   as such in the manuscript itself; they are not resolved by this packaging pass.
3. Talk to a patent attorney about filing timing relative to the Zenodo deposit, if you have not
   already — flagged as urgent in earlier review of this project.

### Earlier checklist (TJEECS target, superseded)

1. Recompile `manuscript_body.tex` in the journal's real Overleaf template (see
   `01_manuscript_LaTeX/COMPILE_NOTES.txt`) — this build used a close approximation of the
   official class file, since that file isn't independently redistributable.
2. Deposit both Zenodo packages, get their DOIs, and fill them into the manuscript's Data
   Availability statement and the cover letter.
