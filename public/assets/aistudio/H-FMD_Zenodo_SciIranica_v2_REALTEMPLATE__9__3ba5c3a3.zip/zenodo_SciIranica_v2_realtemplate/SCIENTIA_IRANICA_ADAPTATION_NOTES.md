# Scientia Iranica adaptation notes

This note documents what changed when the H-FMD FINAL-v1/3 package was re-targeted from a
double-blind-review venue to *Scientia Iranica*, Transactions D, and — the pivotal update — what
happened once the author supplied the journal's **actual official Word template**
(`Template_Scientia_Iranica.docx`), superseding the earlier, independently-researched LaTeX
emulation. Written in the same transparent, nothing-silently-assumed spirit as the rest of this
project's corrections logs.

## Current status: built directly on the real, confirmed template

The authoritative manuscript for this submission target is now:

**`REAL_TEMPLATE_DOCX/H-FMD_Manuscript_SciIranica.docx`** (+ its PDF rendering).

This is a native OOXML document built by reusing the official template's own `styles.xml`,
headers/footers, theme, and section properties verbatim, with only the body content replaced. It
is not a redesign or a best-guess emulation — every structural rule below was read directly off the
template the author provided, not inferred or researched indirectly:

- Single-column; body text Times New Roman 10 pt, single line spacing, justified.
- Named styles reused exactly as the template defines them: `Title`, `Subtitle`, `Affiliation`,
  `Date`, `Keyword`, `Abstract`, `Heading1/2/3`, `Normaltext`, `Figure`, `FigureCaption`,
  `TableCaption`, `References`, `TableofAuthorities`, `TableGrid`.
- Three-level maximum heading numbering (`1.` / `1.1.` / `1.1.1.`, not indented).
- No footnotes anywhere.
- References numbered in citation order (not alphabetical), each with a hyperlinked DOI where one
  exists, ">3 authors" collapsed to "et al." — all 11 references in this manuscript were
  independently checked against publisher/bibliographic sources (7 real DOIs confirmed and
  hyperlinked; 4 confirmed to genuinely have no DOI, e.g. a government report and a patent, rather
  than guessed). Three references (UXO decay-characterisation and concept-drift/TinyML literature)
  were added in a later revision pass and are cited in Sections 1.1, 3.2, and 8.
- Figures and tables are **not inline** — all actual figure/table content, plus a consolidated
  "list of captions," sit at the very end of the document, after References and Biographies, per
  the template's explicit layout rule.
- Figure lettering is pure black (not colored), Times New Roman 10, not bold, on a white
  background — all 4 figures were regenerated from scratch (not just recolored) using the
  project's real, seeded simulation script, enforcing this rule at the font/color level rather than
  patching it after the fact.
- Table borders are horizontal-only, per the template.
- Funding / Conflicts-of-interest declarations render as `☐`/`☒` checkbox glyphs, as the template
  specifies.
- The mandatory GenAI-use disclosure appears as the required "Note:" → "`* GenAI`" heading pair.
- An optional Nomenclature table is included (11 entries), unnumbered heading, per the template.
- Authors' Credit (CRediT taxonomy) and a ~100-word Biographies section are both present in the
  template's own required format.

Full build methodology is documented in `REAL_TEMPLATE_DOCX/README_BUILD.md`. No placeholders
remain — the Biography section carries the author's own text.

## What this supersedes

Before the author supplied the real template, this target was prepared from independently
researched, confirmed-vs-assumed information about the journal (see "What was confirmed" below) —
producing a single-column, dependency-free LaTeX emulation on the plain `article` class, kept now
for provenance at `superseded_LaTeX_emulation/manuscript_SciIranica.tex`/`.pdf`. That draft was a
reasonable, transparently-caveated best effort given what was retrievable at the time (the
template's host page returned a `robots.txt` disallow to automated fetches, and its download link
on the journal's own site rendered through a client-side control a text-level fetch couldn't
follow) — but it was never claimed to be pixel-exact, and it no longer needs to be: the real
template is now in hand and was used directly.

## What was confirmed (independent, live research — still accurate context)

- *Scientia Iranica* is published by Sharif University of Technology, Tehran. Transactions D
  covers Computer Science & Engineering and Electrical Engineering — the correct section for this
  manuscript.
- Peer review is **single-blind**: reviewers are shown the author's name; only the reviewers'
  identities are withheld from the author. Author identity (name, affiliation, email, ORCID) is
  therefore printed directly on the manuscript's own title block — confirmed present via a direct
  text-extraction check of the final PDF (name, email, ORCID, city, and province all found, as
  expected) — rather than withheld into a separate title-page file, and no blinded-body/title-page
  split is produced for this target.
- The journal was previously produced and hosted by Elsevier, which suspended services to Sharif
  University to comply with EU Regulation 1264/2012 (Iran sanctions); the journal continues as a
  Sharif-University-hosted, self-published title. Offered as context for why indirect, pre-template
  research described the house style in Elsevier-derived terms.
- Open access is under CC-BY with no author fee.

## Changes made for the single-blind policy

- The manuscript's Data Availability section, the cover letter, and the Highlights/CRediT/COI file
  all describe **one** fully identified Zenodo archive rather than a blind-review/full-archive
  split. That split existed specifically to keep a Zenodo DOI from leaking author identity to
  double-blind reviewers; under single-blind review the reviewers already see the author's name on
  the manuscript itself, so the split serves no purpose here.
- The prior TJEECS-targeted (double-blind) manuscript, cover letter, and Highlights file remain
  further up this project's tree under their own superseded paths, kept for provenance only.

## Remaining action items for the author before submission

1. Deposit `REAL_TEMPLATE_DOCX`'s companion Zenodo archive (see the top-level package), get its
   DOI, and fill it into the manuscript's Data Availability statement and the cover letter.
2. Read `H-FMD_FINAL-v1_3_Synthesis_Log.md`, section "Open items carried forward" — several
   engineering items (SNR@1.5 m calibration, wire-gauge/SNR-penalty recheck, AFE transformer
   bench-optimisation, the detection-threshold derivation) remain genuinely open and are stated as
   such in the manuscript itself; they are not resolved by this packaging pass.
3. Talk to a patent attorney about filing timing relative to the Zenodo deposit, if that has not
   already happened.
