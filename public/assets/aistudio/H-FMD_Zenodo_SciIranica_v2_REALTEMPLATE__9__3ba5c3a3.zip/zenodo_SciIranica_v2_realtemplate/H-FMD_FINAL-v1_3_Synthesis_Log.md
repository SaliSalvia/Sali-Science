# H-FMD FINAL-v1/3 — Synthesis & Corrections Log

**Label:** H-FMD FINAL-v1/3 — Step 1 of 3: Design and Engineered Architecture
**Date:** 2026-09-04

This pass synthesizes two independently-produced v5 revisions into one final, TJEECS-format-ready
package. It does not re-derive physics from scratch; it verifies, merges, condenses, and formats
work already done, and documents every decision below in the same Finding/Fix/Verified-by style as
the v4 and v5 logs.

## 1. Which SNR/ρ resolution was kept, and why

Two independently-produced fixes existed for the amplitude/power SNR ambiguity: this project's own
v5 pass (declared "SNR = amplitude ratio, uniformly") and a separately-produced revision (introduced
two symbols: ρ for the amplitude ratio governing depth, SNR=ρ² for the power-ratio system-margin
budget). **The two-symbol (ρ/SNR) resolution was kept** — it is more rigorous: it does not require
declaring §5's Albersheim/Skolnik-sourced detection-theory citations (which are genuinely
power-domain in the literature) to secretly be amplitude-domain, and it adds a real, independently
checkable consistency test (10·log₁₀(4000) = 36.02 dB matches the stated +36 dB coherent-integration
term exactly) that the author's own v5 pass did not include.

**Verified by:** extracting Table V(a)/(b) from the uploaded `H-FMD_HYBRID-X_Manuscript_v5_BLIND.docx`
cell-by-cell and confirming every entry (e.g. N=1 row: 1.63, 1.83, 2.06, 2.40, 2.69, 3.02) matches
the values already confirmed correct by executing the archived simulation script in an earlier pass
— only the column header symbol changed (SNR→ρ), no number drifted. ρ_th=3.0 and ρ_disc=33.0 match
the script's hard-coded `RHO_DET`/`RHO_DISC` constants (renamed from `SNR_DET`/`SNR_DISC` in this
pass for notational consistency with the paper; values unchanged — see item 6).

## 2. Content restored after the SNR-fix revision dropped it

**Finding.** The uploaded `_v5_BLIND` and `_v5_CORRECTED` files, while fixing SNR/ρ correctly, had
also reverted every system-level engineering addition from this project's own v5 pass: the power
budget (~34 W continuous draw at full PRF), the mass budget (~8.2 kg copper at the original winding
spec), the thermal analysis, the adaptive-PRF mitigation, the interleaved-timing/blanking
specification, the bucking-turn-count derivation, and the AFE noise-budget revision. The patent
blueprint's three flagged attorney-review items (RERS "energy-recovery" terminology vs. the
dissipative adopted embodiment; "portable" claim language vs. the ~8.6 kg ground-frame reality;
a possible new dependent claim for adaptive-PRF power management) were similarly dropped.

**Fix.** All of the above is restored in this synthesis — condensed to fit the target journal's
15-page / 10-exhibit limits (item 3), not omitted. The power budget's 34.4 W total is additionally
corrected to 33.6 W (see item 5, carried over from the prior pass) rather than reintroduced with its
original small inconsistency.

## 3. TJEECS format compliance — now addressed, not just flagged

Fetched and applied, directly from the journal's own published pages, rather than assumed:
- **LaTeX, not Word**, using `\cite`, numbered sections, `thebibliography` — the deliverable
  manuscript is now `manuscript_body.tex`, compiled and verified.
- **≤15 pages**: compiles to **6 pages** in a dense two-column approximation of the journal's own
  format (verified by direct `pdflatex` compilation, not estimated).
- **≤10 figures+tables combined**: exactly **10** (4 figures, 6 tables) in the main text, down from
  29 in the pre-synthesis draft; everything else moved to `Supplementary_Material.docx`, cross-
  referenced by number (Table S1, S2, …) from the main text, consistent with the journal's own
  "excluding supplements" carve-out.
- **≤300-word abstract, no citations**: 267 words, zero `\cite` commands, verified by direct count
  from the compiled PDF.
- **Separate title page, no author info in the body**: `title_page.tex` now carries name,
  affiliation, ORCID, corresponding-author mark, author contributions, funding, COI, and data
  statement; `manuscript_body.tex` contains no author mention anywhere, matching Editorial
  Manager's two-file blind-submission workflow (the earlier BLIND file used a same-file placeholder
  sentence instead, which the journal's own instructions say not to do).
- **AI-use disclosure**: written as a dedicated Acknowledgment subsection in the manuscript itself
  (mandatory per journal policy) and expanded in `Highlights_CRediT_COI_AIdisclosure.txt`.
- **Cover letter**: written fresh (`Cover_Letter.txt`), disclosing the Zenodo preprint per the
  journal's own preprint policy and the pending provisional patent application.

**Not yet done, explicitly:** compiling against the *official* `elektr.cls`/`elksty.tex` files
(not redistributable outside the journal's own template download/Overleaf copy) — the page/exhibit/
word counts above were verified against a close two-column approximation. A final compile in the
journal's real Overleaf template, before actual submission, is still recommended and may shift
pagination by roughly ±1–2 pages.

## 4. Patent Blueprint — merged, not just reverted or kept

**Finding.** The uploaded `_CORRECTED` patent blueprint did valuable, independent work: it
propagated the ρ/SNR convention consistently throughout (renaming every SNR_th/SNR_disc mention to
ρ_th/ρ_disc) and added a genuinely elegant proof that Mechanism 1's coherent-averaging depth(N)
formula is identical whether derived via √N on ρ (1/6 exponent) or N-fold on SNR (1/12 exponent) —
neither convention changes the N^(1/12) result. This is kept as the base. It had, however, also
dropped the three attorney-review flags from this project's v5 patent-blueprint sync.

**Fix.** The three flags (RERS terminology, portable/mass, block-500 dependent-claim suggestion)
are re-inserted at their original anchor points, updated to cite the corrected 33.6 W figure and the
current manuscript's actual section numbers (Section 4.2–4.3, not the pre-synthesis §IV.C).
No claim text (§V) is altered in either direction — claim-language decisions remain with counsel.

**Verified by:** paragraph-level diff between the uploaded `_CORRECTED` file and this project's own
prior v5 patent blueprint, confirming which paragraphs were genuinely new/improved (ρ propagation,
Mechanism-1 proof) versus simply absent (the three flags) before deciding what to keep, add, or
restore.

## 5. Numeric consistency carried forward unchanged from the prior pass

The 33.6 W (not 34.4 W) power-budget total, the 0.671 (not 0.858) discrimination ratio, and the
0.229 nV/√Hz AFE noise figure are all unchanged from the previous synthesis pass and are not
re-derived here — see the prior `H-FMD_Corrections_v5_Log.md` for their original Finding/Fix/
Verified-by entries. This pass re-confirms them against the newly uploaded files rather than
re-deriving them from scratch.

## 6. Script — renamed for notational consistency, not recomputed

`H-FMD_final_reproducible_simulation_FINAL_v1.py` renames `SNR_DET`/`SNR_DISC` to `RHO_DET`/
`RHO_DISC` (values unchanged: 3.0 and 33.0, both plain linear amplitude ratios) to match the paper's
now-resolved ρ/SNR notation, with an inline comment explaining the rename and explicitly noting that
the separately-drafted `v5script.docx`'s proposed 3.981/10.0 values (yielding the rejected 0.858
ratio) were not applied.

**Verified by:** re-executing the renamed script end-to-end after the rename; every output value
(classification 25.75%/9.08%, RERS worst-of-300k 574.96 V, and the full detection/discrimination
depth grid at ratio 0.6703–0.6709 across all six calibration points) matches the pre-rename output
exactly.

## Open items carried forward, unchanged

- SNR@1.5 m calibration remains unmeasured — still the single highest-priority item.
- The wire-gauge/SNR-penalty gap in the revised gradiometer winding remains open.
- The AFE transformer ratio remains a design point pending bench optimisation.
- The exact +12–13 dB detection-threshold derivation remains unstated pending the author's
  underlying notes.
- The Validation Protocol (Document 3) still has no LaTeX/blind variant and is carried forward from
  v4 unchanged in the full archive only.
- Final pagination should be re-verified in the journal's official Overleaf template before
  submission (item 3).

## 7. SNR@1.5 m — first-principles physics cross-check added (post-delivery addendum)

**Request.** The user asked for this project's single highest-priority open item — the
unmeasured SNR@1.5 m calibration point — to be addressed "however possible."

**What was and wasn't done.** SNR@1.5m is an empirical quantity; no computation substitutes
for the actual Test 5 bench measurement, and this pass does not claim otherwise. What *is*
newly added is a genuine, independent, closed-form physics estimate (not a simulation, not a
guess) built entirely from quantities already fixed elsewhere in this project: the transmit
coil (Section 4.1), the target eddy-current decay constants (Section 3.2), and the AFE noise
floor (Section 5) — plus one externally verified formula (eddy-current sphere response,
Rushton et al., Rev. Sci. Instrum. 93, 125103, 2022).

**Method, briefly.** The manuscript's own stated τ values imply a reference-target radius of
≈15–18 cm (copper and bronze agree on 15.0 cm exactly, from two independent conductivities —
a genuinely reassuring internal-consistency finding). Combined with the transmit coil's known
field at 1.5 m and the target's instantaneous induced dipole moment, the resulting received
EMF (370–2200 nV depending on material) compared against the 0.229 nV/√Hz noise floor gives
ρ@1.5m ≈ 5–160 across plausible bandwidth assumptions — landing inside the previously
unjustified "assumed 5–200" range. This is a meaningful, partial validation, not a closure of
the item.

**Self-caught error.** An early hand-derivation used m(0⁺)=a³B₁ instead of the correct
m(0⁺)=2πa³B₁/μ₀ — a factor of ~5,000,000 error, caught because the resulting femtovolt-scale
signal was physically implausible (far below even a negligible-bandwidth noise floor) and
confirmed via an independent field-domain cross-check before being used in any conclusion.
Documented in Supplementary Material Section S8.5 rather than silently fixed.

**New finding worth the author's attention.** The same calculation at a coin-sized (10 mm)
target instead of the manuscript's implied 15–18 cm target gives ρ@1.5m≈1–11 — at or below
the detection threshold for most of the bandwidth range. Confirming the *intended*
reference-target size is therefore now a second, closely-related open question alongside
Test 5 itself.

**Where this lives:** main text Section 6.1 (concise), Supplementary Material Section S8
(full derivation, sensitivity table, the caught error), Appendix Table A-1/A-2 entries
updated from "still open" to "partially addressed," and a new reproducible function
(`snr_at_1p5m_first_principles()`) in the core simulation script.

**Verified by:** re-executing the updated script end-to-end; the new function's output
(copper SNR 5.17–163.57 across 100 Hz–100 kHz bandwidth) matches the hand-derivation to
within float-rounding, and every previously-verified number in the script (classification
25.75%/9.08%, RERS 574.96 V, discrimination ratio 0.6705) is unchanged.
