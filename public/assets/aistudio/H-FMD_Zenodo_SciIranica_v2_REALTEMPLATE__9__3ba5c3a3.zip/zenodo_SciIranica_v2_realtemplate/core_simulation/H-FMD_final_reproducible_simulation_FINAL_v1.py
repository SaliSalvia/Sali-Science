"""
H-FMD Final Reproducible Simulation Driver -- v4 (merged, corrected pass)
Original revision: 2026-08-14. Merged 2026-08-30 with the v2 extension
(classification_breakdown + cluster_error_metrics) that closes the
previously-open "Gold/Copper-cluster error" verification item -- see
Table I footnote in the v4 manuscript and README_ZENODO_v4.md.

Purpose:
  Reproduce the bounded numerical analyses used in the final H-FMD package.

Important evidentiary rule:
  Simulation outputs are not bench/field measurements. The script labels
  assumptions explicitly and writes a JSON result file beside the figures.

Key corrections from the prior driver:
  1) RERS clamp capacitor tolerance is locked to +/-5% (not +/-10%).
  2) RERS PASS criterion is Vpeak < 575 V, matching the final validation protocol.
  3) Nominal inductance is carried as 185.4 uH where that reference coil is used.
  4) No hard-coded absolute-depth claim is emitted; depth is conditional on the
     measured 1.5 m calibration point and fitted attenuation exponent.
  5) The script has no null-byte/truncated tail and uses a user-selectable output dir.
  6) v4: classification_breakdown() and cluster_error_metrics() added so Table I's
     per-class accuracy and "non-ferrous pooled error" columns are computed directly
     by this script rather than deferred to unarchived companion code. Everything
     else is byte-for-byte unchanged from the 2026-08-14 driver; every previously
     published number still reproduces exactly.
"""

from __future__ import annotations
# ============================================================================
# v FINAL-v1/3 notation note (added during H-FMD FINAL-v1/3 synthesis pass):
# Renamed SNR_DET/SNR_DISC -> RHO_DET/RHO_DISC. Values are UNCHANGED (3.0 and
# 33.0, both plain linear amplitude ratios) -- this is a rename for clarity
# only, matching the manuscript's resolved rho (amplitude ratio, governs the
# r^-6 depth law) vs SNR (power ratio = rho^2, used only in the Sec.5 system
# margin budget) convention. A separately-drafted v5script.docx proposed
# changing these values (implicitly, via a new +20dB discrimination
# threshold) to 3.981/10.0, giving a 0.858 depth ratio instead of 0.671. That
# change is NOT applied here: it does not correspond to any derivation in the
# manuscript (Sec.6: rho_disc = 1/eps_A, eps_A=3%, giving 33 -- not 20dB/10.0),
# and re-running THIS unmodified logic is what confirms 0.671 is correct.
# ============================================================================

import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

DEFAULT_SEED = 20260814
CLAMP_V_LIMIT = 575.0
DRIVER_RATING_V = 620.0
L_NOM_UH = 185.4
C_NOM_NF = 672.0
I_NOM_A = 30.0
R_REF_M = 1.5
RHO_DET = 3.0   # amplitude-ratio detection threshold (paper Eq. 2); NOT the +12dB SNR(power) of Sec.5
RHO_DISC = 33.0  # amplitude-ratio discrimination threshold = 1/eps_A, eps_A=3% (paper Sec.6)

CENTROIDS = {
    "Iron": (0.112, -30.0),
    "Bronze": (0.759, 25.0),
    "Gold": (0.954, 58.0),
    "Copper": (0.955, 62.0),
}
CLASSES = list(CENTROIDS)


def depth_at_threshold(rho_ref, exponent, threshold, n_avg=1):
    """Depth conditional on a reference amplitude ratio rho and power-law exponent.
    NOTE: this function's argument is rho (amplitude ratio), matching the paper's
    Eq. (1)-(2) resolution: rho governs r^-6 directly; SNR=rho^2 (power) is a
    separate quantity used only in the Sec.5 system-margin budget, computed
    nowhere in this script."""
    return R_REF_M * (rho_ref * np.sqrt(n_avg) / threshold) ** (1.0 / exponent)


def classification_once(sigma_r, sigma_phi_deg, n_per_class=400, seed=1):
    rng = np.random.default_rng(seed)
    Xs, ys = [], []
    for cls in CLASSES:
        r0, p0 = CENTROIDS[cls]
        rr = rng.normal(r0, sigma_r, n_per_class)
        pp = rng.normal(p0, sigma_phi_deg, n_per_class)
        Xs.append(np.column_stack([rr, pp]))
        ys.extend([cls] * n_per_class)
    X = np.vstack(Xs)
    y = np.asarray(ys)
    C = np.asarray([[CENTROIDS[c][0], CENTROIDS[c][1] / 90.0] for c in CLASSES])
    Xn = np.column_stack([X[:, 0], X[:, 1] / 90.0])
    d2 = ((Xn[:, None, :] - C[None, :, :]) ** 2).sum(axis=2)
    pred = np.asarray(CLASSES)[np.argmin(d2, axis=1)]
    return float((pred == y).mean())


def _draw_and_predict(sigma_r, sigma_phi_deg, n_per_class, seed):
    """Identical draw order/logic to the archived classification_once(),
    but returns per-sample predictions and labels instead of collapsing
    straight to overall accuracy, so per-class and subset metrics can be
    computed from the SAME draw (bit-identical to the archived script)."""
    rng = np.random.default_rng(seed)
    Xs, ys = [], []
    for cls in CLASSES:
        r0, p0 = CENTROIDS[cls]
        rr = rng.normal(r0, sigma_r, n_per_class)
        pp = rng.normal(p0, sigma_phi_deg, n_per_class)
        Xs.append(np.column_stack([rr, pp]))
        ys.extend([cls] * n_per_class)
    X = np.vstack(Xs)
    y = np.asarray(ys)
    C = np.asarray([[CENTROIDS[c][0], CENTROIDS[c][1] / 90.0] for c in CLASSES])
    Xn = np.column_stack([X[:, 0], X[:, 1] / 90.0])
    d2 = ((Xn[:, None, :] - C[None, :, :]) ** 2).sum(axis=2)
    pred = np.asarray(CLASSES)[np.argmin(d2, axis=1)]
    return pred, y


def classification_breakdown(sigma_r, sigma_phi_deg, n_per_class=400, seed=DEFAULT_SEED):
    """Per-class accuracy + overall error, matching Table I's columns.
    Uses the exact same rng draw as classification_once(), so the
    'overall error' entry here is bit-identical to
    classification_baseline_error_pct / classification_matched_snr_error_pct
    in the original results.json."""
    pred, y = _draw_and_predict(sigma_r, sigma_phi_deg, n_per_class, seed)
    per_class = {}
    for c in CLASSES:
        mask = y == c
        acc = float((pred[mask] == y[mask]).mean())
        wrong_as = {}
        if acc < 1.0:
            wrong = pred[mask][pred[mask] != c]
            vals, counts = np.unique(wrong, return_counts=True)
            wrong_as = {str(v): int(n) for v, n in zip(vals, counts)}
        per_class[c] = {"accuracy_pct": round(acc * 100, 4), "misclassified_as": wrong_as}
    overall_error_pct = float((pred != y).mean()) * 100
    return per_class, overall_error_pct, pred, y


def cluster_error_metrics(sigma_r, sigma_phi_deg, n_per_class=400, seed=DEFAULT_SEED):
    """Computes every candidate 'Gold/Copper-cluster error' definition
    considered, so the author can see the full comparison rather than
    a single unexplained number."""
    pred, y = _draw_and_predict(sigma_r, sigma_phi_deg, n_per_class, seed)
    gc_mask = np.isin(y, ["Gold", "Copper"])
    nonferrous_mask = y != "Iron"

    # (A) "simple average of (1-accuracy)" for the two classes -- what
    #     the caption explicitly says this is NOT. Equivalent to the
    #     pooled 2-class error under the original 4-class boundary.
    simple_avg_pct = float((pred[gc_mask] != y[gc_mask]).mean()) * 100

    # (B) empirical-mean-refit 2-class-subspace boundary (resubstitution)
    Xn_gc = None  # computed inline below for clarity
    r0g, p0g = CENTROIDS["Gold"]
    r0c, p0c = CENTROIDS["Copper"]
    # reconstruct normalized features for the gc subset in draw order
    rng = np.random.default_rng(seed)
    Xs = []
    for cls in CLASSES:
        r0, p0 = CENTROIDS[cls]
        rr = rng.normal(r0, sigma_r, n_per_class)
        pp = rng.normal(p0, sigma_phi_deg, n_per_class)
        Xs.append(np.column_stack([rr, pp]))
    X = np.vstack(Xs)
    Xn = np.column_stack([X[:, 0], X[:, 1] / 90.0])
    Xn_gc = Xn[gc_mask]
    y_gc = y[gc_mask]
    gold_mean = Xn_gc[y_gc == "Gold"].mean(axis=0)
    copper_mean = Xn_gc[y_gc == "Copper"].mean(axis=0)
    d_gold = ((Xn_gc - gold_mean) ** 2).sum(axis=1)
    d_copper = ((Xn_gc - copper_mean) ** 2).sum(axis=1)
    pred_refit = np.where(d_gold < d_copper, "Gold", "Copper")
    refit_boundary_pct = float((pred_refit != y_gc).mean()) * 100

    # (C) pooled non-ferrous (Bronze+Gold+Copper) error under the
    #     ORIGINAL 4-class boundary -- reproduces the published 25.7%/9.1%
    nonferrous_pooled_pct = float((pred[nonferrous_mask] != y[nonferrous_mask]).mean()) * 100

    overall_error_pct = float((pred != y).mean()) * 100

    return {
        "overall_error_pct": round(overall_error_pct, 4),
        "candidate_A_simple_two_class_average_pct": round(simple_avg_pct, 4),
        "candidate_B_fitted_two_class_boundary_resubstitution_pct": round(refit_boundary_pct, 4),
        "candidate_C_nonferrous_pooled_pct__MATCHES_PUBLISHED": round(nonferrous_pooled_pct, 4),
        "candidate_C_equals_overall_times_4_over_3_check": round(overall_error_pct * 4 / 3, 4),
    }


def rers_mc(n=300_000, seed=DEFAULT_SEED):
    rng = np.random.default_rng(seed)
    L = rng.uniform(L_NOM_UH * 0.85, L_NOM_UH * 1.15, n) * 1e-6
    C = rng.uniform(C_NOM_NF * 0.95, C_NOM_NF * 1.05, n) * 1e-9
    I = rng.uniform(I_NOM_A * 0.95, I_NOM_A * 1.05, n)
    v = I * np.sqrt(L / C)
    t = np.pi * np.sqrt(L * C)
    return {
        "n": n,
        "L_tolerance_pct": 15,
        "C_tolerance_pct": 5,
        "I_tolerance_pct": 5,
        "nominal_v_recomputed_V": float(I_NOM_A * np.sqrt((L_NOM_UH*1e-6)/(C_NOM_NF*1e-9))),
        "v_p05_V": float(np.percentile(v, 5)),
        "v_p50_V": float(np.percentile(v, 50)),
        "v_p95_V": float(np.percentile(v, 95)),
        "v_max_V": float(v.max()),
        "p_v_ge_driver_rating": float(np.mean(v >= DRIVER_RATING_V)),
        "p_v_ge_pass_limit": float(np.mean(v >= CLAMP_V_LIMIT)),
        "tfall_p05_us": float(np.percentile(t*1e6, 5)),
        "tfall_p50_us": float(np.percentile(t*1e6, 50)),
        "tfall_p95_us": float(np.percentile(t*1e6, 95)),
        "pass_limit_V": CLAMP_V_LIMIT,
        "driver_rating_V": DRIVER_RATING_V,
    }


def depth_sensitivity():
    exponents = [4, 5, 6, 7, 8]
    snr_refs = [5, 10, 20, 50, 100, 200]
    det = {}
    disc = {}
    for p in exponents:
        det[str(p)] = [round(depth_at_threshold(s, p, RHO_DET, 6), 3) for s in snr_refs]
        disc[str(p)] = [round(depth_at_threshold(s, p, RHO_DISC, 6), 3) for s in snr_refs]
    return {"exponents": exponents, "snr_ref_values": snr_refs,
            "N_avg": 6, "detection_m": det, "discrimination_m": disc}


def contamination_sim(contamination, n_confirmed=400, defense=False, trials=25, seed=100):
    """Proxy study of confirmation mislabeling. Not a trained production classifier."""
    rng_test = np.random.default_rng(999)
    # fixed held-out set
    Xs, ys = [], []
    for cls in CLASSES:
        r0, p0 = CENTROIDS[cls]
        rr = rng_test.normal(r0, 0.03, 400)
        pp = rng_test.normal(p0, 6.0, 400)
        Xs.append(np.column_stack([rr, pp]))
        ys.extend([cls] * 400)
    Xt = np.vstack(Xs)
    yt = np.asarray(ys)
    Xt_n = np.column_stack([Xt[:,0], Xt[:,1]/90.0])

    def one(run_seed):
        rng = np.random.default_rng(run_seed)
        tier1 = {c: np.array([CENTROIDS[c][0], CENTROIDS[c][1]/90.0]) for c in CLASSES}
        tier2 = {c: tier1[c].copy() for c in CLASSES}
        counts = {c: 0 for c in CLASSES}
        errors = []
        for n in range(1, n_confirmed+1):
            true_c = CLASSES[rng.integers(0, len(CLASSES))]
            r0,p0 = CENTROIDS[true_c]
            sample = np.array([rng.normal(r0,0.03), rng.normal(p0,6.0)/90.0])
            if rng.random() < contamination:
                wrong = [c for c in CLASSES if c != true_c]
                confirmed = wrong[rng.integers(0,len(wrong))]
            else:
                confirmed = true_c
            reject = defense and np.linalg.norm(sample-tier2[confirmed]) > 0.35
            if not reject:
                eta=0.15
                tier2[confirmed] += eta*(sample-tier2[confirmed])
                counts[confirmed]+=1
            if n % 20 == 0:
                centers=[]
                for c in CLASSES:
                    a=min(1.0,counts[c]/50.0)
                    centers.append(a*tier2[c]+(1-a)*tier1[c])
                C=np.asarray(centers)
                d2=((Xt_n[:,None,:]-C[None,:,:])**2).sum(2)
                pred=np.asarray(CLASSES)[np.argmin(d2,axis=1)]
                errors.append(1-float(np.mean(pred==yt)))
        return errors

    all_runs=np.asarray([one(seed+i) for i in range(trials)])
    return {
        "contamination": contamination,
        "defense": defense,
        "trials": trials,
        "n_confirmed": n_confirmed,
        "final_mean_error_pct": float(all_runs[:,-1].mean()*100),
        "final_std_error_pct": float(all_runs[:,-1].std()*100),
    }


# H-FMD/HYBRID-X Final Reproducible Simulation Driver -- v5
# ============================================================
# Built by extending the unmodified, independently-executed v4 core below
# with new deterministic v5 additions (power/mass/thermal/soil budgets).
# See the docstring further down (after 'v5 ADDITIONS BEGIN') for why this
# was built on the verified v4 core rather than on the separately-drafted
# v5script.docx, which was found during this pass to hard-code an incorrect
# discrimination-to-detection depth ratio (0.858 instead of the correct 0.671).


# ======================= v5 ADDITIONS BEGIN =======================


import json
import math
from pathlib import Path

# ----------------------------------------------------------------------
# SECTION: System mass budget (manuscript v5, Table II-B1/B2/B3)
# ----------------------------------------------------------------------

COPPER_DENSITY_G_PER_CM3 = 8.96

# (mass per metre in g/m) for the wire gauges used in the manuscript's mass
# tables; these are the manuscript's own stated figures (not re-derived from
# first principles here), carried as named constants so the mass functions
# below are traceable to Table II-B1/B2 rather than to magic numbers.
WIRE_G_PER_M = {
    "14_litz": 50.1,
    "22": 20.2,
    "24": 15.9,
    "26": 12.7,
    "28": 8.0,
}


def winding_mass_kg(diameter_m: float, turns: int, g_per_m: float, is_square: bool = False) -> float:
    """Copper mass of one winding. Square loops (the 1.0 m x 1.0 m transmit
    coil) use perimeter = 4 x side; circular windings use pi x diameter."""
    length_per_turn = (4.0 * diameter_m) if is_square else (3.141592653589793 * diameter_m)
    length_m = turns * length_per_turn
    return length_m * g_per_m / 1000.0


def mass_budget_v4_spec() -> dict:
    """Table II-B1: copper mass at the (unrevised) v4 winding specification."""
    tx = winding_mass_kg(1.0, 6, WIRE_G_PER_M["14_litz"], is_square=True)
    outer = winding_mass_kg(1.2, 20, WIRE_G_PER_M["22"])
    bucking = winding_mass_kg(0.8, 45, WIRE_G_PER_M["22"])
    receive = winding_mass_kg(0.4, 200, WIRE_G_PER_M["26"])
    return {
        "transmit_kg": round(tx, 3),
        "gradiometer_outer_kg": round(outer, 3),
        "gradiometer_bucking_kg": round(bucking, 3),
        "gradiometer_receive_200T_kg": round(receive, 3),
        "copper_total_kg": round(tx + outer + bucking + receive, 3),
    }


def mass_budget_v5_revised() -> dict:
    """Table II-B2/B3: revised gradiometer (80-turn receive) and full system mass.
    NOTE (open item, carried from the manuscript's own caveat): the outer/bucking
    gauges are also thinned here (22->24, 22->26) alongside the receive-turn cut;
    that gauge change is NOT reflected in the SNR-penalty figure below, which only
    accounts for the turn-count reduction at fixed gauge. See the manuscript's
    Sec. II.B open-item note before treating the depth penalty as validated."""
    tx = winding_mass_kg(1.0, 6, WIRE_G_PER_M["14_litz"], is_square=True)
    outer = winding_mass_kg(1.2, 20, WIRE_G_PER_M["24"])
    bucking = winding_mass_kg(0.8, 45, WIRE_G_PER_M["26"])
    receive = winding_mass_kg(0.4, 80, WIRE_G_PER_M["28"])
    gradiometer_total = outer + bucking + receive

    frame = 1.50       # estimated, CFRP composite former
    electronics = 0.60  # estimated, PCB + heatsink
    battery = 1.05      # 100 Wh 4S LiPo pack, see power_budget()
    enclosure = 0.80    # estimated, cabling/connectors/housing

    depth_factor_turns_only = (80.0 / 200.0) ** (1.0 / 12.0)  # SNR ~ sqrt(N_rx); depth ~ SNR^(1/6)

    return {
        "gradiometer_outer_kg": round(outer, 3),
        "gradiometer_bucking_kg": round(bucking, 3),
        "gradiometer_receive_80T_kg": round(receive, 3),
        "gradiometer_total_kg": round(gradiometer_total, 3),
        "transmit_kg": round(tx, 3),
        "frame_kg": frame,
        "electronics_kg": electronics,
        "battery_kg": battery,
        "enclosure_kg": enclosure,
        "system_total_kg": round(tx + gradiometer_total + frame + electronics + battery + enclosure, 3),
        "depth_factor_from_turn_reduction_only": round(depth_factor_turns_only, 4),
        "open_item": "gauge changes on outer/bucking/receive not yet reflected in depth_factor above",
    }


# ----------------------------------------------------------------------
# SECTION: System power budget and adaptive PRF (manuscript v5, Table IV-C1/C2)
# ----------------------------------------------------------------------

L_TX_H = 185.4e-6
I_PK_A = 30.0
R_DSON_OHM = 0.075          # C3M0075120D
V_BUS_V = 14.8              # 4S LiPo
PRF_DEEP_HZ = 300.0
PRF_SCAN_HZ = 30.0


def ramp_time_s(L_h: float = L_TX_H, i_pk_a: float = I_PK_A, v_bus_v: float = V_BUS_V) -> float:
    """t_ramp = L * I_pk / V_bus, linear-ramp charging of the transmit inductor."""
    return L_h * i_pk_a / v_bus_v


def power_budget(prf_hz: float) -> dict:
    """Deterministic (non-Monte-Carlo) system power estimate at a given PRF.
    Reproduces the manuscript's Table IV-C1 exactly at prf_hz=300 and the
    Scan-Mode entries of Table IV-C2 at prf_hz=30."""
    t_ramp = ramp_time_s()
    t_fall_ref_s = 35.1e-6  # from the v4-verified RERS calc, unchanged in v5
    T_PRF = 1.0 / prf_hz
    duty = t_ramp / T_PRF

    p_rers = 0.5 * L_TX_H * I_PK_A ** 2 * prf_hz
    i_rms_sq_ramp = I_PK_A ** 2 / 3.0  # mean-square of a linear ramp over its own duration
    p_conduction = R_DSON_OHM * i_rms_sq_ramp * duty
    p_switching = 2.0 * (prf_hz / PRF_DEEP_HZ)  # scales with switching-event rate
    p_mosfet = p_conduction + p_switching

    fixed_loads = dict(gate_drivers=0.5, afe=0.15, adc_pi=0.025, adc_vlf=0.050,
                       mcu=0.5, edge_ai=2.0, display=0.3, misc=0.5)
    p_fixed = sum(fixed_loads.values())
    total = p_rers + p_mosfet + p_fixed

    return {
        "prf_hz": prf_hz,
        "t_ramp_ms": round(t_ramp * 1000, 4),
        "duty_pct": round(duty * 100, 3),
        "P_RERS_W": round(p_rers, 3),
        "P_MOSFET_conduction_W": round(p_conduction, 3),
        "P_MOSFET_switching_W": round(p_switching, 3),
        "P_MOSFET_total_W": round(p_mosfet, 3),
        "P_fixed_loads_W": round(p_fixed, 3),
        "P_system_total_W": round(total, 3),
    }


def adaptive_prf_summary(duty_scan: float = 0.9, duty_deep: float = 0.1,
                          battery_Wh: float = 100.0) -> dict:
    deep = power_budget(PRF_DEEP_HZ)
    scan = power_budget(PRF_SCAN_HZ)
    p_avg = duty_scan * scan["P_system_total_W"] + duty_deep * deep["P_system_total_W"]
    depth_factor_scan_vs_deep_same_dwell = (12.0 / 120.0) ** (1.0 / 6.0)  # N=12 @30Hz vs N=120 @300Hz, same 0.4s dwell
    return {
        "deep_search": deep,
        "scan": scan,
        "usage_profile": {"scan_duty": duty_scan, "deep_duty": duty_deep},
        "P_avg_W": round(p_avg, 3),
        "battery_Wh": battery_Wh,
        "runtime_mixed_h": round(battery_Wh / p_avg, 2),
        "runtime_scan_only_h": round(battery_Wh / scan["P_system_total_W"], 2),
        "runtime_deep_only_h": round(battery_Wh / deep["P_system_total_W"], 2),
        "depth_factor_scan_vs_deep_same_dwell": round(depth_factor_scan_vs_deep_same_dwell, 4),
    }


# ----------------------------------------------------------------------
# SECTION: Thermal analysis (manuscript v5, Table IV-D1)
# ----------------------------------------------------------------------

R_THETA_JC = 0.6   # degC/W, C3M0075120D TO-247
R_THETA_CS = 0.5   # degC/W, estimated thermal-interface term
R_THETA_SA = 6.5   # degC/W, Fischer SK129/50-class heatsink, natural convection
T_J_MAX = 175.0    # degC, device rating
T_AMB = 45.0       # degC, assumed worst-case ambient


def thermal_analysis(p_mosfet_w: float) -> dict:
    r_total = R_THETA_JC + R_THETA_CS + R_THETA_SA
    t_j = T_AMB + p_mosfet_w * r_total
    return {
        "P_MOSFET_W": round(p_mosfet_w, 3),
        "R_theta_total_C_per_W": r_total,
        "T_J_C": round(t_j, 2),
        "margin_to_Tmax_C": round(T_J_MAX - t_j, 2),
    }


# ----------------------------------------------------------------------
# SECTION: Reference soil profiles (manuscript v5, Table III-E1)
# literature-derived reference points only -- not simulated here
# ----------------------------------------------------------------------

SOIL_PROFILES = {
    "S1_low_mineralisation": {
        "chi_DC": 50e-6, "tau_s": 1e-4, "c": 0.5, "chi_pp_peak": 0.5e-4,
        "geology": "alluvial sand, temperate topsoil",
    },
    "S2_high_mineralisation": {
        "chi_DC": 500e-6, "tau_s": 1e-3, "c": 0.3, "chi_pp_peak": 8.0e-4,
        "geology": "laterite, weathered volcanic basalt",
    },
    "S3_saline_conductive": {
        "chi_DC": 100e-6, "tau_s": 1e-2, "c": 0.7, "chi_pp_peak": 2.0e-4,
        "geology": "coastal, salt-flat, irrigated clay",
    },
}


# ----------------------------------------------------------------------
# SECTION: AFE noise budget, v5 revised (manuscript Table IV, Revised)
# ----------------------------------------------------------------------

def afe_noise_budget_v5(transformer_ratio_n: float = 10.0, G1: float = 10.0, G2: float = 100.0) -> dict:
    coil_johnson = 0.14
    transformer_loss = 0.02
    jfet_referred = 1.80 / transformer_ratio_n
    inamp_referred = 1.00 / (transformer_ratio_n * G1)
    adc_referred = 4.0 / (transformer_ratio_n * G1 * G2)
    rss = (coil_johnson**2 + transformer_loss**2 + jfet_referred**2
           + inamp_referred**2 + adc_referred**2) ** 0.5
    v4_total = 0.191
    depth_factor = (v4_total / rss) ** (1.0 / 6.0)
    return {
        "coil_johnson_nV_sqrtHz": coil_johnson,
        "transformer_loss_nV_sqrtHz": transformer_loss,
        "jfet_referred_nV_sqrtHz": round(jfet_referred, 4),
        "inamp_referred_nV_sqrtHz": round(inamp_referred, 4),
        "adc_referred_nV_sqrtHz": round(adc_referred, 5),
        "rss_total_nV_sqrtHz": round(rss, 4),
        "v4_total_nV_sqrtHz": v4_total,
        "noise_increase_dB": round(20 * math.log10(rss / v4_total), 3),
        "depth_scaling_factor": round(depth_factor, 4),
    }




# ============================================================================
# SNR@1.5m first-principles cross-check (added: SNR@1.5m calibration pass)
# ----------------------------------------------------------------------------
# This does NOT replace Test 5 (the actual bench measurement) -- it computes
# an independent, first-principles physics estimate from parameters already
# stated elsewhere in this script/manuscript, to check whether the
# previously unjustified "assumed rho@1.5m in [5,200]" range is at least
# physically defensible. It is not a simulation (no random draws): every
# quantity is either a manuscript-stated constant or a textbook closed-form
# electromagnetic relation, cited inline.
#
# Formula source (verified): eddy-current-sphere induced dipole moment,
#   m_ec = (2*pi*a^3*B1/mu0) * j2(ka)/j0(ka),  high-freq/thin-skin limit
#   m_ec -> -2*pi*a^3*B1/mu0 as ka -> infinity,
# from an independent, citable closed-form (arXiv:2206.04631, Appendix B;
# cross-checked against its own reduced field-domain relation
# B_ec = -a^3*B1/r'^3, which the moment formula must and does reduce to --
# an earlier hand-derivation in this pass used the field-only form directly
# as if it were the moment, missing the 2*pi/mu0 factor; caught by this
# cross-check and corrected before being used anywhere below).
# Dominant-mode sphere decay time constant tau_1 = mu0*sigma*a^2/pi^2 is
# derived from the same formula's pole structure (root of j0(ka)=0 at ka=pi)
# and matches the standard UXO/EMI-detection forward-model literature.
# ============================================================================

MU0 = 4 * np.pi * 1e-7  # H/m
SPHERE_SIGMA_S_PER_M = {"copper": 5.96e7, "gold": 4.11e7, "bronze": 1.0e7}  # handbook values


def implied_target_radius_m(tau_s: float, sigma_s_per_m: float) -> float:
    """Sphere radius implied by a stated eddy-current decay time constant,
    tau_1 = mu0*sigma*a^2/pi^2 (dominant mode). Inverted for a."""
    return np.sqrt(tau_s * np.pi**2 / (MU0 * sigma_s_per_m))


def tx_field_at_target_T(N_tx: int, I_pk_a: float, area_tx_m2: float, r_m: float) -> float:
    """On-axis near-field magnetic-dipole approximation, B1 = mu0*m_coil/(2*pi*r^3) --
    the SAME approximation this project's r^-6 depth law is built on."""
    m_coil = N_tx * I_pk_a * area_tx_m2
    return MU0 * m_coil / (2 * np.pi * r_m**3)


def received_emf_V(a_m: float, tau_s: float, t_s: float, B1_T: float,
                    N_rx: int, area_rx_m2: float, r_m: float) -> float:
    """Monostatic received EMF at time t after cutoff (same coil transmits and
    receives -- standard single-coil PI topology), via Faraday's law on the
    target's decaying dipole moment m(t) = m(0)*exp(-t/tau)."""
    m0 = 2 * np.pi * a_m**3 * B1_T / MU0
    dmdt = (m0 / tau_s) * np.exp(-t_s / tau_s)
    return N_rx * area_rx_m2 * MU0 / (2 * np.pi * r_m**3) * dmdt


def snr_at_1p5m_first_principles(afe_noise_nV_per_rtHz: float = 0.229,
                                   bandwidths_hz=(100, 1000, 10000, 100000)) -> dict:
    """First-principles SNR@1.5m estimate. Uses ONLY this script's own
    already-stated coil constants (I_NOM_A, the 6-turn/1.0x1.0m transmit
    coil) plus the manuscript's own stated eddy-current decay tau values,
    at r=1.5 m (Test 5's own target depth), t=G2=100us (the manuscript's
    stated first gate)."""
    N_tx, area_tx, r_ref, G2 = 6, 1.0, 1.5, 100e-6
    B1 = tx_field_at_target_T(N_tx, I_NOM_A, area_tx, r_ref)
    tau_manuscript_s = {"copper": 0.1707, "gold": 0.1691, "bronze": 0.0286}
    out = {"B1_nT": round(B1 * 1e9, 3), "by_material": {}}
    for mat, tau_s in tau_manuscript_s.items():
        a_m = implied_target_radius_m(tau_s, SPHERE_SIGMA_S_PER_M[mat])
        v = received_emf_V(a_m, tau_s, G2, B1, N_tx, area_tx, r_ref)
        snrs = {f"{bw}Hz": round(v / (afe_noise_nV_per_rtHz * 1e-9 * np.sqrt(bw)), 2)
                for bw in bandwidths_hz}
        out["by_material"][mat] = {
            "implied_radius_mm": round(a_m * 1000, 1),
            "V_at_G2_nV": round(v * 1e9, 3),
            "SNR_by_bandwidth": snrs,
        }
    return out


def build_v5_results(base_results: dict, seed: int) -> dict:
    """Combine the (unchanged, already-verified) v4 stochastic results with
    the new v5 deterministic additions into one results object."""
    deep = power_budget(PRF_DEEP_HZ)
    out = dict(base_results)  # v4 content untouched
    out["v5_additions"] = {
        "mass_budget_v4_spec": mass_budget_v4_spec(),
        "mass_budget_v5_revised": mass_budget_v5_revised(),
        "power_budget": adaptive_prf_summary(),
        "thermal_deep_search": thermal_analysis(deep["P_MOSFET_total_W"]),
        "thermal_scan": thermal_analysis(power_budget(PRF_SCAN_HZ)["P_MOSFET_total_W"]),
        "ramp_time_ms": round(ramp_time_s() * 1000, 4),
        "afe_noise_budget_v5": afe_noise_budget_v5(),
        "soil_profiles": SOIL_PROFILES,
        "snr_1p5m_first_principles_crosscheck": snr_at_1p5m_first_principles(),
        "discrimination_ratio_note": (
            "UNCHANGED from v4: SNR_DET=3.0, SNR_DISC=33.0 (both linear, see core script), "
            "ratio (SNR_DET/SNR_DISC)**(1/6) = 0.6704 ~= 0.671. A proposed v5 revision to 0.858 "
            "(via an unreferenced +20 dB discrimination threshold) was reviewed and rejected "
            "during this pass; see manuscript Appendix Table A-1, item 7."
        ),
    }
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="h_fmd_sim_output_v5")
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    args = ap.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    results = {}
    results["meta"] = {
        "seed": args.seed,
        "status": "simulation_only",
        "critical_note": "Depth claims require measured Test-5 calibration and fitted exponent.",
        "version": "v5",
    }
    results["rers"] = rers_mc(seed=args.seed)
    results["classification_baseline_error_pct"] = (1 - classification_once(0.03, 6.0, 400, args.seed)) * 100
    results["classification_matched_snr_error_pct"] = (1 - classification_once(0.03, 1.74, 400, args.seed)) * 100
    results["classification_table_I"] = {}
    for label, sigma_phi in [("6.0deg_conservative", 6.0), ("1.74deg_snr_matched", 1.74)]:
        per_class, overall_err, _, _ = classification_breakdown(0.03, sigma_phi, 400, args.seed)
        cluster = cluster_error_metrics(0.03, sigma_phi, 400, args.seed)
        results["classification_table_I"][label] = {
            "per_class_accuracy": per_class,
            "overall_error_pct": round(overall_err, 4),
            "non_ferrous_pooled_error_pct": cluster["candidate_C_nonferrous_pooled_pct__MATCHES_PUBLISHED"],
        }
    results["depth_sensitivity"] = depth_sensitivity()
    results["contamination"] = {
        str(c): contamination_sim(c, defense=False, seed=args.seed + 10)
        for c in (0.0, 0.01, 0.05, 0.10, 0.20)
    }
    results["anomaly_gate"] = {
        str(c): contamination_sim(c, defense=True, seed=args.seed + 200)
        for c in (0.05, 0.10, 0.20)
    }

    # v5: append new deterministic subsystem budgets (mass/power/thermal/AFE/soil)
    results = build_v5_results(results, args.seed)

    with open(out / "results_v5.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
