import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

FIG = "/home/claude/sims/figs"
rng = np.random.default_rng(20260813)
plt.rcParams.update({"figure.dpi": 170, "axes.grid": True, "grid.alpha": 0.3, "font.size": 10})

with open("/home/claude/sims/results.json") as f:
    R = json.load(f)

R2 = {}

# =====================================================================
# FIX A — matched-SNR phase noise re-run of the classification floor
# =====================================================================
centroids = {
    "Iron":   (0.112, -30.0),
    "Bronze": (0.759,  25.0),
    "Gold":   (0.954,  58.0),
    "Copper": (0.955,  62.0),
}
classes = list(centroids.keys())

def simulate_classification(sigma_R, sigma_phi_deg, n_per_class=400, seed=None):
    rr = np.random.default_rng(seed)
    Xs, ys = [], []
    for c in classes:
        Rc, Pc = centroids[c]
        Rv = rr.normal(Rc, sigma_R, n_per_class)
        P = rr.normal(Pc, sigma_phi_deg, n_per_class)
        Xs.append(np.column_stack([Rv, P]))
        ys += [c] * n_per_class
    X = np.vstack(Xs); y = np.array(ys)
    Cmat = np.array([[centroids[c][0], centroids[c][1] / 90.0] for c in classes])
    Xn = np.column_stack([X[:, 0], X[:, 1] / 90.0])
    d2 = ((Xn[:, None, :] - Cmat[None, :, :]) ** 2).sum(axis=2)
    pred = np.array(classes)[d2.argmin(axis=1)]
    return X, y, pred, (pred == y).mean()

# original (conservative) baseline: 3% / 6deg
_, y0, pred0, acc0 = simulate_classification(0.03, 6.0, 400, seed=1)
# amplitude-consistent matched pair at SNR=33: eps=1/33 -> phase = 1/33 rad = 1.736 deg
matched_phase_deg = np.degrees(1.0 / 33.0)
_, y1, pred1, acc1 = simulate_classification(0.03, matched_phase_deg, 400, seed=1)

R2["fixA_matched_phase"] = {
    "matched_phase_deg": float(matched_phase_deg),
    "conservative_overall_err_pct": float((1 - acc0) * 100),
    "matched_overall_err_pct": float((1 - acc1) * 100),
    "conservative_bgc_err_pct": float((1 - (pred0[y0 != "Iron"] == y0[y0 != "Iron"]).mean()) * 100),
    "matched_bgc_err_pct": float((1 - (pred1[y1 != "Iron"] == y1[y1 != "Iron"]).mean()) * 100),
}

# =====================================================================
# FIX B — corrected Table 5 replacement: full N x SNR15 grid, p=6 fixed
# =====================================================================
def depth_at_threshold(snr_ref, p, snr_th, Navg=1):
    return 1.5 * (snr_ref * np.sqrt(Navg) / snr_th) ** (1.0 / p)

N_list = [1, 6, 29, 120, 423]
dwell_s = {1: "instant", 6: "0.02 s", 29: "0.10 s", 120: "0.40 s", 423: "1.41 s"}
snr15_list = [5, 10, 20, 50, 100, 200]
table5_fix = []
for N in N_list:
    row = {"N": N, "dwell": dwell_s[N]}
    for s in snr15_list:
        row[f"det_{s}"] = round(depth_at_threshold(s, 6, 3, N), 2)
        row[f"disc_{s}"] = round(depth_at_threshold(s, 6, 33, N), 2)
    table5_fix.append(row)
R2["fixB_table5"] = table5_fix

# =====================================================================
# FIX C — tightened RERS C_clamp tolerance (was +-10%, try +-5%)
# =====================================================================
N2 = 300_000
L = rng.uniform(185 * 0.85, 185 * 1.15, N2) * 1e-6
C_10 = rng.uniform(672 * 0.90, 672 * 1.10, N2) * 1e-9
C_5 = rng.uniform(672 * 0.95, 672 * 1.05, N2) * 1e-9
Ipk = rng.uniform(30 * 0.95, 30 * 1.05, N2)

Vc10 = Ipk * np.sqrt(L / C_10)
Vc5 = Ipk * np.sqrt(L / C_5)

R2["fixC_rers_tightened"] = {
    "Vclamp_p95_C10pct": float(np.percentile(Vc10, 95)),
    "Vclamp_max_C10pct": float(Vc10.max()),
    "Vclamp_p95_C5pct": float(np.percentile(Vc5, 95)),
    "Vclamp_max_C5pct": float(Vc5.max()),
    "margin_to_620_C10pct_pct": float((620 - Vc10.max()) / 620 * 100),
    "margin_to_620_C5pct_pct": float((620 - Vc5.max()) / 620 * 100),
}

fig, ax = plt.subplots(figsize=(7, 4.3))
ax.hist(Vc10, bins=130, alpha=0.55, color="#b7791f", label="C_clamp ±10% (original)")
ax.hist(Vc5, bins=130, alpha=0.55, color="#2f855a", label="C_clamp ±5% (tightened, recommended)")
ax.axvline(600, color="#c53030", ls="--", lw=1.4, label="Test-2 PASS bar, 600V")
ax.axvline(620, color="#553c9a", ls="--", lw=1.4, label="driver rating, 620V")
ax.set_xlabel("V_clamp (V)"); ax.set_ylabel("draws")
ax.set_title("Effect of tightening C_clamp tolerance on worst-case clamp voltage")
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(f"{FIG}/fixC_tightened_tolerance.png")
plt.close(fig)

# =====================================================================
# FIX D — gradiometer sensitivity, grounded in cited d^3 coupling law
# (US9989663B1, already in Document 1's own prior-art table: coupling
#  between concentric coils scales approximately as diameter^3)
# =====================================================================
# first-order: d(ln coupling)/d(ln diameter) ~ 3  =>  fractional coupling
# error ~ 3 * fractional geometric perturbation, for small perturbations.
k_sens = 3.0
pert_fracs = np.array([0.001, 0.002, 0.005, 0.01, 0.02, 0.05])  # 0.1%-5% geometric error
residual_frac = k_sens * pert_fracs
null_depth_db = -20 * np.log10(residual_frac)

R2["fixD_gradiometer"] = {
    "sensitivity_coefficient": k_sens,
    "source": "US9989663B1 (Document 1 prior-art table): coupling ~ diameter^3",
    "pert_fracs_pct": (pert_fracs * 100).tolist(),
    "null_depth_db": null_depth_db.round(1).tolist(),
    "position_mm_for_1.2m_coil": (pert_fracs * 1200).round(2).tolist(),  # mm, for 1.2m TX coil
}

fig, ax = plt.subplots(figsize=(7, 4.3))
ax.plot(pert_fracs * 100, null_depth_db, marker="o", color="#2c5282")
ax.axhline(40, color="#c53030", ls="--", lw=1.3, label="Document 2 Test 7 PASS bar, 40 dB")
ax.set_xscale("log")
ax.set_xlabel("Fractional geometric perturbation (%, log scale)")
ax.set_ylabel("Implied null depth (dB)")
ax.set_title("Gradiometer null depth vs. geometric tolerance\n(first-order, coupling∝diameter³ per cited prior art)", fontsize=10.5)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(f"{FIG}/fixD_gradiometer_sensitivity.png")
plt.close(fig)

with open("/home/claude/sims/results2.json", "w") as f:
    json.dump(R2, f, indent=2)

print(json.dumps(R2, indent=2))
