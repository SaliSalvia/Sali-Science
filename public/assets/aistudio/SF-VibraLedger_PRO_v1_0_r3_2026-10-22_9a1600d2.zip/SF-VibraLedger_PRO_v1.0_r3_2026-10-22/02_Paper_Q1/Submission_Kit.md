# Journal Submission Kit (draft)

**Hold rule:** do not submit, post to a preprint server, or present until the patent priority application is filed. Add real-data results first (Section "Real-data requirement").

## Highlights (≤ 85 characters each)
* Separates authority to change a reference from classification.
* Trust budget, evidence gate, drift envelope, hash-chained audit log.
* Integer-only, heap-free C core; deterministic, sanitizer-tested.
* Honest limits: self-training can hurt; the gate does not filter poison.

## Cover letter (template)
Dear Editor, we submit "Bounded-Authority Adaptation for Integer-Only Edge Condition Monitoring…" for consideration in *[journal]*. The manuscript presents an integer-only monitoring stack whose on-device adaptation is bounded by corroborating evidence, a decaying trust budget and a cumulative-drift envelope, with an authenticated model lifecycle, and it reports both positive and negative results on simulated vibration and public data, and — [after you add them] — on public bearing recordings. All code, tests and result files are available. No part of the work has been published or is under review elsewhere. A patent application on the described mechanisms [has been filed / is planned]. AI assistance is disclosed in the Declarations. Sincerely, [author].

## Journal shortlist (verify scope, current quartile and APC yourself — they change every year)
| Journal | Fit | Note |
|---|---|---|
| IEEE Sensors Journal | sensing + edge processing | usually accepts simulation + public-data papers if the method is clear |
| IEEE Trans. Instrumentation and Measurement | measurement systems, condition monitoring | expects careful validation |
| Measurement (Elsevier) | condition monitoring methods | broad |
| Sensors (MDPI) | applied sensing, fast review | check current indexing/quartile; APC applies |
| Mechanical Systems and Signal Processing | strongest venue for vibration | expects real-machine or standard benchmark data — add CWRU + at least one more public set |
| IEEE Trans. Industrial Informatics | industrial AI systems | expects industrial validation |
| Engineering Applications of AI / Reliability Engineering & System Safety | AI for industry / safety | broader validation expected |

## Real-data requirement (do this before submitting anywhere)
1. Download public bearing data (e.g. CWRU): normal baselines at each load, and several fault files of the same sampling rate.
2. `python3 04_Validation/tools/cwru_experiment.py --normal 97.mat 98.mat 99.mat 100.mat --fault 105.mat --fault 118.mat --fault 130.mat --fs 12000 --window 2048`
3. Add the printed false-alert rate, alert rate and latency (SF-VibraLedger vs RMS alarm level) to Section 5 as a new table and update the abstract. The harness was **not** run on real data by the package author; only its code path was tested on synthetic files. If the result is unfavourable, report it.

## Submission checklist
- [ ] Priority application filed (date/number recorded)
- [ ] Real-data results added; abstract/conclusion updated
- [ ] Every reference verified against the publisher; formatting per journal
- [ ] Figures at journal resolution; charts labelled SIMULATED / PUBLIC DATA
- [ ] AI-assistance statement per journal policy; ORCID complete
- [ ] Data/code availability statement matches what you actually publish (publishing code after filing is fine)
- [ ] Conflict-of-interest statement mentions the patent
- [ ] Plagiarism / similarity check
