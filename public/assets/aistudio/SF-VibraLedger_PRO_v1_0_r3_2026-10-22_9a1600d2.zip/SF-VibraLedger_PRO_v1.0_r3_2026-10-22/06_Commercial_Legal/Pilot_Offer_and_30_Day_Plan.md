# Pilot Offer and 30-Day Plan

*Nothing here is a promise of results. Do not quote ROI, avoided downtime or accuracy on the customer's machine until measured on it.*

## Offer ladder
| Stage | What the customer gets | Customer effort | Your effort |
|---|---|---|---|
| A. Paid recording evaluation | Window-by-window status timeline + written report from **their** CSV log(s), run locally under NDA | export 1 healthy + 1 event recording | 1–2 days |
| B. Paid pilot (2–4 weeks) | Continuous or periodic logs from one asset class; weekly findings; acceptance metrics agreed in writing | data access, a contact in maintenance | days per week |
| C. Site licence / OEM | per site or asset band; support terms | integration | scoped |

Price by the customer's alternative cost (an outside vibration analyst's visit; an imported condition-monitoring system), not by your cost.

## Acceptance metrics to agree in writing (stage B)
False alerts per 1000 healthy windows; missed events; detection latency; behaviour across load/speed/temperature; TRANSIENT (sensor-quality) handling; restart/recovery; operator usefulness. State that failure to meet them is a valid pilot outcome.

## 30-day plan
| Days | Action |
|---|---|
| 1–3 | Trademark check on the product name; attorney review; **file the priority application** |
| 3–5 | List 30 targets: maintenance/reliability managers in plants with many motors, pumps, fans; vibration-service companies; PdM integrators |
| 5–10 | Send 5 tailored messages/day with the one-page sheet (no source, no binaries); offer stage A; NDA on request |
| 10–20 | Run 2–3 stage-A evaluations; **ask each customer for permission to use anonymised results** |
| 15–25 | Run the public-data harness (`04_Validation/tools/cwru_experiment.py`) and add the results to the paper |
| 20–30 | Convert the best stage-A into a stage-B proposal with acceptance metrics; submit the paper after the filing |

## Data handling promise (say it, and mean it)
The tool runs on your computer; the customer's file is not uploaded, copied to third parties, or used for anything except the agreed evaluation; delete after the engagement on request.

## Outreach templates
**EN.** Subject: *Local, no-upload evaluation of your motor/pump vibration logs.* — "We evaluate a small deterministic monitoring engine on customers' own vibration recordings, locally and under NDA. Send one healthy recording and one recording around a known event; you receive a window-by-window status timeline and a short report. The engine learns your load modes and reports where it is blind (it is not yet validated on your machine class). 20-minute call?"

**FA.** موضوع: *ارزیابی محلی و بدون ارسال داده‌ی لاگ ارتعاش موتور/پمپ شما.* — «ما یک موتور پایش کوچک و قطعی را روی ضبط‌های ارتعاش خودِ مشتری، محلی و تحت NDA ارزیابی می‌کنیم. یک ضبط سالم و یک ضبط اطراف رویدادی شناخته‌شده بدهید؛ جدول زمانی وضعیت هر پنجره و گزارش کوتاه می‌گیرید. این موتور حالت‌های بار شما را یاد می‌گیرد و می‌گوید کجا کور است (هنوز روی رده‌ی ماشین شما اعتبارسنجی نشده). یک تماس ۲۰ دقیقه‌ای؟»
