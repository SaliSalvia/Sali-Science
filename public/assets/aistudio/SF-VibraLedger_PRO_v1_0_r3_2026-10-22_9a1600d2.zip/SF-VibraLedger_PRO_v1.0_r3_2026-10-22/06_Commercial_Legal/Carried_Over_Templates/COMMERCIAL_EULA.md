# SF-VibraLedger Commercial Evaluation / Pilot Terms — Draft

## Purpose
SF-VibraLedger is an industrial edge-intelligence software technology for streaming sensor analytics and controlled adaptive classification.

## Evaluation
A customer may receive a time-limited evaluation build solely to assess technical suitability in a controlled environment.

## Pilot
A paid pilot should define: equipment/assets covered, sensors, installation scope, test duration, acceptance metrics, data ownership, support, cybersecurity requirements, and permitted deployment targets.

## Production License
Production use requires a separate written license covering device count, sites, term, support, updates, and permitted integrations.

## Safety
SF-VibraLedger is an analytics and decision-support component. It must not be treated as a safety-rated protection system unless separately engineered, certified, and accepted for that purpose.

## IP
Source code, documentation, model-lifecycle mechanisms, and related know-how remain subject to the rights of the rights holder and applicable agreements.

## Disclaimer
No warranty of field performance, maintenance savings, uptime improvement, or fault-detection coverage is made by this document. Such metrics must be established by application-specific validation.
