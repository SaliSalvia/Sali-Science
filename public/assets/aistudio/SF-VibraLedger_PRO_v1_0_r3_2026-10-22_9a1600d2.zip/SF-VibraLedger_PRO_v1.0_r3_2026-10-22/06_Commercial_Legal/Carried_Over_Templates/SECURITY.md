# Security Policy

## Scope
Security-sensitive components include authenticated model serialization, generation rollback protection, learning-token validation, feature-fingerprint binding, and bounded model lifecycle operations.

## Reporting
For responsible disclosure, contact the project security owner through the private project channel. Do not publicly disclose exploitable details before coordinated remediation.

## Deployment
Production deployments should use unique device credentials, protected key storage where available, signed/authenticated model packages, secure update procedures, access control, logging, and independent penetration testing appropriate to the deployment.

## Current evidence
The included host validation covers functional security checks, malformed-wire mutation fuzzing, and sanitizer-based testing. It is not a substitute for a production security assessment or hardware-in-the-loop penetration test.
