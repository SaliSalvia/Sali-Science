Templates carried over from the previous master package (2026-09-18) WITHOUT legal review in this session.
Have a lawyer review the NDA, trial agreement and licence before use. Names/versions inside may refer to earlier product names.
