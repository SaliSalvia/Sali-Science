# SF-VibraLedger Paid Pilot — Offer Template

## Objective
Deploy SF-VibraLedger on a defined industrial asset population and measure whether the edge engine can produce useful early deviation signals while rejecting low-quality sensor conditions.

## Pilot scope
- 1–5 representative machines;
- 2–6 sensor channels per machine where available;
- commissioning healthy baseline;
- controlled data collection and event labeling;
- edge inference and evidence logging;
- agreed success metrics.

## Metrics
- detection latency;
- false-positive rate;
- false-negative rate where labels exist;
- sensor-fault rejection rate;
- coverage / blocked-decision rate;
- CPU, RAM, Flash and power on target hardware;
- stability over the agreed observation period.

## Commercial conversion
Pilot → annual site license → multi-site deployment → OEM/SDK licensing.
