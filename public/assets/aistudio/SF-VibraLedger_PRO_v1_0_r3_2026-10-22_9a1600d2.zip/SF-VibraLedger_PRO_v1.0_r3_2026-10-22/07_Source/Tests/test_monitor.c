#include "SFVibraLedger_Commission.h"
#include "test_common.h"
#include <string.h>
enum { D = 6 };
static const double MODE_CTR[3][D] = {{0,0,0,0,0,0},{300,250,0,0,300,0},{650,600,0,0,650,0}};
static const double SD[D] = {30,30,100,100,30,100};
static void gen(int mode, double drift, const double *shift, int32_t *out) { for (int d = 0; d < D; ++d) out[d] = (int32_t)llround(5000.0 + MODE_CTR[mode][d] + drift + (shift ? shift[d] : 0.0) + SD[d] * tc_gauss()); }
static SFVLM_Monitor *commissioned(void) {
    static SFVLM_Monitor mon; static int32_t F[150 * D]; static uint16_t Q[150]; const uint8_t key[16] = "monitor-test-key";
    CHECK(SFVLM_Init(&mon, D, 1, 4, NULL, key, 16) == 0);
    for (int i = 0; i < 150; ++i) { gen((i / 10) % 3, 0, NULL, &F[i * D]); Q[i] = 1024; }
    SFVLC_Report rep; CHECK(SFVLC_Commission(&mon, F, Q, 150, NULL, &rep) == 0); CHECK(rep.ok && rep.modes == 3);
    printf("commissioned: modes=%u used=%u thr_radius=%u/%u/%u\n", rep.modes, rep.used_windows, rep.threshold_radius[0], rep.threshold_radius[1], rep.threshold_radius[2]);
    return &mon;
}
int main(void) {
    tc_s = 42; SFVLM_Monitor *mon = commissioned(); SFVLM_Output o; int32_t v[D]; int mode = 0; unsigned warn = 0, alarm = 0, learned = 0;
    for (int t = 0; t < 3000; ++t) { if (t % 100 == 0) mode = (int)(tc_u32() % 3u); gen(mode, 0, NULL, v); CHECK(SFVLM_Update(mon, v, 1024, &o) == 0); warn += (o.status >= SFVLM_WARNING); alarm += (o.status == SFVLM_ALARM); learned += o.learned; }
    printf("stationary 3000 windows: warning+=%u alarm=%u learned=%u\n", warn, alarm, learned); CHECK(alarm == 0); CHECK(warn <= 30); CHECK(learned > 100);
    /* moderate fault (8 sigma on two dims, mode 1) is flagged within a few windows and clears after removal */
    double sh[D] = {240, 240, 0, 0, 0, 0}; int det = -1;
    for (int t = 0; t < 30; ++t) { gen(1, 0, sh, v); CHECK(SFVLM_Update(mon, v, 1024, &o) == 0); if (det < 0 && o.status >= SFVLM_WARNING) det = t; }
    printf("moderate fault detected after %d windows (status %d)\n", det, (int)o.status); CHECK(det >= 0 && det <= 6);
    int cleared = -1; for (int t = 0; t < 40; ++t) { gen(1, 0, NULL, v); CHECK(SFVLM_Update(mon, v, 1024, &o) == 0); if (cleared < 0 && o.status == SFVLM_HEALTHY) cleared = t; }
    printf("status cleared after %d healthy windows\n", cleared); CHECK(cleared >= 0 && cleared <= 12);
    /* severe fault -> ALARM */
    double big[D] = {3000, 3000, 3000, 0, 0, 0}; int alarmed = -1; for (int t = 0; t < 12; ++t) { gen(2, 0, big, v); CHECK(SFVLM_Update(mon, v, 1024, &o) == 0); if (alarmed < 0 && o.status == SFVLM_ALARM) alarmed = t; }
    CHECK(alarmed >= 0 && alarmed <= 6); for (int t = 0; t < 40; ++t) { gen(2, 0, NULL, v); (void)SFVLM_Update(mon, v, 1024, &o); }
    /* low sensor quality: judge nothing, learn nothing */
    uint32_t g0 = mon->model.generation; for (int t = 0; t < 30; ++t) { gen(0, 0, big, v); CHECK(SFVLM_Update(mon, v, 400, &o) == 0); CHECK(o.status == SFVLM_TRANSIENT && o.learned == 0); }
    CHECK(mon->model.generation == g0);
    /* audit chain: verifies with the key, detects tampering and a wrong key */
    const uint8_t key[16] = "monitor-test-key"; CHECK(SFVLAL_Count(&mon->audit) > 0); CHECK(SFVLAL_Verify(&mon->audit, key, 16) == 0);
    CHECK(SFVLAL_Verify(&mon->audit, (const uint8_t *)"wrong-key-000000", 16) != 0);
    mon->audit.entries[0].evidence_mask ^= 0x55u; CHECK(SFVLAL_Verify(&mon->audit, key, 16) != 0);
    /* cumulative drift envelope: slow monotonic drift is followed by adaptation until the envelope, then frozen + flagged */
    tc_s = 43; mon = commissioned(); uint32_t gen_at_limit = 0; int limit_at = -1; mode = 0;
    for (int t = 0; t < 12000; ++t) { if (t % 100 == 0) mode = (int)(tc_u32() % 3u); gen(mode, 0.02 * t, NULL, v); CHECK(SFVLM_Update(mon, v, 1024, &o) == 0);
        if (limit_at < 0 && o.status == SFVLM_DRIFT_LIMIT) { limit_at = t; gen_at_limit = mon->model.generation; } }
    printf("drift envelope reached at window %d (generation frozen at %u -> final %u)\n", limit_at, gen_at_limit, mon->model.generation);
    CHECK(limit_at >= 0); CHECK(o.status == SFVLM_DRIFT_LIMIT || o.status == SFVLM_WARNING || o.status == SFVLM_ALARM);
    printf("MONITOR PASS\n"); return 0;
}
