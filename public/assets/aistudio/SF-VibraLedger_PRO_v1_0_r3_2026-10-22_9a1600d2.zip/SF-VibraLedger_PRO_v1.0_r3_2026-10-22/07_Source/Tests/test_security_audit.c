#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void setup(SFVL_Model *m, int32_t *norm){
    SFVL_Init(m,4,2,2);
    int32_t raw[4]={100,200,300,400};
    for(uint8_t d=0;d<4;d++) assert(SFVL_SetNormalizationReference(m,d,100,100)==0);
    assert(SFVL_Normalize(m,raw,norm)==0);
    assert(SFVL_SeedPrototype(m,0,0,norm,256,8)==0);
}
int main(void){
    SFVL_Model m; int32_t norm[4]; setup(&m,norm);
    SFVL_Result r; uint32_t g0=m.generation;
    for(int i=0;i<16;i++) assert(SFVL_Process(&m,norm,1024,&r)==SFVL_STATUS_SUCCESS);
    assert(r.predicted_class==0 && r.trust_q>0);
    if(r.learn_eligible){ assert(SFVL_FeedbackLearnGated(&m,&r.token,norm)==0); assert(m.generation>g0); assert(SFVL_FeedbackLearnGated(&m,&r.token,norm)!=0); }
    SFVL_Result low; assert(SFVL_Process(&m,norm,0,&low)==SFVL_STATUS_SUCCESS); assert(low.learn_eligible==0);
    int32_t far[4]={10000,10000,10000,10000}; SFVL_Result unk; assert(SFVL_Process(&m,far,1024,&unk)==SFVL_STATUS_BLOCKED); assert(unk.status==SFVL_STATUS_BLOCKED);
    uint8_t key[32], buf[10000]; for(int i=0;i<32;i++)key[i]=(uint8_t)i;
    size_t n=SFVL_WireSerialize(&m,SFVL_WIRE_CAP_CORE|SFVL_WIRE_CAP_EVIDENCE_GATE|SFVL_WIRE_CAP_UNKNOWN_POOL|SFVL_WIRE_CAP_CONTEXT_CAL|SFVL_WIRE_CAP_TRUST_LEDGER,key,32,buf,sizeof(buf)); assert(n>0);
    SFVL_WireStore st; SFVL_WireStoreInit(&st,&m); assert(SFVL_WireStageToStore(buf,n,key,32,&st)==SFVL_WIRE_ROLLBACK_ERR);
    SFVL_Model old=st.slot[0]; if(old.generation)old.generation--; SFVL_WireStoreInit(&st,&old); assert(SFVL_WireStageToStore(buf,n,key,32,&st)==SFVL_WIRE_OK);
    buf[n-1]^=0x80u; assert(SFVL_WireStageToStore(buf,n,key,32,&st)==SFVL_WIRE_AUTH_ERR);
    printf("FINAL_SECURITY_FUNCTIONAL_AUDIT PASS\n"); return 0;
}
