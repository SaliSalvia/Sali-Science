/* Stability test: under a stationary healthy stream the acceptance boundary must not shrink
 * as learning proceeds. NOTE: this test alone does NOT discriminate the BUG-2 fix (pre-fix ratio 0.963 vs 0.967);
 * the discriminating evidence is the 30-seed A/B in Validation/BUGFIX_REPORT.md. */
#include "SFVibraLedger_Core.h"
#include "test_common.h"
int main(void) {
    enum { D = 15 }; tc_s = 777; SFVL_Model m; SFVL_Init(&m, D, 1, 1);
    for (uint8_t d = 0; d < D; ++d) CHECK(SFVL_SetNormalizationReference(&m, d, 0, 1024) == 0);
    int32_t ctr[D] = {0}; uint32_t scl[D]; for (int d = 0; d < D; ++d) scl[d] = 820;             /* mean |dev| of N(0,1024) */
    SFVL_Prototype tmp; (void)tmp;
    CHECK(SFVL_SeedPrototypeFull(&m, 0, 0, ctr, scl, 1, 0, 200) == 0);
    /* measure commissioned radius statistics exactly as the commissioning tool does */
    double rs = 0, ra = 0; enum { N0 = 300 }; double rad[N0];
    for (int i = 0; i < N0; ++i) { int32_t x[D]; for (int d = 0; d < D; ++d) x[d] = (int32_t)(tc_gauss() * 1024.0); rad[i] = sqrt((double)SFVL_DistanceSq(&m, &m.proto[0][0], x)); rs += rad[i]; }
    rs /= N0; for (int i = 0; i < N0; ++i) ra += fabs(rad[i] - rs); ra /= N0;
    CHECK(SFVL_SeedPrototypeFull(&m, 0, 0, ctr, scl, (uint32_t)(rs * 1.1), (uint32_t)(ra * 1.1), 200) == 0);
    uint64_t thr0 = m.proto[0][0].threshold_sq; SFVL_Result r; int updates = 0;
    for (int i = 0; i < 12000; ++i) { int32_t x[D]; for (int d = 0; d < D; ++d) x[d] = (int32_t)(tc_gauss() * 1024.0); (void)SFVL_Process(&m, x, 1024, &r); if (r.learn_eligible && SFVL_FeedbackLearnGated(&m, &r.token, x) == 0) ++updates; }
    double shrink = sqrt((double)m.proto[0][0].threshold_sq) / sqrt((double)thr0);
    int acc = 0, N = 4000; for (int i = 0; i < N; ++i) { int32_t x[D]; for (int d = 0; d < D; ++d) x[d] = (int32_t)(tc_gauss() * 1024.0); (void)SFVL_Process(&m, x, 1024, &r); acc += (r.status == SFVL_STATUS_SUCCESS); }
    printf("updates=%d radius ratio after/before=%.3f fresh acceptance=%.4f\n", updates, shrink, (double)acc / N);
    CHECK(updates > 200); CHECK(shrink > 0.90); CHECK((double)acc / N > 0.97);
    printf("BOUNDARY_STABILITY PASS\n"); return 0;
}
