/* Claim-8 support: ONE monotonic generation counter is shared by local learning and by authenticated remote updates. */
#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include "test_common.h"
#include <string.h>
int main(void) {
    const uint8_t key[32] = "0123456789abcdef0123456789abcdef"; const uint32_t caps = SFVL_WIRE_CAP_CORE | SFVL_WIRE_CAP_EVIDENCE_GATE | SFVL_WIRE_CAP_UNKNOWN_POOL | SFVL_WIRE_CAP_CONTEXT_CAL | SFVL_WIRE_CAP_TRUST_LEDGER;
    SFVL_Model m; SFVL_Init(&m, 4, 2, 2); int32_t norm[4], raw[4] = {100, 200, 300, 400};
    for (uint8_t d = 0; d < 4; d++) CHECK(SFVL_SetNormalizationReference(&m, d, 100, 100) == 0);
    CHECK(SFVL_Normalize(&m, raw, norm) == 0); CHECK(SFVL_SeedPrototype(&m, 0, 0, norm, 256, 8) == 0);
    SFVL_Result r; int ok = 0; for (int i = 0; i < 40 && !ok; ++i) { CHECK(SFVL_Process(&m, norm, 1024, &r) == SFVL_STATUS_SUCCESS); ok = r.learn_eligible; } CHECK(ok);
    SFVL_LearnToken tok = r.token;
    /* (1) a token issued before an authenticated remote update is void after it */
    SFVL_Model newer = m; newer.generation = m.generation + 5u; uint8_t buf[SFVL_WIRE_MAX_LEN]; size_t n = SFVL_WireSerialize(&newer, caps, key, 32, buf, sizeof(buf)); CHECK(n > 0);
    SFVL_WireStore st; SFVL_WireStoreInit(&st, &m); CHECK(SFVL_WireStageToStore(buf, n, key, 32, &st) == SFVL_WIRE_OK);
    SFVL_Model activated = *SFVL_WireStoreActive(&st); CHECK(activated.generation == m.generation + 5u);
    CHECK(SFVL_FeedbackLearnGated(&activated, &tok, norm) == -2);
    /* (2) an envelope older than a local learning update is refused (rollback protection sees the shared counter) */
    SFVL_Model snapshot = m; uint8_t old_env[SFVL_WIRE_MAX_LEN]; size_t n_old = SFVL_WireSerialize(&snapshot, caps, key, 32, old_env, sizeof(old_env)); CHECK(n_old > 0);
    CHECK(SFVL_FeedbackLearnGated(&m, &tok, norm) == 0);                       /* local update advances the counter */
    SFVL_WireStore st2; SFVL_WireStoreInit(&st2, &m); CHECK(SFVL_WireStageToStore(old_env, n_old, key, 32, &st2) == SFVL_WIRE_ROLLBACK_ERR);
    CHECK(SFVL_WireStoreActive(&st2)->generation == m.generation);           /* active model untouched */
    /* (3) an envelope with a strictly greater generation is accepted, a tampered or wrong-key one is not */
    SFVL_Model up = m; up.generation = m.generation + 1u; size_t n_up = SFVL_WireSerialize(&up, caps, key, 32, buf, sizeof(buf)); CHECK(n_up > 0);
    uint8_t bad[SFVL_WIRE_MAX_LEN]; memcpy(bad, buf, n_up); bad[SFVL_WIRE_HEADER_LEN + 3] ^= 0x01u;
    SFVL_WireStore st3; SFVL_WireStoreInit(&st3, &m); CHECK(SFVL_WireStageToStore(bad, n_up, key, 32, &st3) == SFVL_WIRE_AUTH_ERR);
    const uint8_t other[32] = "ffffffffffffffffffffffffffffffff"; CHECK(SFVL_WireStageToStore(buf, n_up, other, 32, &st3) == SFVL_WIRE_AUTH_ERR);
    CHECK(SFVL_WireStoreActive(&st3)->generation == m.generation);
    CHECK(SFVL_WireStageToStore(buf, n_up, key, 32, &st3) == SFVL_WIRE_OK); CHECK(SFVL_WireStoreActive(&st3)->generation == m.generation + 1u);
    printf("GENERATION_COUPLING PASS\n"); return 0;
}
