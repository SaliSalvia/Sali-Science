/* Regression test for BUG-1: a promoted unknown-state prototype must accept the samples that formed it. */
#include "SFVibraLedger_Core.h"
#include "test_common.h"
int main(void) {
    const double noise[2] = {100.0, 300.0}; const double need[2] = {0.98, 0.70};   /* pre-fix acceptance was 99.4% / 17.2% */
    for (int k = 0; k < 2; ++k) {
        tc_s = 1234; SFVL_Model m; SFVL_Init(&m, 4, 2, 2); int32_t z[4] = {0, 0, 0, 0}; CHECK(SFVL_SeedPrototype(&m, 0, 0, z, 256, 32) == 0);
        int32_t c[4] = {6000, -5000, 4000, 7000}; SFVL_Result r;
        for (int i = 0; i < 200; ++i) { int32_t x[4]; for (int d = 0; d < 4; ++d) x[d] = c[d] + (int32_t)(tc_gauss() * noise[k]); (void)SFVL_Process(&m, x, 1024, &r); }
        int slot = -1; for (int u = 0; u < (int)SFVL_MAX_UNKNOWN_PROTOTYPES; ++u) if (m.unknown[u].valid && m.unknown[u].hits >= m.unknown_promote_hits) slot = u;
        CHECK(slot >= 0); CHECK(SFVL_PromoteUnknown(&m, (uint8_t)slot, 1) == 0);
        int acc = 0, N = 2000; for (int i = 0; i < N; ++i) { int32_t x[4]; for (int d = 0; d < 4; ++d) x[d] = c[d] + (int32_t)(tc_gauss() * noise[k]); (void)SFVL_Process(&m, x, 1024, &r); acc += (r.status == SFVL_STATUS_SUCCESS && r.predicted_class == 1); }
        printf("noise=%.0f acceptance=%.3f (required >= %.2f)\n", noise[k], (double)acc / N, need[k]); CHECK((double)acc / N >= need[k]);
    }
    printf("PROMOTE_CONSISTENCY PASS\n"); return 0;
}
