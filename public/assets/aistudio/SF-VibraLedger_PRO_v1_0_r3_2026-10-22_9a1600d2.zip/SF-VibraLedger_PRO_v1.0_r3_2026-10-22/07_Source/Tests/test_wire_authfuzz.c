/* Authenticated-mutation fuzz: the payload is corrupted and the HMAC tag is RE-COMPUTED with the valid key, so the parser's
 * schema / bounds / self-test logic is really exercised (a plain bit-flip fuzz is stopped by the tag check almost always).
 * Any staged model must satisfy the structural invariants and must survive processing under sanitizers. */
#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include "SFVibraLedger_SHA256.h"
#include "test_common.h"
#include <string.h>
static void rehash(uint8_t *b, size_t n, const uint8_t *key) { uint8_t tag[32]; sf_hmac_sha256(key, 32, b, n - 32, tag); memcpy(b + n - 32, tag, 32); }
static int invariants(const SFVL_Model *m) {
    if (m->active_dimensions == 0 || m->active_dimensions > SFVL_MAX_DIMENSIONS || m->active_classes == 0 || m->active_classes > SFVL_MAX_CLASSES) return 0;
    if (m->prototypes_per_class == 0 || m->prototypes_per_class > SFVL_MAX_PROTOTYPES_PER_CLASS) return 0;
    for (uint8_t d = 0; d < m->active_dimensions; ++d) if (m->norm_scale[d] < SFVL_MIN_SCALE || m->norm_scale[d] > SFVL_MAX_SCALE) return 0;
    for (uint8_t c = 0; c < m->active_classes; ++c) for (uint8_t p = 0; p < m->prototypes_per_class; ++p) { const SFVL_Prototype *q = &m->proto[c][p]; if (!q->valid) continue; if (q->trust_q > SFVL_Q || q->threshold_sq == 0) return 0; for (uint8_t d = 0; d < m->active_dimensions; ++d) if (q->scale[d] < SFVL_MIN_SCALE || q->scale[d] > SFVL_MAX_SCALE) return 0; }
    return 1;
}
int main(void) {
    SFVL_Model m; SFVL_Init(&m, 8, 3, 2); for (uint8_t d = 0; d < 8; ++d) CHECK(SFVL_SetNormalizationReference(&m, d, 100 * d, 50 + d) == 0);
    int32_t c[8] = {0}; CHECK(SFVL_SeedPrototype(&m, 0, 0, c, 256, 8) == 0); c[0] = 3000; CHECK(SFVL_SeedPrototype(&m, 1, 0, c, 300, 8) == 0);
    uint8_t key[32]; for (int i = 0; i < 32; ++i) key[i] = (uint8_t)(i * 7 + 3); uint8_t good[10000];
    const uint32_t caps = SFVL_WIRE_CAP_CORE | SFVL_WIRE_CAP_EVIDENCE_GATE | SFVL_WIRE_CAP_UNKNOWN_POOL | SFVL_WIRE_CAP_CONTEXT_CAL | SFVL_WIRE_CAP_TRUST_LEDGER;
    size_t n = SFVL_WireSerialize(&m, caps, key, 32, good, sizeof(good)); CHECK(n > 0);
    unsigned ok = 0, rej = 0, iters = 300000; tc_s = 99;
    for (unsigned it = 0; it < iters; ++it) {
        uint8_t b[10000]; memcpy(b, good, n); unsigned k = 1u + tc_u32() % 6u;
        for (unsigned j = 0; j < k; ++j) { size_t pos = 32u + (size_t)(tc_u32() % (uint32_t)(n - 64u)); b[pos] = (uint8_t)tc_u32(); }
        if (tc_u32() % 8u == 0) b[12 + tc_u32() % 8u] = (uint8_t)tc_u32();            /* header generation too */
        rehash(b, n, key);
        SFVL_Model old = m; old.generation = 0; SFVL_WireStore st; SFVL_WireStoreInit(&st, &old);   /* generation 0 so rollback check passes */
        SFVL_WireStatus s = SFVL_WireStageToStore(b, n, key, 32, &st);
        if (s == SFVL_WIRE_OK) { ++ok; const SFVL_Model *a = SFVL_WireStoreActive(&st); CHECK(invariants(a));
            SFVL_Model tmp = *a; SFVL_Result r; int32_t x[SFVL_MAX_DIMENSIONS]; for (int d = 0; d < (int)SFVL_MAX_DIMENSIONS; ++d) x[d] = (int32_t)tc_u32();
            (void)SFVL_Process(&tmp, x, 1024, &r); if (r.learn_eligible) (void)SFVL_FeedbackLearnGated(&tmp, &r.token, x); } else ++rej;
    }
    printf("authenticated-mutation fuzz: %u iterations, accepted-and-invariant-checked=%u rejected=%u\n", iters, ok, rej);
    CHECK(ok > 0 && rej > 0); printf("WIRE_AUTHFUZZ PASS\n"); return 0;
}
