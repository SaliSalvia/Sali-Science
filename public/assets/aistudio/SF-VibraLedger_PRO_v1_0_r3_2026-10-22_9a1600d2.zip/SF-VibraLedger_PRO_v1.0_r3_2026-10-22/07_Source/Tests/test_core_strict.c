/* Strict (unconditional) tests of the core's security/learning contract. */
#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include "test_common.h"
#include <string.h>

static void setup(SFVL_Model *m, int32_t *norm) {
    SFVL_Init(m, 4, 2, 2);
    int32_t raw[4] = {100, 200, 300, 400};
    for (uint8_t d = 0; d < 4; d++) CHECK(SFVL_SetNormalizationReference(m, d, 100, 100) == 0);
    CHECK(SFVL_Normalize(m, raw, norm) == 0);
    CHECK(SFVL_SeedPrototype(m, 0, 0, norm, 256, 8) == 0);
}
int main(void) {
    SFVL_Model m; int32_t norm[4]; setup(&m, norm);
    SFVL_Result r; int eligible_seen = 0; uint32_t g0 = m.generation;
    for (int i = 0; i < 40 && !eligible_seen; ++i) { CHECK(SFVL_Process(&m, norm, 1024, &r) == SFVL_STATUS_SUCCESS); eligible_seen = r.learn_eligible; }
    CHECK(eligible_seen);                                            /* learning MUST become possible on healthy repeated evidence */
    SFVL_LearnToken tok = r.token;
    int32_t wrong[4]; memcpy(wrong, norm, sizeof(wrong)); wrong[0] += 1;
    CHECK(SFVL_FeedbackLearnGated(&m, &tok, wrong) == -6);            /* fingerprint binding */
    SFVL_LearnToken bad = tok; bad.magic ^= 1u; CHECK(SFVL_FeedbackLearnGated(&m, &bad, norm) == -2);
    bad = tok; bad.model_generation += 1u;   CHECK(SFVL_FeedbackLearnGated(&m, &bad, norm) == -2);
    bad = tok; bad.sensor_quality_q = 100;   CHECK(SFVL_FeedbackLearnGated(&m, &bad, norm) == -5);
    bad = tok; bad.evidence_mask &= (uint8_t)~SFVL_EVIDENCE_TEMPORAL; CHECK(SFVL_FeedbackLearnGated(&m, &bad, norm) == -4);
    CHECK(SFVL_FeedbackLearnGated(&m, &tok, norm) == 0);              /* legitimate redemption */
    CHECK(m.generation == g0 + 1u);
    CHECK(SFVL_FeedbackLearnGated(&m, &tok, norm) == -2);             /* replay: generation moved on */
    /* trust budget: immediately after a learning event the prototype must NOT be eligible again */
    CHECK(SFVL_Process(&m, norm, 1024, &r) == SFVL_STATUS_SUCCESS); CHECK(r.learn_eligible == 0);
    /* trust decays with idle epochs: stale prototype loses maturity/eligibility */
    int32_t far[4] = {30000, 30000, 30000, 30000}; SFVL_Result u;
    for (int i = 0; i < 3000; ++i) (void)SFVL_Process(&m, far, 1024, &u);
    CHECK(SFVL_DecayedTrust(&m, &m.proto[0][0]) == 0);
    CHECK(SFVL_Process(&m, norm, 1024, &r) == SFVL_STATUS_SUCCESS); CHECK(r.learn_eligible == 0 && (r.evidence_mask & SFVL_EVIDENCE_MATURITY) == 0);
    /* low sensor quality never yields a token */
    SFVL_Result lq; CHECK(SFVL_Process(&m, norm, 100, &lq) == SFVL_STATUS_SUCCESS); CHECK(lq.learn_eligible == 0);
    /* unknown-state quarantine: recurring far samples mature, promotion needs explicit action, promoted state is then recognised */
    SFVL_Model m2; setup(&m2, norm); int32_t ctr[4] = {6000, -5000, 4000, 7000};
    for (int i = 0; i < 60; ++i) { int32_t x[4]; for (int d = 0; d < 4; ++d) x[d] = ctr[d] + (int32_t)(tc_gauss() * 150.0); (void)SFVL_Process(&m2, x, 1024, &u); }
    int slot = -1; for (int k = 0; k < (int)SFVL_MAX_UNKNOWN_PROTOTYPES; ++k) if (m2.unknown[k].valid && m2.unknown[k].hits >= m2.unknown_promote_hits) slot = k;
    CHECK(slot >= 0); uint32_t gp = m2.generation; CHECK(SFVL_PromoteUnknown(&m2, (uint8_t)slot, 1) == 0); CHECK(m2.generation == gp + 1u);
    int acc = 0; for (int i = 0; i < 300; ++i) { int32_t x[4]; for (int d = 0; d < 4; ++d) x[d] = ctr[d] + (int32_t)(tc_gauss() * 150.0); (void)SFVL_Process(&m2, x, 1024, &u); acc += (u.status == SFVL_STATUS_SUCCESS && u.predicted_class == 1); }
    CHECK(acc >= 270);                                               /* regression for the promotion scale bug (was ~99% only for tiny noise) */
    /* determinism: identical inputs -> byte-identical model state */
    SFVL_Model a, b; int32_t n1[4], n2[4]; setup(&a, n1); setup(&b, n2); tc_s = 12345; uint64_t s0 = tc_s;
    for (int run = 0; run < 2; ++run) { SFVL_Model *mm = run ? &b : &a; tc_s = s0;
        for (int i = 0; i < 5000; ++i) { int32_t x[4]; for (int d = 0; d < 4; ++d) x[d] = n1[d] + (int32_t)(tc_gauss() * 40.0); SFVL_Result rr; (void)SFVL_Process(mm, x, 1024, &rr); if (rr.learn_eligible) (void)SFVL_FeedbackLearnGated(mm, &rr.token, x); } }
    CHECK(memcmp(&a, &b, sizeof(a)) == 0);
    printf("CORE_STRICT PASS generation=%u\n", m.generation);
    return 0;
}
