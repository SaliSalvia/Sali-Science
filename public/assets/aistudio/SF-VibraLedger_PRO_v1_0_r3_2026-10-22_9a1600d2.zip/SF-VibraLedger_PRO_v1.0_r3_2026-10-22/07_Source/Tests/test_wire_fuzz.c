#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint32_t rng=0xC0FFEE11u; static uint32_t rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
int main(void){SFVL_Model m;SFVL_Init(&m,8,2,2);int32_t c[8]={0};assert(SFVL_SeedPrototype(&m,0,0,c,256,8)==0);uint8_t key[32],buf[10000];for(int i=0;i<32;i++)key[i]=(uint8_t)(i+1);size_t n=SFVL_WireSerialize(&m,SFVL_WIRE_CAP_CORE|SFVL_WIRE_CAP_EVIDENCE_GATE|SFVL_WIRE_CAP_UNKNOWN_POOL|SFVL_WIRE_CAP_CONTEXT_CAL|SFVL_WIRE_CAP_TRUST_LEDGER,key,32,buf,sizeof(buf));assert(n>0);for(unsigned i=0;i<200000u;i++){uint8_t b[10000];memcpy(b,buf,n);unsigned flips=1u+(rnd()%8u);for(unsigned j=0;j<flips;j++)b[rnd()%n]^=(uint8_t)(1u<<(rnd()%8u));SFVL_WireStore st;SFVL_WireStoreInit(&st,&m);(void)SFVL_WireStageToStore(b,n,key,32,&st);}printf("FINAL_WIRE_FUZZ PASS iterations=200000\n");return 0;}
