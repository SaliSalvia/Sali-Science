#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include "SFVibraLedger_XCal.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void){
    SFVL_Model m; SFVL_Init(&m,4,2,2);
    int32_t raw[4]={100,200,300,400}, norm[4]={0};
    for(int i=0;i<4;i++) assert(SFVL_SetNormalizationReference(&m,(uint8_t)i,100,100)==0);
    assert(SFVL_Normalize(&m,raw,norm)==0);
    assert(SFVL_SeedPrototype(&m,0,0,norm,256,8)==0);
    SFVL_Result r;
    for(int i=0;i<12;i++){ assert(SFVL_Process(&m,norm,1024,&r)==SFVL_STATUS_SUCCESS); }
    assert(r.predicted_class==0);
    if(r.learn_eligible){ assert(SFVL_FeedbackLearnGated(&m,&r.token,norm)==0); }
    uint8_t key[32]; for(int i=0;i<32;i++) key[i]=(uint8_t)(i+1);
    uint8_t buf[10000];
    uint32_t gen_before=m.generation;
    size_t n=SFVL_WireSerialize(&m, SFVL_WIRE_CAP_CORE|SFVL_WIRE_CAP_EVIDENCE_GATE|SFVL_WIRE_CAP_UNKNOWN_POOL|SFVL_WIRE_CAP_CONTEXT_CAL|SFVL_WIRE_CAP_TRUST_LEDGER,key,sizeof(key),buf,sizeof(buf));
    assert(n>0);
    SFVL_WireStore st; SFVL_WireStoreInit(&st,&m); /* store current gen: stage must reject equal */
    assert(SFVL_WireStageToStore(buf,n,key,sizeof(key),&st)==SFVL_WIRE_ROLLBACK_ERR);
    SFVL_Model older=st.slot[0]; older.generation=gen_before-1; SFVL_WireStoreInit(&st,&older);
    assert(SFVL_WireStageToStore(buf,n,key,sizeof(key),&st)==SFVL_WIRE_OK);
    buf[n-1]^=1u; assert(SFVL_WireStageToStore(buf,n,key,sizeof(key),&st)==SFVL_WIRE_AUTH_ERR);
    SFVL_XCal_State xc; SFVL_XCal_Init(&xc,4,2,4); uint16_t ctx[2]={512,512}; uint16_t q=0; int32_t ref=0; int32_t vals[4]={10,11,9,10}; uint16_t qs[4]={1024,1024,1024,1024};
    uint16_t k=SFVL_XCal_ContextKey(ctx,2,4); assert(SFVL_XCal_RobustConsensus(vals,qs,4,700,&ref,&q)==0 && q==1024); assert(SFVL_XCal_SetGain(&xc,0,k,1024)==0);
    printf("SF-VibraLedger FINAL core test PASS; wire_len=%zu generation=%u trust=%u ref=%d\n",n,m.generation,r.trust_q,ref);
    return 0;
}
