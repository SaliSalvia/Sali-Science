#ifndef TEST_COMMON_H
#define TEST_COMMON_H
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#define CHECK(c) do { if (!(c)) { fprintf(stderr, "CHECK FAILED %s:%d: %s\n", __FILE__, __LINE__, #c); exit(1); } } while (0)
static uint64_t tc_s = 0x9E3779B97F4A7C15ull;
static inline uint32_t tc_u32(void) { tc_s ^= tc_s << 13; tc_s ^= tc_s >> 7; tc_s ^= tc_s << 17; return (uint32_t)(tc_s >> 16); }
static inline double tc_uni(void) { return ((double)tc_u32() + 1.0) / 4294967297.0; }
static inline double tc_gauss(void) { return sqrt(-2.0 * log(tc_uni())) * cos(6.283185307179586 * tc_uni()); }
#endif
