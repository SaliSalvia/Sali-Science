#include "SFVibraLedger_Core.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
static double gauss(void){ double u=(rand()+1.0)/(RAND_MAX+2.0), v=(rand()+1.0)/(RAND_MAX+2.0); return sqrt(-2*log(u))*cos(6.28318530718*v);} 
int main(void){
  const int D=4; double sigma_noise[3]={100.0,300.0,500.0};
  for(int si=0;si<3;++si){
    srand(1234);
    SFVL_Model m; SFVL_Init(&m,D,2,2);
    int32_t seedc[4]={0,0,0,0}; SFVL_SeedPrototype(&m,0,0,seedc,256,32);
    int32_t centre[4]={6000,-5000,4000,7000}; /* far-away unknown state (~6 sigma) */
    SFVL_Result r; int promoted=-1;
    for(int i=0;i<200 && promoted<0;++i){
      int32_t x[4]; for(int d=0;d<D;++d) x[d]=centre[d]+(int32_t)(gauss()*sigma_noise[si]);
      SFVL_Process(&m,x,1024,&r);
    }
    int slot=-1; for(int u=0;u<SFVL_MAX_UNKNOWN_PROTOTYPES;++u) if(m.unknown[u].valid && m.unknown[u].hits>=m.unknown_promote_hits){slot=u;break;}
    int hits_max=0; for(int u=0;u<SFVL_MAX_UNKNOWN_PROTOTYPES;++u) if(m.unknown[u].valid && (int)m.unknown[u].hits>hits_max) hits_max=(int)m.unknown[u].hits;
    if(slot<0){ printf("noise=%.0f: unknown pool never reached promote hits (max hits=%d)\n",sigma_noise[si],hits_max); continue; }
    int rc=SFVL_PromoteUnknown(&m,(uint8_t)slot,1);
    int acc=0,N=1000;
    for(int i=0;i<N;++i){ int32_t x[4]; for(int d=0;d<D;++d) x[d]=centre[d]+(int32_t)(gauss()*sigma_noise[si]); SFVL_Process(&m,x,1024,&r); if(r.status==SFVL_STATUS_SUCCESS && r.predicted_class==1) ++acc; }
    printf("noise=%.0f: promote rc=%d, hits_at_promotion>=%d, acceptance of fresh same-distribution samples by promoted prototype = %.1f%%\n",sigma_noise[si],rc,(int)m.unknown_promote_hits,100.0*acc/N);
  }
  return 0;}
