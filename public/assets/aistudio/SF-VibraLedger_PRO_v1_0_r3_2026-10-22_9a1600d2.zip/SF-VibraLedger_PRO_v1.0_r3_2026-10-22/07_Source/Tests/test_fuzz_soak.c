/* Randomised robustness + long soak: extreme feature windows, extreme monitor inputs, long random operation.
 * Intended to be run natively AND under -fsanitize=address,undefined. Argument: iteration scale (default 1). */
#include "SFVibraLedger_Commission.h"
#include "SFVibraLedger_Features.h"
#include "test_common.h"
#include <string.h>
int main(int argc, char **argv) {
    unsigned scale = argc > 1 ? (unsigned)atoi(argv[1]) : 1u; if (scale == 0) scale = 1;
    /* 1. feature extractor: random legal windows incl. extreme amplitudes */
    static int32_t w[SFVLF_MAX_WINDOW]; SFVLF_Config c; SFVLF_Features f; tc_s = 2024; unsigned fok = 0;
    for (unsigned it = 0; it < 20000u * scale; ++it) {
        SFVLF_ConfigInit(&c); uint32_t n = SFVLF_MIN_WINDOW + tc_u32() % (SFVLF_MAX_WINDOW - SFVLF_MIN_WINDOW + 1u); int mag = (int)(tc_u32() % 30u);
        c.bands = (uint8_t)(tc_u32() % 5u); for (int b = 0; b < 4; ++b) c.goertzel_coeff_q22[b] = (int32_t)((int64_t)(tc_u32() % 16777217u) - 8388608); c.full_scale = (tc_u32() & 1u) ? (int32_t)(1u << (tc_u32() % 30u)) : 0;
        int mode = (int)(tc_u32() % 4u);
        for (uint32_t i = 0; i < n; ++i) { int64_t v = (int64_t)((int32_t)tc_u32()) >> (31 - mag); if (mode == 1) v = (i & 1u) ? (1 << mag) : -(1 << mag); if (mode == 2) v = 0; if (mode == 3) v = (int64_t)(1u << mag) - 1; if (v > 1073741823) v = 1073741823; if (v < -1073741823) v = -1073741823; w[i] = (int32_t)v; }
        int rc = SFVLF_Extract(w, n, &c, &f); CHECK(rc == SFVLF_OK);
        CHECK(f.quality_q <= 1024u); CHECK(f.rms <= f.peak + 1u); ++fok;
    }
    printf("feature fuzz: %u windows OK\n", fok);
    /* 2. monitor soak: commission, then random walk with mode changes, faults, glitches and extreme raw values */
    static SFVLM_Monitor mon; static int32_t F[150 * 6]; static uint16_t Q[150]; const uint8_t key[16] = "soak-key-0123456";
    CHECK(SFVLM_Init(&mon, 6, 1, 4, NULL, key, 16) == 0);
    for (int i = 0; i < 150; ++i) { for (int d = 0; d < 6; ++d) F[i * 6 + d] = (int32_t)(5000 + ((i / 10) % 3) * 300 + 30 * tc_gauss()); Q[i] = 1024; }
    SFVLC_Report rep; CHECK(SFVLC_Commission(&mon, F, Q, 150, NULL, &rep) == 0);
    SFVLM_Output o; uint32_t gen_prev = mon.model.generation; unsigned counts[6] = {0}; unsigned N = 300000u * scale;
    for (unsigned t = 0; t < N; ++t) {
        int32_t v[6]; unsigned kind = tc_u32() % 1000u;
        for (int d = 0; d < 6; ++d) v[d] = (int32_t)(5000 + ((t / 500u) % 3u) * 300 + 30 * tc_gauss());
        if (kind < 3) for (int d = 0; d < 6; ++d) v[d] = (int32_t)tc_u32();                  /* garbage */
        else if (kind < 6) v[tc_u32() % 6u] = (tc_u32() & 1u) ? INT32_MAX : INT32_MIN;      /* extremes */
        else if (kind < 20) v[0] += 4000;                                                      /* fault-like */
        uint16_t q = (kind >= 20 && kind < 30) ? 300 : 1024;
        CHECK(SFVLM_Update(&mon, v, q, &o) == 0); CHECK(o.status <= SFVLM_DRIFT_LIMIT); ++counts[o.status];
        CHECK(mon.model.generation >= gen_prev); gen_prev = mon.model.generation;
    }
    printf("monitor soak: %u updates, status counts HEALTHY/TRANSIENT/WATCH/WARNING/ALARM/DRIFT_LIMIT = %u/%u/%u/%u/%u/%u, generation=%u\n", N, counts[0], counts[1], counts[2], counts[3], counts[4], counts[5], mon.model.generation);
    CHECK(SFVLAL_Verify(&mon.audit, key, 16) == 0);
    printf("FUZZ_SOAK PASS\n"); return 0;
}
