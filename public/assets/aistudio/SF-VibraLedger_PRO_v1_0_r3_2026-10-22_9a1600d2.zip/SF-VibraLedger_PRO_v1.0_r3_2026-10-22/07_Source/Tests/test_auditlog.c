#include "SFVibraLedger_AuditLog.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
    const uint8_t key[] = "test-audit-key-0001";
    SFVLAL_Log log;
    SFVLAL_Init(&log);

    /* 1) Append 10 events, chain must verify. */
    for (uint32_t i = 0; i < 10u; ++i) {
        int rc = SFVLAL_Append(&log, key, sizeof(key) - 1u, i, i, i, 0, 0, 0x0F, SFVLAL_OUTCOME_APPLIED, 0, 100 + i, 0xAAAA0000u + i);
        assert(rc == 0);
    }
    assert(SFVLAL_Count(&log) == 10u);
    assert(SFVLAL_DroppedCount(&log) == 0u);
    assert(SFVLAL_Verify(&log, key, sizeof(key) - 1u) == 0);
    printf("10 entries appended, chain verifies, dropped=%llu\n", (unsigned long long)SFVLAL_DroppedCount(&log));

    char line[160];
    size_t n = SFVLAL_ExportLine(&log, 0u, line, sizeof(line));
    assert(n > 0);
    printf("oldest entry: %s\n", line);

    /* 2) Tamper with one field of an in-window entry directly, confirm detection. */
    uint32_t idx_to_tamper = 4u; /* window index 4, buffer not yet wrapped so == raw index 4 */
    log.entries[idx_to_tamper].evidence_mask ^= 0xFFu;
    int bad = SFVLAL_Verify(&log, key, sizeof(key) - 1u);
    printf("after tampering entry #%u: SFVLAL_Verify returned %d (expected %u)\n", idx_to_tamper, bad, idx_to_tamper + 1u);
    assert(bad == (int)(idx_to_tamper + 1u));
    /* restore */
    log.entries[idx_to_tamper].evidence_mask ^= 0xFFu;
    assert(SFVLAL_Verify(&log, key, sizeof(key) - 1u) == 0);

    /* 3) Wrong key must also be detected as a full mismatch on the oldest entry. */
    const uint8_t wrong_key[] = "different-key";
    int bad_key = SFVLAL_Verify(&log, wrong_key, sizeof(wrong_key) - 1u);
    assert(bad_key != 0);
    printf("verification with wrong key correctly fails (code=%d)\n", bad_key);

    /* 4) Wraparound: append well beyond capacity, confirm dropped-count honesty
     *    and that the chain still verifies over the retained window only. */
    SFVLAL_Log log2;
    SFVLAL_Init(&log2);
    const uint32_t total = SFVLAL_CAPACITY * 3u + 5u;
    for (uint32_t i = 0; i < total; ++i) {
        int rc = SFVLAL_Append(&log2, key, sizeof(key) - 1u, i, i, i, (uint8_t)(i % 3u), 0, 0x1F, SFVLAL_OUTCOME_APPLIED, 0, i, 0xBEEF0000u + i);
        assert(rc == 0);
    }
    assert(SFVLAL_Count(&log2) == SFVLAL_CAPACITY);
    assert(SFVLAL_DroppedCount(&log2) == total - SFVLAL_CAPACITY);
    assert(SFVLAL_Verify(&log2, key, sizeof(key) - 1u) == 0);
    n = SFVLAL_ExportLine(&log2, 0u, line, sizeof(line));
    printf("after %u appends (capacity %u): count=%u dropped=%llu, oldest retained: %s\n",
           total, SFVLAL_CAPACITY, SFVLAL_Count(&log2), (unsigned long long)SFVLAL_DroppedCount(&log2), line);

    printf("audit log unit tests passed\n");
    return 0;
}
