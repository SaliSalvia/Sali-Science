#include "SFVibraLedger_Features.h"
#include "test_common.h"
#include <string.h>
static int32_t buf[SFVLF_MAX_WINDOW];
static void fill_sine(uint32_t n, double amp, double f, double fs, double dc, double noise) {
    for (uint32_t i = 0; i < n; ++i) buf[i] = (int32_t)llround(dc + amp * sin(6.283185307179586 * f * i / fs) + noise * tc_gauss());
}
int main(void) {
    /* log2 table accuracy */
    double worst = 0; for (uint32_t v = 1; v < 200000; v += (v < 4096 ? 1 : 37)) { double e = fabs((double)SFVLF_Log2Q(v) - log2((double)v) * 1024.0); if (e > worst) worst = e; }
    for (int k = 0; k < 32; ++k) { double e = fabs((double)SFVLF_Log2Q(1u << k) - k * 1024.0); if (e > worst) worst = e; }
    printf("log2Q worst error = %.3f units (1/1024 octave)\n", worst); CHECK(worst <= 2.0);
    SFVLF_Config c; SFVLF_ConfigInit(&c); SFVLF_Features f;
    /* pure sine, integer number of cycles: rms = A/sqrt2, kurtosis = 1.5, crest = sqrt2 */
    const double fs = 10240.0; fill_sine(2048, 6000.0, 320.0, fs, 0.0, 0.0);
    CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK);
    printf("sine: rms=%u (%.1f) crest=%.3f kurt=%.3f\n", f.rms, 6000.0 / sqrt(2.0), f.crest_q / 1024.0, f.kurt_q / 1024.0);
    CHECK(fabs((double)f.rms - 6000.0 / sqrt(2.0)) < 2.0); CHECK(fabs(f.kurt_q / 1024.0 - 1.5) < 0.01); CHECK(fabs(f.crest_q / 1024.0 - 1.4142) < 0.01);
    /* DC offset must not change AC features */
    fill_sine(2048, 6000.0, 320.0, fs, 12345.0, 0.0); SFVLF_Features g; CHECK(SFVLF_Extract(buf, 2048, &c, &g) == SFVLF_OK); CHECK(g.rms == f.rms || g.rms + 1 == f.rms || g.rms == f.rms + 1);
    /* Goertzel tone amplitude (bin-exact frequency) */
    SFVLF_ConfigInit(&c); c.bands = 2; c.goertzel_coeff_q22[0] = (int32_t)llround(2.0 * cos(6.283185307179586 * 320.0 / fs) * 4194304.0); c.goertzel_coeff_q22[1] = (int32_t)llround(2.0 * cos(6.283185307179586 * 640.0 / fs) * 4194304.0);
    fill_sine(2048, 6000.0, 320.0, fs, 0.0, 0.0); CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK);
    printf("tone: band0=%u (expect 6000) band1=%u (expect ~0)\n", f.band_amp[0], f.band_amp[1]); CHECK(abs((int)f.band_amp[0] - 6000) < 60); CHECK(f.band_amp[1] < 120);
    /* Gaussian noise kurtosis ~ 3 */
    SFVLF_ConfigInit(&c); double ks = 0; for (int t = 0; t < 40; ++t) { for (int i = 0; i < 2048; ++i) buf[i] = (int32_t)llround(3000.0 * tc_gauss()); CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK); ks += f.kurt_q / 1024.0; }
    printf("gaussian kurtosis mean = %.3f\n", ks / 40); CHECK(fabs(ks / 40 - 3.0) < 0.15);
    /* impulses raise kurtosis and crest */
    for (int i = 0; i < 2048; ++i) buf[i] = (int32_t)llround(500.0 * tc_gauss());
    for (int i = 100; i < 2048; i += 200) buf[i] += 9000;
    CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK); CHECK(f.kurt_q / 1024.0 > 6.0); CHECK(f.crest_q / 1024.0 > 8.0);
    /* integrity flags */
    for (int i = 0; i < 2048; ++i) buf[i] = 5;
    CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK); CHECK((f.flags & SFVLF_FLAG_FLATLINE) && f.quality_q == 0);
    c.full_scale = 32767;
    for (int i = 0; i < 2048; ++i) { double v = 40000.0 * sin(0.05 * i); buf[i] = (int32_t)(v > 32767 ? 32767 : (v < -32767 ? -32767 : v)); }
    CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK); CHECK((f.flags & SFVLF_FLAG_SATURATION) && f.quality_q < 700);
    for (int i = 0; i < 2048; ++i) buf[i] = (int32_t)llround(3000.0 * tc_gauss());
    for (int i = 300; i < 900; ++i) buf[i] = buf[300];
    SFVLF_ConfigInit(&c); CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_OK); CHECK((f.flags & SFVLF_FLAG_DROPOUT) && f.quality_q < 900);
    /* range checks */
    CHECK(SFVLF_Extract(buf, 8, &c, &f) == SFVLF_ERR_RANGE); CHECK(SFVLF_Extract(buf, 5000, &c, &f) == SFVLF_ERR_RANGE); CHECK(SFVLF_Extract(NULL, 64, &c, &f) == SFVLF_ERR_ARG);
    buf[10] = 1073741824; CHECK(SFVLF_Extract(buf, 2048, &c, &f) == SFVLF_ERR_RANGE);
    /* extreme but legal input (24-bit ADC, 4096 samples) must not overflow: compare to double reference */
    for (int i = 0; i < 4096; ++i) buf[i] = (int32_t)llround(8000000.0 * sin(0.031 * i) + 2000000.0 * tc_gauss());
    CHECK(SFVLF_Extract(buf, 4096, &c, &f) == SFVLF_OK); double s2 = 0, s4 = 0, m = 0; for (int i = 0; i < 4096; ++i) m += buf[i]; m = trunc(m / 4096);
    for (int i = 0; i < 4096; ++i) { double y = buf[i] - m; s2 += y * y; s4 += y * y * y * y; } s2 /= 4096; s4 /= 4096;
    CHECK(fabs(f.rms - sqrt(s2)) / sqrt(s2) < 1e-3); CHECK(fabs(f.kurt_q / 1024.0 - s4 / (s2 * s2)) / (s4 / (s2 * s2)) < 5e-3);
    printf("FEATURES PASS\n"); return 0;
}
