#include "SFVibraLedger_XCal.h"
#include <string.h>
#include <limits.h>

static int32_t sat_i32(int64_t x) { if (x > INT32_MAX) return INT32_MAX; if (x < INT32_MIN) return INT32_MIN; return (int32_t)x; }
static SFVL_XCal_KeyEntry *find_entry(SFVL_XCal_State *s, uint8_t ch, uint16_t key, int create) {
    if (!s || ch >= s->channels) return NULL;
    uint16_t start = (uint16_t)(((uint32_t)ch * 257u + key) % SFVL_XCal_MAX_KEYS);
    for (uint8_t k = 0u; k < SFVL_XCal_MAX_KEYS; ++k) {
        uint8_t i = (uint8_t)((start + k) % SFVL_XCal_MAX_KEYS);
        SFVL_XCal_KeyEntry *e = &s->entry[i];
        if (e->valid && e->channel == ch && e->context_key == key) return e;
        if (!e->valid && create) { memset(e, 0, sizeof(*e)); e->valid=1u; e->channel=ch; e->context_key=key; e->gain_q=SFVL_XCal_Q; return e; }
    }
    return NULL;
}

void SFVL_XCal_Init(SFVL_XCal_State *s, uint8_t channels, uint8_t context_dims, uint8_t bins_per_dim) {
    if (!s) return;
    memset(s,0,sizeof(*s));
    s->channels = channels > SFVL_XCal_MAX_CHANNELS ? SFVL_XCal_MAX_CHANNELS : channels;
    s->context_dims = context_dims > SFVL_XCal_MAX_CONTEXT_DIMS ? SFVL_XCal_MAX_CONTEXT_DIMS : context_dims;
    s->bins_per_dim = bins_per_dim < 1u ? 1u : (bins_per_dim > SFVL_XCal_MAX_BINS_PER_DIM ? SFVL_XCal_MAX_BINS_PER_DIM : bins_per_dim);
    s->min_quality_q = 700u;
}

uint16_t SFVL_XCal_ContextKey(const uint16_t *ctx_q, uint8_t context_dims, uint8_t bins_per_dim) {
    if (!ctx_q || context_dims == 0u) return 0u;
    if (bins_per_dim < 1u) bins_per_dim = 1u;
    uint16_t key = 0u; uint16_t mul = 1u;
    for (uint8_t d=0u; d<context_dims && d<SFVL_XCal_MAX_CONTEXT_DIMS; ++d) {
        uint16_t q = ctx_q[d] > SFVL_XCal_Q ? SFVL_XCal_Q : ctx_q[d];
        uint16_t b = (uint16_t)(((uint32_t)q * bins_per_dim) / (SFVL_XCal_Q + 1u));
        if (b >= bins_per_dim) b = (uint16_t)(bins_per_dim - 1u);
        key = (uint16_t)(key + b * mul);
        mul = (uint16_t)(mul * bins_per_dim);
    }
    return key;
}

int32_t SFVL_XCal_Correct(const SFVL_XCal_State *s, uint8_t channel, uint16_t context_key, int32_t raw) {
    if (!s || channel >= s->channels) return raw;
    for (uint8_t i=0u;i<SFVL_XCal_MAX_KEYS;++i) {
        const SFVL_XCal_KeyEntry *e=&s->entry[i];
        if (e->valid && e->channel==channel && e->context_key==context_key) {
            int64_t scaled = ((int64_t)raw * (int64_t)e->gain_q) / (int64_t)SFVL_XCal_Q;
            return sat_i32(scaled + e->bias);
        }
    }
    return raw;
}

int SFVL_XCal_SetGain(SFVL_XCal_State *s, uint8_t channel, uint16_t context_key, uint32_t gain_q) {
    SFVL_XCal_KeyEntry *e=find_entry(s,channel,context_key,1); if(!e) return -1;
    if (gain_q < 128u) gain_q = 128u;
    if (gain_q > 4096u) gain_q = 4096u;
    e->gain_q = gain_q;
    return 0;
}

int SFVL_XCal_UpdateBiasFromReference(SFVL_XCal_State *s, uint8_t channel, uint16_t context_key, int32_t raw, int32_t reference, uint16_t quality_q) {
    SFVL_XCal_KeyEntry *e=find_entry(s,channel,context_key,1); if(!e) return -1;
    if (quality_q < s->min_quality_q) return -2;
    int64_t predicted = ((int64_t)raw * (int64_t)e->gain_q) / (int64_t)SFVL_XCal_Q + e->bias;
    int64_t err=(int64_t)reference-predicted;
    e->bias=sat_i32((int64_t)e->bias + err/8);
    if (e->hits != UINT32_MAX) ++e->hits;
    return 0;
}

int SFVL_XCal_RobustConsensus(const int32_t *values, const uint16_t *quality_q, uint8_t n, uint16_t min_quality_q, int32_t *reference_out, uint16_t *quality_out) {
    if(!values||!quality_q||!reference_out||!quality_out||n==0u||n>SFVL_XCal_MAX_CHANNELS) return -1;
    int32_t work[SFVL_XCal_MAX_CHANNELS]; uint8_t count=0u;
    for(uint8_t i=0u;i<n;++i) if(quality_q[i]>=min_quality_q) work[count++]=values[i];
    if(count==0u) { *quality_out=0u; return -2; }
    for(uint8_t i=1u;i<count;++i){int32_t v=work[i];uint8_t j=i;while(j>0u&&work[j-1u]>v){work[j]=work[j-1u];--j;}work[j]=v;}
    int32_t med=work[count/2u]; *reference_out=med;
    uint16_t q=(uint16_t)(((uint32_t)count*SFVL_XCal_Q)/n); *quality_out=q; return 0;
}
