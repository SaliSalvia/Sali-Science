#ifndef SFVL_XCAL_H
#define SFVL_XCAL_H
#include <stdint.h>
#include <stddef.h>

#define SFVL_XCal_Q 1024u
#define SFVL_XCal_MAX_CHANNELS 8u
#define SFVL_XCal_MAX_CONTEXT_DIMS 4u
#define SFVL_XCal_MAX_BINS_PER_DIM 8u
#define SFVL_XCal_MAX_KEYS 64u

typedef struct {
    uint8_t valid;
    uint8_t channel;
    uint16_t context_key;
    int32_t bias;
    uint32_t gain_q;
    uint32_t hits;
} SFVL_XCal_KeyEntry;

typedef struct {
    uint8_t channels;
    uint8_t context_dims;
    uint8_t bins_per_dim;
    uint8_t reserved;
    uint32_t min_quality_q;
    SFVL_XCal_KeyEntry entry[SFVL_XCal_MAX_KEYS];
} SFVL_XCal_State;

void SFVL_XCal_Init(SFVL_XCal_State *s, uint8_t channels, uint8_t context_dims, uint8_t bins_per_dim);
uint16_t SFVL_XCal_ContextKey(const uint16_t *ctx_q, uint8_t context_dims, uint8_t bins_per_dim);
int32_t SFVL_XCal_Correct(const SFVL_XCal_State *s, uint8_t channel, uint16_t context_key, int32_t raw);
int SFVL_XCal_SetGain(SFVL_XCal_State *s, uint8_t channel, uint16_t context_key, uint32_t gain_q);
int SFVL_XCal_UpdateBiasFromReference(SFVL_XCal_State *s, uint8_t channel, uint16_t context_key, int32_t raw, int32_t reference, uint16_t quality_q);
int SFVL_XCal_RobustConsensus(const int32_t *values, const uint16_t *quality_q, uint8_t n, uint16_t min_quality_q, int32_t *reference_out, uint16_t *quality_out);

#endif
