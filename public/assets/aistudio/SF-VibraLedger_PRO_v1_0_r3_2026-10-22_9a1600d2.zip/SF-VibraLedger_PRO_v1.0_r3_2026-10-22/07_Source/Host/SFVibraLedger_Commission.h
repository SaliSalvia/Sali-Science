#ifndef SFVIBRALEDGER_COMMISSION_H
#define SFVIBRALEDGER_COMMISSION_H
/* HOST-SIDE commissioning (uses libm and doubles; NOT part of the embedded footprint).
 * Input: windows of model-input features (from SFVLF_ToModelVector) recorded on a machine believed
 * healthy, possibly across several operating modes. Output: a fully seeded SFVL_Model. */
#include "SFVibraLedger_Monitor.h"
#include <stdint.h>

typedef struct {
    uint8_t  max_modes;        /* <= prototypes_per_class, default 4 */
    uint16_t quality_min_q;    /* windows below this are ignored, default 850 */
    double   min_sigma_units;  /* floor for the pooled within-mode sigma (feature units), default 6 */
    double   split_gain;       /* accept K+1 modes only if SSE ratio < this, default 0.5 */
    double   min_mode_frac;    /* smallest acceptable mode size, default 0.08 */
    double   radius_margin;    /* multiplies commissioned radii (boundary head-room), default 1.10 */
} SFVLC_Params;

typedef struct {
    int      ok;
    uint32_t used_windows;
    uint8_t  modes;
    double   sigma[SFVL_MAX_DIMENSIONS];
    uint32_t mode_count[SFVL_MAX_PROTOTYPES_PER_CLASS];
    uint32_t radius_mean[SFVL_MAX_PROTOTYPES_PER_CLASS];
    uint32_t threshold_radius[SFVL_MAX_PROTOTYPES_PER_CLASS];
} SFVLC_Report;

void SFVLC_ParamsDefaults(SFVLC_Params *p);
int  SFVLC_Commission(SFVLM_Monitor *mon, const int32_t *feat, const uint16_t *quality, uint32_t n, const SFVLC_Params *p, SFVLC_Report *rep);

#endif
