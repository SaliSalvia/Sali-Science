#include "SFVibraLedger_Commission.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define MAXN 4096u
#define D_MAX SFVL_MAX_DIMENSIONS

void SFVLC_ParamsDefaults(SFVLC_Params *p) {
    p->max_modes = 4; p->quality_min_q = 850; p->min_sigma_units = 6.0;
    p->split_gain = 0.5; p->min_mode_frac = 0.08; p->radius_margin = 1.10;
}

static int cmp_d(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return (x > y) - (x < y); }

static double median_of(double *v, uint32_t n) {
    qsort(v, n, sizeof(double), cmp_d);
    return (n & 1u) ? v[n / 2u] : 0.5 * (v[n / 2u - 1u] + v[n / 2u]);
}

/* deterministic farthest-point-initialised k-means in standardised space */
static double kmeans(const double *u, uint32_t n, uint8_t D, uint8_t K, uint8_t *asg, double *cent) {
    uint32_t first = 0u; double best = 1e300;
    for (uint32_t i = 0; i < n; ++i) { double s = 0; for (uint8_t d = 0; d < D; ++d) s += u[i * D + d] * u[i * D + d]; if (s < best) { best = s; first = i; } }
    for (uint8_t d = 0; d < D; ++d) cent[d] = u[first * D + d];
    for (uint8_t k = 1; k < K; ++k) {
        uint32_t far = 0u; double fd = -1;
        for (uint32_t i = 0; i < n; ++i) {
            double m = 1e300;
            for (uint8_t c = 0; c < k; ++c) { double s = 0; for (uint8_t d = 0; d < D; ++d) { double t = u[i * D + d] - cent[c * D + d]; s += t * t; } if (s < m) m = s; }
            if (m > fd) { fd = m; far = i; }
        }
        for (uint8_t d = 0; d < D; ++d) cent[k * D + d] = u[far * D + d];
    }
    double sse = 0;
    for (int it = 0; it < 40; ++it) {
        sse = 0;
        for (uint32_t i = 0; i < n; ++i) {
            double m = 1e300; uint8_t bc = 0;
            for (uint8_t c = 0; c < K; ++c) { double s = 0; for (uint8_t d = 0; d < D; ++d) { double t = u[i * D + d] - cent[c * D + d]; s += t * t; } if (s < m) { m = s; bc = c; } }
            asg[i] = bc; sse += m;
        }
        double acc[SFVL_MAX_PROTOTYPES_PER_CLASS * D_MAX]; uint32_t cnt[SFVL_MAX_PROTOTYPES_PER_CLASS];
        memset(acc, 0, sizeof(acc)); memset(cnt, 0, sizeof(cnt));
        for (uint32_t i = 0; i < n; ++i) { ++cnt[asg[i]]; for (uint8_t d = 0; d < D; ++d) acc[asg[i] * D + d] += u[i * D + d]; }
        for (uint8_t c = 0; c < K; ++c) if (cnt[c]) for (uint8_t d = 0; d < D; ++d) cent[c * D + d] = acc[c * D + d] / cnt[c];
    }
    return sse;
}

int SFVLC_Commission(SFVLM_Monitor *mon, const int32_t *feat, const uint16_t *quality, uint32_t n_in, const SFVLC_Params *pp, SFVLC_Report *rep) {
    SFVLC_Params P; if (pp) P = *pp; else SFVLC_ParamsDefaults(&P);
    if (!mon || !feat || !quality || !rep) return -1;
    memset(rep, 0, sizeof(*rep));
    SFVL_Model *m = &mon->model; uint8_t D = m->active_dimensions;
    if (D == 0u || D > D_MAX) return -2;
    if (P.max_modes > m->prototypes_per_class) P.max_modes = m->prototypes_per_class;
    if (P.max_modes == 0u) P.max_modes = 1u;
    static double u[MAXN * D_MAX]; static double raw[MAXN * D_MAX]; static uint8_t asg[MAXN];
    uint32_t n = 0u;
    for (uint32_t i = 0; i < n_in && n < MAXN; ++i) if (quality[i] >= P.quality_min_q) { for (uint8_t d = 0; d < D; ++d) raw[n * D + d] = (double)feat[i * D + d]; ++n; }
    if (n < 30u) return -3;
    rep->used_windows = n;
    double gmed[D_MAX], gsig[D_MAX], tmp[MAXN];
    /* Standardise with a WITHIN-MODE noise estimate obtained from consecutive-window differences:
     * operating modes persist for many windows, so most consecutive pairs lie inside one mode and the
     * median absolute difference is a robust noise scale that is not inflated by between-mode spread.
     * (Commissioning windows must therefore be supplied in time order.) */
    for (uint8_t d = 0; d < D; ++d) {
        for (uint32_t i = 0; i < n; ++i) tmp[i] = raw[i * D + d];
        gmed[d] = median_of(tmp, n);
        for (uint32_t i = 0; i + 1u < n; ++i) tmp[i] = fabs(raw[(i + 1u) * D + d] - raw[i * D + d]);
        gsig[d] = 1.4826 * median_of(tmp, n - 1u) / 1.41421356; if (gsig[d] < P.min_sigma_units) gsig[d] = P.min_sigma_units;
    }
    for (uint32_t i = 0; i < n; ++i) for (uint8_t d = 0; d < D; ++d) u[i * D + d] = (raw[i * D + d] - gmed[d]) / gsig[d];
    /* choose number of modes */
    double cent[SFVL_MAX_PROTOTYPES_PER_CLASS * D_MAX]; uint8_t bestK = 1u;
    /* mode count: the LARGEST K whose SSE drops below split_gain x SSE(K-1) with every mode big enough.
     * All K are scanned (an intermediate K may fail when a merged pair of modes is still elongated). */
    double sse_prev = kmeans(u, n, D, 1u, asg, cent);
    for (uint8_t K = 2; K <= P.max_modes; ++K) {
        double sse = kmeans(u, n, D, K, asg, cent);
        uint32_t cnt[SFVL_MAX_PROTOTYPES_PER_CLASS]; memset(cnt, 0, sizeof(cnt)); for (uint32_t i = 0; i < n; ++i) ++cnt[asg[i]];
        int okc = 1; for (uint8_t c = 0; c < K; ++c) if ((double)cnt[c] < P.min_mode_frac * n) okc = 0;
        if (okc && sse < P.split_gain * sse_prev) bestK = K;
        sse_prev = sse;
    }
    kmeans(u, n, D, bestK, asg, cent);
    rep->modes = bestK;
    /* pooled within-mode robust sigma per dimension */
    double sigma[D_MAX];
    for (uint8_t d = 0; d < D; ++d) {
        double acc = 0, wsum = 0;
        for (uint8_t c = 0; c < bestK; ++c) {
            uint32_t k = 0; for (uint32_t i = 0; i < n; ++i) if (asg[i] == c) tmp[k++] = raw[i * D + d];
            if (k < 5u) continue;
            double med = median_of(tmp, k); for (uint32_t j = 0; j < k; ++j) tmp[j] = fabs(tmp[j] - med);
            double s = 1.4826 * median_of(tmp, k); acc += s * s * k; wsum += k;
        }
        sigma[d] = wsum > 0 ? sqrt(acc / wsum) : gsig[d]; if (sigma[d] < P.min_sigma_units) sigma[d] = P.min_sigma_units;
        rep->sigma[d] = sigma[d];
        if (SFVL_SetNormalizationReference(m, d, (int32_t)llround(gmed[d]), (uint32_t)llround(sigma[d])) != 0) return -4;
    }
    /* seed one prototype per mode from members expressed in the model's own normalised units */
    m->unknown_join_threshold_sq = (uint64_t)D * 4096u * 2u;
    for (uint8_t c = 0; c < bestK; ++c) {
        static int32_t nrm[MAXN * D_MAX]; uint32_t k = 0; double mean[D_MAX] = {0}, var[D_MAX] = {0};
        for (uint32_t i = 0; i < n; ++i) if (asg[i] == c) {
            int32_t rawv[D_MAX], nv[D_MAX]; for (uint8_t d = 0; d < D; ++d) rawv[d] = (int32_t)llround(raw[i * D + d]);
            SFVL_Normalize(m, rawv, nv); for (uint8_t d = 0; d < D; ++d) { nrm[k * D + d] = nv[d]; mean[d] += nv[d]; } ++k;
        }
        if (k < 5u) return -5;
        for (uint8_t d = 0; d < D; ++d) mean[d] /= k;
        for (uint32_t j = 0; j < k; ++j) for (uint8_t d = 0; d < D; ++d) { double t = nrm[j * D + d] - mean[d]; var[d] += t * t; }
        int32_t ctr[D_MAX]; uint32_t scl[D_MAX];
        for (uint8_t d = 0; d < D; ++d) { ctr[d] = (int32_t)llround(mean[d]); double mad = 0; for (uint32_t j = 0; j < k; ++j) mad += fabs(nrm[j * D + d] - mean[d]); mad /= k;
            /* the core's online update tracks the MEAN ABSOLUTE deviation as the per-dimension scale, so seed with the same statistic:
             * the metric then does not jump at the first authorised update. */
            (void)var; if (mad < 256.0) mad = 256.0; scl[d] = (uint32_t)llround(mad); }
        if (SFVL_SeedPrototypeFull(m, 0u, c, ctr, scl, 1u, 0u, k) != 0) return -6;   /* temporary radius, re-measured next */
        double rad[MAXN]; double rm = 0;
        for (uint32_t j = 0; j < k; ++j) { uint64_t d2 = SFVL_DistanceSq(m, &m->proto[0][c], &nrm[j * D]); rad[j] = (double)SFVL_Isqrt64(d2); rm += rad[j]; }
        rm /= k; double mad = 0; for (uint32_t j = 0; j < k; ++j) mad += fabs(rad[j] - rm); mad /= k;
        double rmm = rm * P.radius_margin, madm = mad * P.radius_margin; if (rmm < 1.0) rmm = 1.0;
        if (SFVL_SeedPrototypeFull(m, 0u, c, ctr, scl, (uint32_t)llround(rmm), (uint32_t)llround(madm), k) != 0) return -6;
        rep->mode_count[c] = k; rep->radius_mean[c] = (uint32_t)llround(rmm);
        rep->threshold_radius[c] = SFVL_Isqrt64(m->proto[0][c].threshold_sq);
    }
    rep->ok = 1;
    return SFVLM_Arm(mon);
}
