/* sfvibraledger_eval - evaluate SF-VibraLedger on YOUR recorded vibration/current data (host tool, read-only on input).
 *
 *   sfvibraledger_eval --input data.csv --fs 10240 --calib-windows 90 --freqs 24.7,49.4 [--window 2048] [--skip-cols 0]
 *                [--full-scale 32767] [--out result.csv] [--audit audit.txt] [--no-adapt] [--key SECRET]
 *
 * The first --calib-windows windows (time-ordered!) are taken as HEALTHY reference (all operating modes you want
 * treated as normal must be present). The remaining windows are monitored. Output is one row per window.
 * Nothing is uploaded, nothing is modified: the tool only reads the input and writes the files you name.
 */
#define _POSIX_C_SOURCE 200809L
#include "SFVibraLedger_Commission.h"
#include "SFVibraLedger_Features.h"
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *STATUS_NAME[6] = {"HEALTHY", "TRANSIENT", "WATCH", "WARNING", "ALARM", "DRIFT_LIMIT"};

static int parse_row(char *line, int skip, double *vals, int max) {
    int n = 0, col = 0; char *save = NULL;
    for (char *tok = strtok_r(line, ",;\t \r\n", &save); tok; tok = strtok_r(NULL, ",;\t \r\n", &save), ++col) {
        if (col < skip) continue;
        char *end; double v = strtod(tok, &end); if (end == tok) return -1;
        if (n < max) vals[n++] = v;
    }
    return n;
}

int main(int argc, char **argv) {
    const char *in = NULL, *out = NULL, *aud = NULL, *key = "sfvibraledger-eval-default-key"; double fs = 10240.0; unsigned win = 2048, calib = 90; int skip = 0, noadapt = 0; int32_t full = 32767;
    double freqs[4]; int nb = 0;
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--input") && i + 1 < argc) in = argv[++i]; else if (!strcmp(argv[i], "--fs") && i + 1 < argc) fs = atof(argv[++i]);
        else if (!strcmp(argv[i], "--window") && i + 1 < argc) win = (unsigned)atoi(argv[++i]); else if (!strcmp(argv[i], "--calib-windows") && i + 1 < argc) calib = (unsigned)atoi(argv[++i]);
        else if (!strcmp(argv[i], "--skip-cols") && i + 1 < argc) skip = atoi(argv[++i]); else if (!strcmp(argv[i], "--full-scale") && i + 1 < argc) full = (int32_t)atol(argv[++i]);
        else if (!strcmp(argv[i], "--out") && i + 1 < argc) out = argv[++i]; else if (!strcmp(argv[i], "--audit") && i + 1 < argc) aud = argv[++i];
        else if (!strcmp(argv[i], "--key") && i + 1 < argc) key = argv[++i]; else if (!strcmp(argv[i], "--no-adapt")) noadapt = 1;
        else if (!strcmp(argv[i], "--freqs") && i + 1 < argc) { char *s = argv[++i], *sv = NULL; for (char *t = strtok_r(s, ",", &sv); t && nb < 4; t = strtok_r(NULL, ",", &sv)) freqs[nb++] = atof(t); }
        else { fprintf(stderr, "unknown or incomplete option: %s\nsee header of sfvibraledger_eval.c for usage\n", argv[i]); return 2; }
    }
    if (!in) { fprintf(stderr, "usage: sfvibraledger_eval --input data.csv --fs HZ [--calib-windows N] [--freqs f1,f2] [--window N] [--skip-cols K] [--out file] [--audit file] [--no-adapt]\n"); return 2; }
    FILE *fp = fopen(in, "r"); if (!fp) { perror("input"); return 2; }
    size_t cap = 1u << 16, rows = 0; double *data = NULL; int ch = -1; char line[65536]; double vals[64];
    while (fgets(line, sizeof(line), fp)) {
        char tmp[65536]; strncpy(tmp, line, sizeof(tmp) - 1); tmp[sizeof(tmp) - 1] = 0; int n = parse_row(tmp, skip, vals, 64);
        if (n <= 0) { if (rows == 0) continue; fprintf(stderr, "bad row %zu\n", rows + 1); return 2; }              /* header lines are skipped */
        if (ch < 0) { ch = n; data = (double *)malloc(cap * (size_t)ch * sizeof(double)); } if (n != ch) { fprintf(stderr, "row %zu has %d columns, expected %d\n", rows + 1, n, ch); return 2; }
        if (rows >= cap) { cap *= 2; data = (double *)realloc(data, cap * (size_t)ch * sizeof(double)); } memcpy(&data[rows * (size_t)ch], vals, (size_t)ch * sizeof(double)); ++rows;
    }
    fclose(fp); if (ch <= 0 || rows < (size_t)win * (calib + 5u)) { fprintf(stderr, "not enough data: %zu rows, need >= %u\n", rows, win * (calib + 5u)); return 2; }
    unsigned per = 3u + (unsigned)nb, dims = (unsigned)ch * per; if (dims > SFVL_MAX_DIMENSIONS) { fprintf(stderr, "channels(%d) x features(%u) = %u > %u dimensions; use fewer channels/bands\n", ch, per, dims, SFVL_MAX_DIMENSIONS); return 2; }
    SFVLF_Config fc; SFVLF_ConfigInit(&fc); fc.full_scale = full; fc.bands = (uint8_t)nb; for (int b = 0; b < nb; ++b) fc.goertzel_coeff_q22[b] = (int32_t)llround(2.0 * cos(6.283185307179586 * freqs[b] / fs) * 4194304.0);
    unsigned nwin = (unsigned)(rows / win); int32_t *F = (int32_t *)calloc((size_t)nwin * dims, sizeof(int32_t)); uint16_t *Q = (uint16_t *)calloc(nwin, sizeof(uint16_t)); double *rmsmax = (double *)calloc(nwin, sizeof(double)); int32_t *buf = (int32_t *)malloc(win * sizeof(int32_t));
    for (unsigned w = 0; w < nwin; ++w) {
        uint16_t qmin = 1024; double rm = 0;
        for (int c = 0; c < ch; ++c) {
            for (unsigned i = 0; i < win; ++i) { double v = data[((size_t)w * win + i) * (size_t)ch + (size_t)c]; if (v > 1e9) v = 1e9; if (v < -1e9) v = -1e9; buf[i] = (int32_t)llround(v); }
            SFVLF_Features f; int rc = SFVLF_Extract(buf, win, &fc, &f); if (rc) { fprintf(stderr, "feature extraction failed (rc=%d): window must be 16..4096 samples\n", rc); return 2; }
            SFVLF_ToModelVector(&f, &fc, &F[(size_t)w * dims + (unsigned)c * per]); if (f.quality_q < qmin) qmin = f.quality_q; if (f.rms > rm) rm = f.rms;
        }
        Q[w] = qmin; rmsmax[w] = rm;
    }
    static SFVLM_Monitor mon; SFVLM_Config cfg; SFVLM_ConfigDefaults(&cfg); if (noadapt) cfg.adapt_enabled = 0;
    if (SFVLM_Init(&mon, (uint8_t)dims, 1, 4, &cfg, (const uint8_t *)key, strlen(key) > 32 ? 32 : strlen(key)) != 0) return 2;
    SFVLC_Report rep; int rc = SFVLC_Commission(&mon, F, Q, calib, NULL, &rep);
    if (rc != 0) { fprintf(stderr, "commissioning failed (rc=%d): need >=30 good-quality healthy windows\n", rc); return 3; }
    printf("input: %zu samples x %d channels @ %.0f Hz -> %u windows of %u samples (%.0f ms)\n", rows, ch, fs, nwin, win, 1000.0 * win / fs);
    printf("commissioned on %u healthy windows: %u operating mode(s) found, dims=%u\n", rep.used_windows, rep.modes, dims);
    FILE *fo = out ? fopen(out, "w") : NULL; if (fo) fprintf(fo, "window,time_s,status,health_q,deviation_q,drift_q,learned,quality_q,max_channel_rms\n");
    unsigned counts[6] = {0}; long first_alert = -1, first_watch = -1; SFVLM_Output o;
    for (unsigned w = calib; w < nwin; ++w) {
        if (SFVLM_Update(&mon, &F[(size_t)w * dims], Q[w], &o) != 0) { fprintf(stderr, "monitor update failed at window %u\n", w); return 3; }
        ++counts[o.status]; if (o.status >= SFVLM_WARNING && first_alert < 0) first_alert = (long)w; if (o.status == SFVLM_WATCH && first_watch < 0) first_watch = (long)w;
        if (fo) fprintf(fo, "%u,%.3f,%s,%u,%u,%u,%u,%u,%.0f\n", w, (double)w * win / fs, STATUS_NAME[o.status], o.health_q, o.deviation_q, o.drift_q, o.learned, Q[w], rmsmax[w]);
    }
    if (fo) fclose(fo);
    printf("monitored %u windows: HEALTHY=%u TRANSIENT=%u WATCH=%u WARNING=%u ALARM=%u DRIFT_LIMIT=%u\n", nwin - calib, counts[0], counts[1], counts[2], counts[3], counts[4], counts[5]);
    if (first_alert >= 0) printf("FIRST ALERT (WARNING or higher): window %ld (t=%.1f s)\n", first_alert, (double)first_alert * win / fs); else printf("no WARNING/ALARM raised\n");
    printf("authorised adaptations applied: %u; audit chain entries: %u (verify: %s)\n", mon.learn_total, SFVLAL_Count(&mon.audit), SFVLAL_Verify(&mon.audit, (const uint8_t *)key, strlen(key) > 32 ? 32 : strlen(key)) == 0 ? "OK" : "FAILED");
    if (aud) { FILE *fa = fopen(aud, "w"); if (fa) { char l[512]; for (uint32_t i = 0; i < SFVLAL_Count(&mon.audit); ++i) { SFVLAL_ExportLine(&mon.audit, i, l, sizeof(l)); fprintf(fa, "%s\n", l); } fclose(fa); } }
    return 0;
}
