/* Flat C API used by the Python validation harness (ctypes). Host-only. */
#include "SFVibraLedger_Commission.h"
#include "SFVibraLedger_Features.h"
#include <stdlib.h>
#include <string.h>

typedef struct { SFVLM_Monitor mon; SFVL_Result last; } XSShim;

void *xs_new(void) { XSShim *s = (XSShim *)calloc(1, sizeof(*s)); return s; }
void xs_free(void *h) { free(h); }
size_t xs_sizeof_monitor(void) { return sizeof(SFVLM_Monitor); }
size_t xs_sizeof_model(void) { return sizeof(SFVL_Model); }

int xs_init(void *h, int dims, int classes, int ppc, const uint8_t *key, int key_len) {
    XSShim *s = (XSShim *)h; return SFVLM_Init(&s->mon, (uint8_t)dims, (uint8_t)classes, (uint8_t)ppc, NULL, key, (size_t)key_len);
}
/* id: 0 warn_persistence 1 alarm_persistence 2 recover_windows 3 watch_ratio_q 4 alarm_ratio_q 5 drift_limit_q 6 adapt_enabled 7 audit_every
 *     100 learn_margin_sq 101 learn_slack_sq 102 min_sensor_quality_q 103 min_trust_for_learn_q 104 trust_learn_cost_q
 *     105 trust_decay_per_epoch_q 106 base_alpha_fp 107 unknown_join_threshold_sq 108 unknown_promote_hits 109 min_trust_for_maturity_q */
int xs_set(void *h, int id, uint64_t v) {
    XSShim *s = (XSShim *)h; SFVLM_Config *c = &s->mon.cfg; SFVL_Model *m = &s->mon.model;
    switch (id) {
    case 0: c->warn_persistence = (uint8_t)v; break; case 1: c->alarm_persistence = (uint8_t)v; break;
    case 2: c->recover_windows = (uint16_t)v; break; case 3: c->watch_ratio_q = (uint32_t)v; break;
    case 4: c->alarm_ratio_q = (uint32_t)v; break; case 5: c->drift_limit_q = (uint32_t)v; break;
    case 6: c->adapt_enabled = (uint8_t)v; break; case 7: c->audit_every_n_learn = (uint8_t)v; break;
    case 100: m->learn_margin_sq = v; break; case 101: m->learn_slack_sq = v; break;
    case 102: m->min_sensor_quality_q = (uint32_t)v; break; case 103: m->min_trust_for_learn_q = (uint32_t)v; break;
    case 104: m->trust_learn_cost_q = (uint32_t)v; break; case 105: m->trust_decay_per_epoch_q = (uint32_t)v; break;
    case 106: m->base_alpha_fp = (uint32_t)v; break; case 107: m->unknown_join_threshold_sq = v; break;
    case 108: m->unknown_promote_hits = (uint32_t)v; break; case 109: m->min_trust_for_maturity_q = (uint32_t)v; break;
    default: return -1;
    }
    return 0;
}
/* report: [ok, used, modes, sigma[16], count[4], thr_radius[4]] as int64 */
int xs_commission(void *h, const int32_t *feat, const uint16_t *q, uint32_t n, int64_t *rep) {
    XSShim *s = (XSShim *)h; SFVLC_Report r; SFVLC_Params p; SFVLC_ParamsDefaults(&p);
    int rc = SFVLC_Commission(&s->mon, feat, q, n, &p, &r);
    rep[0] = r.ok; rep[1] = r.used_windows; rep[2] = r.modes;
    for (int i = 0; i < 16; ++i) rep[3 + i] = (int64_t)(r.sigma[i] * 1000.0);
    for (int i = 0; i < 4; ++i) { rep[19 + i] = r.mode_count[i]; rep[23 + i] = r.threshold_radius[i]; }
    return rc;
}
/* out: status, class, proto, learned, health, deviation, drift, window, learn_total, generation */
int xs_update(void *h, const int32_t *feat, int quality, int64_t *out) {
    XSShim *s = (XSShim *)h; SFVLM_Output o; int rc = SFVLM_Update(&s->mon, feat, (uint16_t)quality, &o);
    if (rc) return rc;
    out[0] = o.status; out[1] = o.matched_class; out[2] = o.matched_prototype; out[3] = o.learned; out[4] = o.health_q;
    out[5] = o.deviation_q; out[6] = o.drift_q; out[7] = o.window_index; out[8] = s->mon.learn_total; out[9] = s->mon.model.generation;
    return 0;
}
int xs_audit_verify(void *h, const uint8_t *key, int kl) { XSShim *s = (XSShim *)h; return SFVLAL_Verify(&s->mon.audit, key, (size_t)kl); }
uint32_t xs_audit_count(void *h) { return SFVLAL_Count(&((XSShim *)h)->mon.audit); }
uint64_t xs_audit_dropped(void *h) { return SFVLAL_DroppedCount(&((XSShim *)h)->mon.audit); }
size_t xs_audit_line(void *h, uint32_t i, char *buf, size_t cap) { return SFVLAL_ExportLine(&((XSShim *)h)->mon.audit, i, buf, cap); }

/* ---- raw core access for the real-data / ablation experiments ---- */
int xs_core_setnorm(void *h, int d, int32_t c, uint32_t sc) { return SFVL_SetNormalizationReference(&((XSShim *)h)->mon.model, (uint8_t)d, c, sc); }
int xs_core_seed(void *h, int cls, int slot, const int32_t *ctr, const uint32_t *scl, uint32_t rm, uint32_t rmad, uint32_t hits) {
    return SFVL_SeedPrototypeFull(&((XSShim *)h)->mon.model, (uint8_t)cls, (uint8_t)slot, ctr, scl, rm, rmad, hits);
}
uint64_t xs_core_dist(void *h, int cls, int slot, const int32_t *norm) { SFVL_Model *m = &((XSShim *)h)->mon.model; return SFVL_DistanceSq(m, &m->proto[cls][slot], norm); }
/* out: status, class, proto, eligible, mask, quality, trust, best_d2(as double ok), thr */
int xs_core_process(void *h, const int32_t *norm, int quality, int64_t *out) {
    XSShim *s = (XSShim *)h; SFVL_Result *r = &s->last; int rc = (int)SFVL_Process(&s->mon.model, norm, (uint16_t)quality, r);
    out[0] = r->status; out[1] = r->predicted_class; out[2] = r->predicted_prototype; out[3] = r->learn_eligible; out[4] = r->evidence_mask;
    out[5] = r->sensor_quality_q; out[6] = r->trust_q; out[7] = (int64_t)(r->best_distance_sq > INT64_MAX ? INT64_MAX : r->best_distance_sq);
    return rc;
}
int xs_core_learn(void *h, const int32_t *norm) { XSShim *s = (XSShim *)h; return SFVL_FeedbackLearnGated(&s->mon.model, &s->last.token, norm); }
int xs_core_center(void *h, int cls, int slot, int32_t *out16) { SFVL_Model *m = &((XSShim *)h)->mon.model; for (int d = 0; d < 16; ++d) out16[d] = m->proto[cls][slot].center[d]; return m->proto[cls][slot].valid; }
uint32_t xs_core_generation(void *h) { return ((XSShim *)h)->mon.model.generation; }

/* ---- feature extraction: returns model-vector length; raw[]: mean,rms,peak,crest_q,kurt_q,band0..3 ; qout: quality ---- */
int xs_features(const int32_t *x, uint32_t n, int32_t full_scale, int nb, const int32_t *coeff_q22, int32_t *vec, int64_t *raw, int *qout) {
    SFVLF_Config c; SFVLF_ConfigInit(&c); c.full_scale = full_scale; c.bands = (uint8_t)nb;
    for (int i = 0; i < nb && i < (int)SFVLF_MAX_BANDS; ++i) c.goertzel_coeff_q22[i] = coeff_q22[i];
    SFVLF_Features f; int rc = SFVLF_Extract(x, n, &c, &f); if (rc) return rc;
    raw[0] = f.mean; raw[1] = f.rms; raw[2] = f.peak; raw[3] = f.crest_q; raw[4] = f.kurt_q;
    for (int i = 0; i < 4; ++i) raw[5 + i] = f.band_amp[i];
    *qout = f.quality_q; return SFVLF_ToModelVector(&f, &c, vec);
}
