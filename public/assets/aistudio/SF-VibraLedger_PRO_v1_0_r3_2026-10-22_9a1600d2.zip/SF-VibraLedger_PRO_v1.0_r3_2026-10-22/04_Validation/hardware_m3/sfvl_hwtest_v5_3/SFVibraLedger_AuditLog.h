#ifndef SFVIBRALEDGER_AUDITLOG_H
#define SFVIBRALEDGER_AUDITLOG_H

/*
 * Bounded Adaptation Audit Log
 * ----------------------------
 * STATUS: IMPLEMENTED - validated by host-side tests (Source/Tests) only; not run on target hardware. Not yet wired into SFVibraLedger_Wire as a
 *         capability flag (SFVL_WIRE_CAP_AUDIT_LOG would be the natural slot -
 *         see Core/SFVibraLedger_Wire.h's existing SFVL_WIRE_CAP_* pattern, which
 *         this module deliberately mirrors: same (key, key_len) HMAC
 *         convention, so it can be added there without inventing a second
 *         authentication scheme). Not run on target hardware.
 *
 * WHY THIS EXISTS
 * ---------------
 * This is NOT presented as a new patentable core mechanism. A hash-chained,
 * tamper-evident log of model-update events is a well-established general
 * technique (e.g. US8230228B2, IBM, 2008, tamper detection for a log of
 * records) and has already been proposed specifically for ML model updates
 * very recently (Yuan et al., "AuditableLLM: A Hash-Chain-Backed,
 * Compliance-Aware Auditable Framework for Large Language Models",
 * Electronics 15(1):56, 2026; and a 2026 defensive publication on
 * tdcommons.org describing an HMAC-chained forensic log plus atomic model
 * rollback for AI incident response). Both of those target cloud-scale /
 * LLM-scale systems. Claiming the general idea of "a hash-chained audit
 * log for ML updates" here would be claiming something that already
 * exists; this module does not attempt that.
 *
 * What IS new here, if anything, is narrower: a fixed-capacity, allocation-
 * free, O(1)-per-append implementation sized for microcontroller-class
 * hardware, whose entries are not a generic "what happened" record but the
 * SAME evidence_mask / decayed-trust value / token fingerprint / generation
 * pair already produced by SFVL_Process and SFVL_FeedbackLearnGated (i.e.
 * the log is a direct, structural byproduct of the evidence gate and Trust
 * Ledger already implemented, not a bolted-on separate subsystem), reusing
 * the project's existing HMAC key rather than a second key. Treat this as
 * a supporting / dependent claim candidate at best, not an independent
 * pillar - see Patent/PROPOSED_ADDENDUM_Trust_Ledger.md for where this
 * honestly sits in the claim strategy.
 *
 * Why it is useful commercially: a machine that keeps adapting after deployment needs an
 * exportable answer to "what did this device change, when, and on what evidence?" -
 * for the customer's quality/maintenance records. This module does not by itself make any
 * regulatory-compliance claim.
 *
 * DESIGN CHOICES
 * --------------
 * - Fixed-capacity ring buffer (SFVLAL_CAPACITY entries): bounded RAM,
 *   deterministic, no dynamic allocation.
 * - When capacity is exceeded, OLDEST entries are silently overwritten -
 *   this module refuses to pretend completeness: `SFVLAL_DroppedCount()`
 *   reports exactly how many entries have been evicted, so an exporting
 *   system can honestly disclose a gap instead of implying full history.
 * - Each entry's chain_hash = HMAC-SHA256(key, previous chain_hash (or a
 *   fixed genesis value) || this entry's other fields). Verification
 *   requires the same key; without it, an attacker who can rewrite the
 *   log can produce an internally-consistent chain, so this is
 *   tamper-EVIDENT against a verifier holding the key, not
 *   tamper-PROOF against an attacker who has extracted it - the same
 *   trust model already accepted for SFVibraLedger_Wire's model-integrity HMAC.
 */

#include <stdint.h>
#include <stddef.h>

#ifndef SFVLAL_CAPACITY
#define SFVLAL_CAPACITY 32u
#endif

#define SFVLAL_OUTCOME_APPLIED 0u
#define SFVLAL_OUTCOME_ISSUED_NOT_REDEEMED 1u
#define SFVLAL_OUTCOME_REJECTED 2u
#define SFVLAL_OUTCOME_ESCALATION 3u /* monitor status escalation; reject_code carries the new status */

typedef struct {
    uint32_t epoch;
    uint32_t generation_before;
    uint32_t generation_after;
    uint8_t predicted_class;
    uint8_t predicted_prototype;
    uint8_t evidence_mask;
    uint8_t outcome;
    int8_t reject_code;
    uint8_t reserved[3];
    uint32_t trust_at_decision_q;
    uint64_t sample_fingerprint;
    uint8_t chain_hash[32];
} SFVLAL_Entry;

typedef struct {
    SFVLAL_Entry entries[SFVLAL_CAPACITY];
    uint32_t next_index;
    uint32_t count;
    uint64_t total_appended;
    uint8_t genesis_hash[32];
    uint8_t window_anchor_hash[32]; /* hash the oldest RETAINED entry actually chained from;
                                        == genesis_hash until the first eviction, then rolls
                                        forward to the evicted entry's own hash each time an
                                        older entry falls out of the fixed-capacity window. */
} SFVLAL_Log;

void SFVLAL_Init(SFVLAL_Log *log);
int SFVLAL_Append(SFVLAL_Log *log, const uint8_t *key, size_t key_len,
                uint32_t epoch, uint32_t generation_before, uint32_t generation_after,
                uint8_t predicted_class, uint8_t predicted_prototype, uint8_t evidence_mask,
                uint8_t outcome, int8_t reject_code, uint32_t trust_at_decision_q,
                uint64_t sample_fingerprint);

uint64_t SFVLAL_DroppedCount(const SFVLAL_Log *log);
uint32_t SFVLAL_Count(const SFVLAL_Log *log);

/* Returns 0 if the entire retained chain verifies against `key`, anchored
 * correctly whether or not eviction has occurred (see window_anchor_hash).
 * Otherwise returns (1 + the in-window position of the first entry whose
 * chain_hash does not match), oldest-first. */
int SFVLAL_Verify(const SFVLAL_Log *log, const uint8_t *key, size_t key_len);

/* Human-readable single-line export of one in-window entry (oldest-first
 * indexing), for the transparency/human-oversight side of things. Returns
 * the number of bytes written (excluding NUL), or 0 on error. */
size_t SFVLAL_ExportLine(const SFVLAL_Log *log, uint32_t window_index, char *buf, size_t buf_cap);

#endif
