#ifndef SFVIBRALEDGER_FEATURES_H
#define SFVIBRALEDGER_FEATURES_H
/*
 * SF-VibraLedger window feature extraction (integer only, no dynamic memory, no libm).
 *
 * Turns one window of raw sensor samples (e.g. an accelerometer or current channel) into the
 * condition-monitoring features used in industrial practice: AC-RMS, peak, crest factor,
 * kurtosis, narrow-band tone amplitudes (Goertzel) and a signal-integrity quality score.
 * All quantities are deterministic for identical input on every conforming C11 target.
 *
 * Bounds (enforced, documented, tested): 16 <= n <= 4096 samples; |x| < 2^30; Goertzel
 * angular frequency >= 0.01 rad/sample (coefficient in Q22, |c| <= 2^23).
 */
#include <stdint.h>
#include <stddef.h>

#define SFVLF_MIN_WINDOW 16u
#define SFVLF_MAX_WINDOW 4096u
#define SFVLF_MAX_BANDS 4u
#define SFVLF_Q 1024u

#define SFVLF_FLAG_SATURATION 0x01u
#define SFVLF_FLAG_FLATLINE   0x02u
#define SFVLF_FLAG_DROPOUT    0x04u

typedef struct {
    int32_t  full_scale;                      /* ADC full-scale magnitude (0 = unknown / disable saturation test) */
    uint8_t  bands;                           /* 0..SFVLF_MAX_BANDS */
    int32_t  goertzel_coeff_q22[SFVLF_MAX_BANDS]; /* 2*cos(2*pi*f/fs) in Q22, supplied by commissioning */
    uint32_t min_rms;                         /* below this AC-RMS the channel is considered flat-lined */
} SFVLF_Config;

typedef struct {
    int32_t  mean;
    uint32_t rms;                             /* AC-RMS about the window mean */
    uint32_t peak;                            /* max |x - mean| */
    uint32_t crest_q;                         /* peak / rms, Q10 */
    uint32_t kurt_q;                          /* kurtosis, Q10 (Gaussian ~ 3072) */
    uint32_t band_amp[SFVLF_MAX_BANDS];        /* tone amplitude (same unit as samples) */
    uint16_t quality_q;                       /* 0..1024 signal-integrity score */
    uint8_t  flags;
    uint8_t  reserved;
} SFVLF_Features;

typedef enum { SFVLF_OK = 0, SFVLF_ERR_ARG = -1, SFVLF_ERR_RANGE = -2 } SFVLF_Status;

void SFVLF_ConfigInit(SFVLF_Config *cfg);
int  SFVLF_Extract(const int32_t *x, uint32_t n, const SFVLF_Config *cfg, SFVLF_Features *out);

/* log2(v) in Q10 (v>=1; v==0 returns 0). Table + linear interpolation, max error < 0.003 octave. */
int32_t SFVLF_Log2Q(uint32_t v);

/* Build the model input vector for one channel: [log2 rms, log2 crest, log2 kurt, log2 (band+1) ...].
 * Returns the number of values written (3 + bands). */
uint8_t SFVLF_ToModelVector(const SFVLF_Features *f, const SFVLF_Config *cfg, int32_t *out);

#endif
