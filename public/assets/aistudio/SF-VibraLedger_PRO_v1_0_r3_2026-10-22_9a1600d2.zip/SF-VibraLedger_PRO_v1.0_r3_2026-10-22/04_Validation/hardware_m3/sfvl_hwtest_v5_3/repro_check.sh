#!/usr/bin/env bash
# =============================================================================
#  SF-VibraLedger - build repeatability check (two clean builds, same environment)
#
#  usage:  bash repro_check.sh                 (from the sfvl_hwtest directory)
#  env:    BUILD_ARGS="HWT_CYCLES=1 HWT_STACKINFO=1"   make arguments for BOTH builds
#          ORIGINAL_ELF=<path>   optional: also compare with an earlier release ELF (READ ONLY)
#          FULL_CLEAN=1          (default) delete bin/<board> before each build, i.e. RIOT objects too
#
#  What a result means - and does not:
#    A == B  : two clean builds in THIS environment gave identical bytes.  It is NOT a formal
#              reproducible-build proof (same machine, same paths, same clock behaviour).
#    A != B  : something non-deterministic or stale is in the build; see the report.
#    vs ORIGINAL_ELF is only meaningful if sources, Makefile and BUILD_ARGS equal those of the
#    original build; the report prints sizes so a flag mismatch (e.g. timing code on/off) is visible.
#  Nothing outside a NEW verification directory is written, except bin/<board> of this app.
# =============================================================================
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$HERE" || exit 5
PROJ="$(cd "$HERE/.." && pwd)"
BOARD="${BOARD:-iotlab-m3}"
BUILD_ARGS="${BUILD_ARGS:-}"
FULL_CLEAN="${FULL_CLEAN:-1}"
ORIGINAL_ELF="${ORIGINAL_ELF:-}"
APP="sfvl_hwtest"; ELF="$HERE/bin/$BOARD/$APP.elf"
VDIR="$PROJ/verification_repro_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$VDIR" || { echo "cannot create $VDIR"; exit 5; }
REPORT="$VDIR/repro_report.txt"
say() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }
die() { say "FATAL: $*"; exit 5; }

# never delete anything that is, or lives next to, a file we were told to protect
case "$ORIGINAL_ELF" in "$HERE"/bin/*) die "ORIGINAL_ELF lives inside bin/ which this script deletes - copy it elsewhere first";; esac
[ -n "$ORIGINAL_ELF" ] && [ ! -f "$ORIGINAL_ELF" ] && die "ORIGINAL_ELF not found: $ORIGINAL_ELF"
for t in make sha256sum arm-none-eabi-gcc; do command -v "$t" >/dev/null 2>&1 || die "missing tool: $t"; done
[ -f "$PROJ/RIOT/Makefile.include" ] || die "no RIOT checkout at $PROJ/RIOT"

bin_hash() {   # hash of the flashable image (ELF metadata stripped); n/a if objcopy is missing
  if command -v arm-none-eabi-objcopy >/dev/null 2>&1; then
    arm-none-eabi-objcopy -O binary "$1" "$VDIR/tmp.bin" 2>/dev/null && sha256sum "$VDIR/tmp.bin" | cut -d' ' -f1 || echo "n/a"
  else echo "n/a"; fi
}
size_of() { command -v arm-none-eabi-size >/dev/null 2>&1 && arm-none-eabi-size "$1" | tail -1 | awk '{print "text="$1" data="$2" bss="$3}' || echo "n/a"; }

build_one() {   # $1 = label
  local label="$1" log="$VDIR/build_$1.log" skew
  if [ "$FULL_CLEAN" = "1" ]; then rm -rf "$HERE/bin/$BOARD"; else rm -rf "$HERE/bin/$BOARD/application_$APP" "$ELF"; fi
  say "build $label ..."
  # shellcheck disable=SC2086
  make BOARD="$BOARD" $BUILD_ARGS > "$log" 2>&1 || { say "build $label FAILED"; tail -20 "$log"; return 1; }
  [ -f "$ELF" ] || { say "no ELF after build $label"; return 1; }
  cp "$ELF" "$VDIR/repro_$label.elf"
  skew="$(grep -ciE 'clock skew|modification time .* in the future|dans le futur' "$log")"
  eval "SKEW_$label=$skew"
  say "build $label: elf=$(sha256sum "$ELF" | cut -d' ' -f1) $(size_of "$ELF") skew-warnings=$skew"
}

say "environment: $(arm-none-eabi-gcc --version | head -1) | RIOT $(cd "$PROJ/RIOT" && git describe --always 2>/dev/null) | $(date -u '+%F %T') UTC"
SKEW_A=0; SKEW_B=0
build_one A || exit 3
build_one B || exit 3
HA="$(sha256sum "$VDIR/repro_A.elf" | cut -d' ' -f1)"; HB="$(sha256sum "$VDIR/repro_B.elf" | cut -d' ' -f1)"
BA="$(bin_hash "$VDIR/repro_A.elf")"; BB="$(bin_hash "$VDIR/repro_B.elf")"
SRC="$(cat Makefile main.c hwt_hash.h sfvl_hwtest_data.h SFVibraLedger_*.[ch] 2>/dev/null | sha256sum | cut -d' ' -f1)"

{
  echo "SF-VibraLedger build repeatability check"
  echo "time          : $(date -u '+%F %T') UTC"
  echo "toolchain     : $(arm-none-eabi-gcc --version | head -1)"
  echo "RIOT          : $(cd "$PROJ/RIOT" && git describe --always 2>/dev/null)"
  echo "build args    : ${BUILD_ARGS:-<defaults>}   full clean between builds: $FULL_CLEAN"
  echo "source hash   : $SRC"
  echo "build A       : $HA  $(size_of "$VDIR/repro_A.elf")  skew-warnings=$SKEW_A"
  echo "build B       : $HB  $(size_of "$VDIR/repro_B.elf")  skew-warnings=$SKEW_B"
  echo "image A / B   : $BA / $BB   (objcopy -O binary)"
  if [ "$HA" = "$HB" ]; then
    echo "A vs B        : IDENTICAL ELF bytes"
    VERDICT="two clean builds in this environment are byte-identical"
  elif [ "$BA" != "n/a" ] && [ "$BA" = "$BB" ]; then
    echo "A vs B        : ELF differs but the flashable image is identical (metadata/debug only)"
    VERDICT="flashable images identical; ELF metadata differs"
  else
    echo "A vs B        : DIFFERENT"
    VERDICT="builds differ - non-deterministic or stale inputs"
  fi
  if [ -n "$ORIGINAL_ELF" ]; then
    HO="$(sha256sum "$ORIGINAL_ELF" | cut -d' ' -f1)"
    echo "original ELF  : $HO  $(size_of "$ORIGINAL_ELF")  ($ORIGINAL_ELF, read only)"
    if [ "$HO" = "$HA" ]; then echo "A vs original : IDENTICAL"; else echo "A vs original : different (expected if sources, Makefile or BUILD_ARGS differ from the original build - compare the sizes above)"; fi
  fi
  echo "verdict       : $VERDICT"
  echo "limits        : same machine/paths/toolchain; clock-skew warnings A=$SKEW_A B=$SKEW_B may mean an incomplete incremental build (FULL_CLEAN=1 avoids stale objects); this is not a formal reproducible-build claim."
  echo "artifacts     : $VDIR"
} | tee "$REPORT"
rm -f "$VDIR/tmp.bin"
[ "$HA" = "$HB" ] && exit 0 || exit 1
