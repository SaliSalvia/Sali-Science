/* Minimal self-contained SHA-256 (FIPS 180-4) for embedded use.
 * No dynamic allocation, no external dependencies. Written from the
 * public FIPS 180-4 specification for use as VibraLedger's
 * model-integrity primitive (HMAC-SHA256 over serialized buffers). */
#ifndef SF_SHA256_H
#define SF_SHA256_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>

typedef struct {
    uint32_t state[8];
    uint64_t bitlen;
    uint8_t  buf[64];
    size_t   buflen;
} sf_sha256_ctx_t;

static const uint32_t SF_SHA256_K[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

#define SF_ROTR(x,n) (((x)>>(n))|((x)<<(32-(n))))

static void sf_sha256_transform(sf_sha256_ctx_t *ctx, const uint8_t data[64]) {
    uint32_t w[64], a,b,c,d,e,f,g,h;
    for (int i = 0; i < 16; i++)
        w[i] = ((uint32_t)data[i*4]<<24)|((uint32_t)data[i*4+1]<<16)|((uint32_t)data[i*4+2]<<8)|((uint32_t)data[i*4+3]);
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = SF_ROTR(w[i-15],7) ^ SF_ROTR(w[i-15],18) ^ (w[i-15]>>3);
        uint32_t s1 = SF_ROTR(w[i-2],17) ^ SF_ROTR(w[i-2],19) ^ (w[i-2]>>10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    a=ctx->state[0]; b=ctx->state[1]; c=ctx->state[2]; d=ctx->state[3];
    e=ctx->state[4]; f=ctx->state[5]; g=ctx->state[6]; h=ctx->state[7];
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = SF_ROTR(e,6) ^ SF_ROTR(e,11) ^ SF_ROTR(e,25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = h + S1 + ch + SF_SHA256_K[i] + w[i];
        uint32_t S0 = SF_ROTR(a,2) ^ SF_ROTR(a,13) ^ SF_ROTR(a,22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        uint32_t t2 = S0 + maj;
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    ctx->state[0]+=a; ctx->state[1]+=b; ctx->state[2]+=c; ctx->state[3]+=d;
    ctx->state[4]+=e; ctx->state[5]+=f; ctx->state[6]+=g; ctx->state[7]+=h;
}

static void sf_sha256_init(sf_sha256_ctx_t *ctx) {
    static const uint32_t iv[8] = {
        0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
        0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19
    };
    memcpy(ctx->state, iv, sizeof(iv));
    ctx->bitlen = 0; ctx->buflen = 0;
}

static void sf_sha256_update(sf_sha256_ctx_t *ctx, const uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        ctx->buf[ctx->buflen++] = data[i];
        if (ctx->buflen == 64) {
            sf_sha256_transform(ctx, ctx->buf);
            ctx->bitlen += 512;
            ctx->buflen = 0;
        }
    }
}

static void sf_sha256_final(sf_sha256_ctx_t *ctx, uint8_t out[32]) {
    size_t i = ctx->buflen;
    ctx->bitlen += (uint64_t)ctx->buflen * 8;
    ctx->buf[i++] = 0x80;
    if (i > 56) { while (i < 64) ctx->buf[i++] = 0; sf_sha256_transform(ctx, ctx->buf); i = 0; }
    while (i < 56) ctx->buf[i++] = 0;
    for (int j = 7; j >= 0; j--) ctx->buf[i++] = (uint8_t)(ctx->bitlen >> (j*8));
    sf_sha256_transform(ctx, ctx->buf);
    for (int j = 0; j < 8; j++) {
        out[j*4]   = (uint8_t)(ctx->state[j] >> 24);
        out[j*4+1] = (uint8_t)(ctx->state[j] >> 16);
        out[j*4+2] = (uint8_t)(ctx->state[j] >> 8);
        out[j*4+3] = (uint8_t)(ctx->state[j]);
    }
}

static void sf_sha256(const uint8_t *data, size_t len, uint8_t out[32]) {
    sf_sha256_ctx_t ctx;
    sf_sha256_init(&ctx);
    sf_sha256_update(&ctx, data, len);
    sf_sha256_final(&ctx, out);
}

/* HMAC-SHA256, RFC 2104. key_len may exceed the 64-byte block size. */
static void sf_hmac_sha256(const uint8_t *key, size_t key_len,
                            const uint8_t *msg, size_t msg_len,
                            uint8_t out[32]) {
    uint8_t k[64] = {0};
    uint8_t k_ipad[64], k_opad[64];
    uint8_t tmp[32];

    if (key_len > 64) { sf_sha256(key, key_len, tmp); memcpy(k, tmp, 32); }
    else { memcpy(k, key, key_len); }

    for (int i = 0; i < 64; i++) {
        k_ipad[i] = k[i] ^ 0x36;
        k_opad[i] = k[i] ^ 0x5c;
    }

    sf_sha256_ctx_t ctx;
    sf_sha256_init(&ctx);
    sf_sha256_update(&ctx, k_ipad, 64);
    sf_sha256_update(&ctx, msg, msg_len);
    sf_sha256_final(&ctx, tmp);

    sf_sha256_init(&ctx);
    sf_sha256_update(&ctx, k_opad, 64);
    sf_sha256_update(&ctx, tmp, 32);
    sf_sha256_final(&ctx, out);
}

#endif /* SF_SHA256_H */
