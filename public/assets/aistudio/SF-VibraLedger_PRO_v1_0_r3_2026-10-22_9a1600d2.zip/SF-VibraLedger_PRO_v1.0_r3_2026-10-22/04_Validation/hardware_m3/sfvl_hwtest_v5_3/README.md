# SF-VibraLedger - real-hardware validation (FIT IoT-LAB, board m3 / Cortex-M3)

## Run it (on the IoT-LAB frontend)

    cd ~/sfvl_project/sfvl_hwtest_v5_3
    bash run_hwtest.sh                  # correctness + timing, one run
    REPEATS=5 bash run_hwtest.sh        # + 4 more resets; per-run timing medians in summary.txt
    bash repro_check.sh                 # two clean builds, same environment, compare hashes
    bash reanalyze.sh [LOGDIR]          # re-derive the verdict from saved logs (no hardware, originals untouched)

`run_hwtest.sh`: preflight -> forced app rebuild -> reuse-or-reserve an m3 node -> flash -> open serial
FIRST, then reset -> verdict.  Logs: `~/sfvl_project/logs/latest/` (`summary.txt`, `run.log`,
`serial_final.log`, `build_tier*.log`, `debug_report.txt` on failure).
Knobs: `SITE ARCHI DURATION CAPTURE_SECS ATTEMPTS EXP_ID NODE SKIP_BUILD SKIP_FLASH REPEATS KEEP DEBUG FORCE`.
Exit codes: 0 PASS | 1 device FAILED/crashed | 2 no serial | 3 build | 4 experiment/flash | 5 preflight.

## Evidence discipline (what summary.txt ties together)
firmware ELF sha256, **source hash** (Makefile + main.c + data + library), build flavour and exact make
arguments, clock-skew warning count, experiment/node, command line, and the device report.
`SKIP_BUILD=1` is only accepted when the ELF carries a build stamp equal to the current source hash
(otherwise it refuses, or with `FORCE=1` records that the ELF is NOT bound to these sources).

## Correctness: what the on-device CHECKs prove (26, +2 with stack introspection)
Model commissioned on the host (libm, host-only by design) -> authenticated wire blob -> firmware built
from the shipped Core/Wire/AuditLog/Features/Monitor sources (unmodified).
* embedded data intact (hashes) - catches a bad transfer/flash
* integer feature front end on RAW samples: 6 windows x 3 channels x 2048 int16 samples (all four
  statuses) through the real `SFVLF_Extract` + `SFVLF_ToModelVector`; bit-identical to the host
* wire format on silicon: pristine accepted; payload flip, tag flip, wrong key, truncation rejected
* three independent replays of 210 windows: status sequence, counts, first alert, hash of EVERY output field
* audit chain: count, verify, wrong key rejected, tamper detected, exported lines and the final
  HMAC chain head (32 B) identical to the host; learn counters identical
* determinism across runs; stack headroom >= 25 % (when stack introspection is available)

## Timing (v5): reported only if the counter is shown to work
At start the firmware runs a self-test: counter read overhead, a busy-loop sanity bound, and - with the
`ztimer_msec` module (`HWT_TIMERCAL=1`, default) - 3 x 100 ms sleeps against an independent time base to
**measure the real core clock** and compare it with the nominal one (3 % tolerance).  It prints
`TIMING_VALID: yes | partial | no`; microseconds are shown only when the clock was confirmed (or, for
`partial`, are labelled as using the nominal macro).  Statistics: n, min, median, p95, max, mean, in
cycles and us, for `SFVLM_Update` (split: without / with an audit entry = HMAC-SHA256), `SFVLF_Extract`
(1 channel x 2048 samples), `SFVL_WireStageToStore`; plus the CPU share of one 200 ms window.
`summary.txt` carries a `timing:` verdict line (VALID / PARTIAL / INVALID) and a `serial fresh:` line
(bytes that arrived BEFORE each reset; non-zero would mean a stale replay, so repeated runs could not be
trusted as independent executions).
Caveats printed with the numbers: counter-read overhead is included; the RTOS tick is not masked, so
p95/max may contain interrupts (min/median are the stable figures); this measures single functions on
this firmware, not whole-program time.  `HWT_CYCLES=0` disables all of it (that is why an earlier run said
"timing skipped").  Build tiers: full -> no stack info (keeps the clock check) -> no ztimer check -> neither -> no timing; the flavour used is
printed in `summary.txt` (`build:`) and the failing tier's log is kept (`build_tier<N>.log`).

## Build repeatability (`repro_check.sh`)
Two clean builds (`bin/<board>` deleted before each, so RIOT objects are rebuilt too), same arguments,
compare ELF and flashable-image hashes; optionally `ORIGINAL_ELF=<copy outside bin/>` (read only).
A == B means *identical in this environment* - not a formal reproducible-build proof; clock-skew warnings
(NFS vs frontend clock) are counted and reported.  A vs an older ELF is meaningful only with the same
sources, Makefile and `BUILD_ARGS` (e.g. timing code on/off changes the size by a few hundred bytes).

## Measured on silicon (run 20261017_213850 - m3-100, ELF 88bd7416..., source hash 782db815..., build "full", TIMING_VALID: yes)
28 CHECKs PASS (firmware declared total=28), including the integer feature extractor bit-exact on real Cortex-M3
and the HMAC audit-chain head identical to the host.  Clock confirmation: 3 x 100 ms of ztimer = 7,211,123 /
7,211,125 / 7,211,328 DWT cycles -> 72.11 MHz vs nominal 72.00 MHz (0.15 %, consistent with the sleep wake-up
latency).  Caveat: this is only as independent as the hardware timer behind `ztimer_msec`.

| function (median of n calls) | cycles | at 72 MHz |
|---|---|---|
| `SFVLM_Update`, no audit entry (n=618) | 43,059 | 597 us (min 468, p95 800, max 808) |
| `SFVLM_Update`, audit entry appended - HMAC-SHA256 (n=12) | 88,071 | 1,221 us |
| `SFVLF_Extract`, 1 channel x 2048 samples (n=18) | 789,273 | 10,945 us |
| `SFVL_WireStageToStore`, 5558-byte blob (n=3) | 911,757 | 12,643 us |

CPU per 200 ms window (3 x Extract + Update, medians): 33.4 ms = 16.7 % of one core (Extract is >98 % of it).
Five hardware captures gave identical medians (deterministic code, no cache).  Stack: 12,288 B configured,
worst observed 7,108 B used (harness incl. printf).  Flash 121,352 B of 524,288 (72 KB are embedded raw
samples); static RAM 46,216 B of 65,536 (incl. the 12 KB stack).  Counter-read overhead (1 cycle) is included;
RTOS-tick interrupts are not masked.  The first capture of a run may begin with the tail of the post-flash boot
run: judgement is done on the LAST run block only and `summary.txt` lists the bytes seen before each reset.

## Real-hardware findings so far
* The first silicon run HardFaulted at the first successful `SFVL_WireStageToStore`: it keeps a whole
  `SFVL_Model` (~5.6 KB) on the stack (~6.5 KB deep with HMAC) while RIOT's default main stack is ~2 KB.
  Makefile now sets `HWT_STACK=12288`; integrators must budget >= 8 KB for that call.
* Stack high-water is measured by scanning RIOT's stack paint (same algorithm as `thread_measure_stack_free`);
  the library function itself failed to compile in v5.1 ("incompatible pointer type") on RIOT 2026.10-devel.
* Measured on m3-10 (v3 firmware): stack used_max ~ 7.0 KB of 12 KB; `SFVLM_Monitor` = 8104 B on ARM
  (8112 B on x86-64).

## Not covered
Real sensor/ADC input, power loss during model activation, long soak, formal reproducible-build proof.

## Files
`main.c` firmware | `hwt_hash.h` shared fingerprint | `sfvl_hwtest_data.h` generated reference data
`run_hwtest.sh`, `repro_check.sh` | `SFVibraLedger_*` shipped library sources | `host_reference/`
