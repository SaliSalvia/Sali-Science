#include "SFVibraLedger_Features.h"
#include <string.h>

static const uint16_t LOG2_TAB[33] = {0,45,90,132,174,214,254,292,330,366,402,436,470,504,536,568,599,629,659,689,717,745,773,800,827,853,879,904,929,953,977,1001,1024};

static uint32_t isqrt64(uint64_t x) {
    uint64_t op = x, res = 0, one = (uint64_t)1 << 62;
    while (one > op) one >>= 2;
    while (one != 0) {
        if (op >= res + one) { op -= res + one; res = (res >> 1) + one; }
        else { res >>= 1; }
        one >>= 2;
    }
    return (res > UINT32_MAX) ? UINT32_MAX : (uint32_t)res;
}

static unsigned bitlen64(uint64_t v) { unsigned n = 0u; while (v) { ++n; v >>= 1; } return n; }
static uint64_t abs64(int64_t v) { return v < 0 ? (uint64_t)(-v) : (uint64_t)v; }

int32_t SFVLF_Log2Q(uint32_t v) {
    if (v == 0u) return 0;
    unsigned b = bitlen64(v);           /* v in [2^(b-1), 2^b) */
    uint32_t e = b - 1u;
    /* mantissa fraction in [0,1) scaled to 32 steps + remainder for interpolation */
    uint64_t frac = (uint64_t)v - ((uint64_t)1 << e);      /* 0 .. 2^e - 1 */
    uint64_t scaled = (e >= 5u) ? (frac >> (e - 5u)) : (frac << (5u - e)); /* 0..31 */
    uint64_t rem_num, rem_den;
    if (e >= 5u) { rem_num = frac & (((uint64_t)1 << (e - 5u)) - 1u); rem_den = (uint64_t)1 << (e - 5u); }
    else { rem_num = 0u; rem_den = 1u; }
    int32_t lo = (int32_t)LOG2_TAB[scaled];
    int32_t hi = (int32_t)LOG2_TAB[scaled + 1u];
    int32_t interp = lo + (int32_t)(((int64_t)(hi - lo) * (int64_t)rem_num) / (int64_t)rem_den);
    return (int32_t)(e * 1024u) + interp;
}

void SFVLF_ConfigInit(SFVLF_Config *cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    cfg->min_rms = 1u;
}

int SFVLF_Extract(const int32_t *x, uint32_t n, const SFVLF_Config *cfg, SFVLF_Features *out) {
    if (!x || !cfg || !out) return SFVLF_ERR_ARG;
    if (n < SFVLF_MIN_WINDOW || n > SFVLF_MAX_WINDOW || cfg->bands > SFVLF_MAX_BANDS) return SFVLF_ERR_RANGE;
    memset(out, 0, sizeof(*out));
    int64_t sum = 0;
    for (uint32_t i = 0; i < n; ++i) {
        if (x[i] > 1073741823 || x[i] < -1073741823) return SFVLF_ERR_RANGE;
        sum += x[i];
    }
    int64_t mean = sum / (int64_t)n;
    out->mean = (int32_t)mean;

    /* pass 1: peak, dropout (longest identical run), saturation count */
    uint64_t peak = 0u; uint32_t run = 1u, max_run = 1u, sat = 0u;
    for (uint32_t i = 0; i < n; ++i) {
        uint64_t a = abs64((int64_t)x[i] - mean);
        if (a > peak) peak = a;
        if (i > 0u) { if (x[i] == x[i - 1u]) { ++run; if (run > max_run) max_run = run; } else run = 1u; }
        if (cfg->full_scale > 0) {
            int64_t fs98 = ((int64_t)cfg->full_scale * 98) / 100;
            if ((int64_t)x[i] >= fs98 || (int64_t)x[i] <= -fs98) ++sat;
        }
    }
    out->peak = (peak > UINT32_MAX) ? UINT32_MAX : (uint32_t)peak;

    /* block scaling for 4th moments: 4*b + ceil_log2(n) <= 63 */
    unsigned lg = bitlen64((uint64_t)(n - 1u)); if (lg == 0u) lg = 1u;
    unsigned bmax = (63u - lg) / 4u;
    unsigned pb = bitlen64(peak);
    unsigned sh = (pb > bmax) ? (pb - bmax) : 0u;
    uint64_t s2 = 0u, s4 = 0u, ss_full = 0u;
    for (uint32_t i = 0; i < n; ++i) {
        int64_t y = (int64_t)x[i] - mean;
        uint64_t a = abs64(y);
        ss_full += a * a;                       /* |y| < 2^31 -> a*a < 2^62; n*2^62 could overflow: guarded below */
        uint64_t z = a >> sh;
        uint64_t z2 = z * z;
        s2 += z2; s4 += z2 * z2;
    }
    /* ss_full overflow guard: if peak >= 2^25 use the scaled sum for RMS instead */
    uint64_t m2_full;
    if (pb <= 25u) m2_full = ss_full / n;
    else m2_full = (s2 / n) << (2u * sh);       /* scaled estimate, precision limited to 2^sh */
    out->rms = isqrt64(m2_full);
    if (out->rms == 0u) out->crest_q = 0u; else out->crest_q = (uint32_t)(((uint64_t)out->peak * SFVLF_Q) / out->rms);
    uint64_t m2z = s2 / n, m4z = s4 / n;
    if (m2z == 0u) out->kurt_q = 3u * SFVLF_Q;
    else { uint64_t den = m2z * m2z; uint64_t k = (m4z * SFVLF_Q) / den; out->kurt_q = (k > UINT32_MAX) ? UINT32_MAX : (uint32_t)k; }

    /* Goertzel tone amplitudes on samples scaled to <= 2^11 magnitude */
    if (cfg->bands > 0u) {
        unsigned gsh = (pb > 11u) ? (pb - 11u) : 0u;
        for (uint8_t b = 0; b < cfg->bands; ++b) {
            int64_t c = cfg->goertzel_coeff_q22[b];
            if (c > (int64_t)8388608 || c < -(int64_t)8388608) return SFVLF_ERR_RANGE;
            int64_t s1 = 0, s0 = 0, sp = 0;
            for (uint32_t i = 0; i < n; ++i) {
                int64_t y = ((int64_t)x[i] - mean);
                int64_t w = (y >= 0) ? (y >> gsh) : -((-y) >> gsh);
                s0 = w + ((c * s1) >> 22) - sp;
                sp = s1; s1 = s0;
            }
            int64_t pw = s1 * s1 + sp * sp - (((c * s1) >> 22) * sp);
            if (pw < 0) pw = 0;
            uint64_t mag = isqrt64((uint64_t)pw);                 /* |X_k| in scaled units */
            uint64_t amp = (2u * mag) / n;                        /* single-tone amplitude */
            amp <<= gsh;
            out->band_amp[b] = (amp > UINT32_MAX) ? UINT32_MAX : (uint32_t)amp;
        }
    }

    /* signal-integrity quality */
    uint32_t q = SFVLF_Q; uint8_t flags = 0u;
    if (out->rms < cfg->min_rms) { flags |= SFVLF_FLAG_FLATLINE; q = 0u; }
    if (cfg->full_scale > 0 && sat > 0u) {
        uint32_t frac = (uint32_t)(((uint64_t)sat * SFVLF_Q) / n);       /* Q10 fraction of saturated samples */
        uint32_t pen = frac * 12u; if (pen > q) pen = q;
        q -= pen; if (frac >= 10u) flags |= SFVLF_FLAG_SATURATION;      /* >= ~1% */
    }
    if (max_run >= n / 8u) {
        uint32_t frac = (uint32_t)(((uint64_t)max_run * SFVLF_Q) / n);
        uint32_t pen = frac * 2u; if (pen > q) pen = q;
        q -= pen; flags |= SFVLF_FLAG_DROPOUT;
    }
    out->quality_q = (uint16_t)q; out->flags = flags;
    return SFVLF_OK;
}

uint8_t SFVLF_ToModelVector(const SFVLF_Features *f, const SFVLF_Config *cfg, int32_t *out) {
    if (!f || !cfg || !out) return 0u;
    uint8_t k = 0u;
    out[k++] = SFVLF_Log2Q(f->rms ? f->rms : 1u);
    out[k++] = SFVLF_Log2Q(f->crest_q ? f->crest_q : 1u);
    out[k++] = SFVLF_Log2Q(f->kurt_q ? f->kurt_q : 1u);
    for (uint8_t b = 0; b < cfg->bands; ++b) out[k++] = SFVLF_Log2Q(f->band_amp[b] + 1u);
    return k;
}
