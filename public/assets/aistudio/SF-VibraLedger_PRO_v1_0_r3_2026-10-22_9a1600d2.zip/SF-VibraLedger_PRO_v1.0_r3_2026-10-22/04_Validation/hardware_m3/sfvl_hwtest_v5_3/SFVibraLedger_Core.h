#ifndef SFVIBRALEDGER_CORE_H
#define SFVIBRALEDGER_CORE_H

/*
 * SF-VibraLedger deterministic embedded intelligence core.
 *
 * Fixed-point, statically bounded, no dynamic allocation. The active design
 * combines evidence-gated adaptation with a per-prototype Trust Ledger that
 * decays over processing epochs and spends adaptation budget.
 */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <limits.h>

#define SFVL_MAX_DIMENSIONS 16u
#define SFVL_MAX_CLASSES 8u
#define SFVL_MAX_PROTOTYPES_PER_CLASS 4u
#define SFVL_MAX_UNKNOWN_PROTOTYPES 4u
#define SFVL_HISTORY 8u
#define SFVL_Q 1024u
#define SFVL_MAX_SCALE 1048576u
#define SFVL_MIN_SCALE 1u
#define SFVL_UNKNOWN_CLASS 255u
#define SFVL_TOKEN_MAGIC 0x53463254u /* SF2T */
#define SFVL_UNKNOWN_SCALE 512u /* metric shared by unknown-pool joining AND by a promoted prototype */

typedef enum {
    SFVL_STATUS_SUCCESS = 0,
    SFVL_STATUS_BLOCKED = 1,
    SFVL_STATUS_ERROR = 2
} SFVL_Status;

typedef enum {
    SFVL_EVIDENCE_NONE = 0,
    SFVL_EVIDENCE_TEMPORAL = 1u << 0,
    SFVL_EVIDENCE_MARGIN = 1u << 1,
    SFVL_EVIDENCE_SLACK = 1u << 2,
    SFVL_EVIDENCE_SENSOR_QUALITY = 1u << 3,
    SFVL_EVIDENCE_EXTERNAL_CONFIRMATION = 1u << 4, /* still unwired - see header note */
    SFVL_EVIDENCE_MATURITY = 1u << 5               /* NOW driven by decaying trust_q, and NOW required */
} SFVL_Evidence;

typedef struct {
    int32_t center[SFVL_MAX_DIMENSIONS];
    uint32_t scale[SFVL_MAX_DIMENSIONS];
    uint64_t threshold_sq;
    uint32_t radius_mean;
    uint32_t radius_mad;
    uint32_t hits;        /* lifetime learning count - unchanged semantics, drives alpha only */
    uint32_t trust_q;     /* NEW: bounded [0, SFVL_Q] current trust score */
    uint32_t trust_epoch; /* NEW: model epoch trust_q was last brought up to date */
    uint8_t valid;
} SFVL_Prototype;

typedef struct {
    int32_t center[SFVL_MAX_DIMENSIONS];
    uint32_t hits;
    uint8_t valid;
} SFVL_UnknownPrototype;

typedef struct {
    uint8_t active_dimensions;
    uint8_t active_classes;
    uint8_t prototypes_per_class;
    uint8_t reserved;

    int32_t norm_center[SFVL_MAX_DIMENSIONS];
    uint32_t norm_scale[SFVL_MAX_DIMENSIONS];

    uint32_t base_alpha_fp;
    uint64_t learn_margin_sq;
    uint64_t learn_slack_sq;
    uint64_t unknown_join_threshold_sq;
    uint32_t unknown_promote_hits;
    uint32_t min_sensor_quality_q;

    uint32_t generation; /* unchanged: increments only on authorized trusted-model mutation */

    /* --- NEW: Trust Ledger parameters (Q-scaled, 0..SFVL_Q unless noted) --- */
    uint32_t epoch;                    /* monotonic tick, +1 per SFVL_Process call */
    uint32_t trust_decay_per_epoch_q;  /* trust lost per idle epoch (linear) */
    uint32_t trust_learn_cost_q;       /* trust spent by one successful FeedbackLearnGated */
    uint32_t min_trust_for_maturity_q; /* floor for SFVL_EVIDENCE_MATURITY */
    uint32_t min_trust_for_learn_q;    /* floor required to authorize a learning update */

    SFVL_Prototype proto[SFVL_MAX_CLASSES][SFVL_MAX_PROTOTYPES_PER_CLASS];
    SFVL_UnknownPrototype unknown[SFVL_MAX_UNKNOWN_PROTOTYPES];

    uint8_t history[SFVL_HISTORY];
    uint8_t history_len;
} SFVL_Model;

typedef struct {
    uint32_t magic;
    uint32_t model_generation;
    uint8_t predicted_class;
    uint8_t predicted_prototype;
    uint8_t evidence_mask;
    uint8_t reserved;
    uint16_t sensor_quality_q;
    uint16_t reserved2;
    uint64_t best_distance_sq;
    uint64_t second_distance_sq;
    uint64_t sample_fingerprint;
    uint32_t trust_at_issue_q; /* NEW: decayed trust snapshot at issuance, for audit/debug */
} SFVL_LearnToken;

typedef struct {
    SFVL_Status status;
    uint8_t predicted_class;
    uint8_t predicted_prototype;
    uint8_t temporally_confirmed;
    uint8_t learn_eligible;
    uint16_t sensor_quality_q;
    uint8_t evidence_mask;
    uint8_t reserved;
    uint64_t best_distance_sq;
    uint64_t second_distance_sq;
    uint32_t trust_q;       /* NEW: decayed trust of the matched prototype, pre-update, for observability */
    SFVL_LearnToken token;
} SFVL_Result;

void SFVL_Init(SFVL_Model *m, uint8_t dimensions, uint8_t classes, uint8_t prototypes_per_class);
int SFVL_SetNormalizationReference(SFVL_Model *m, uint8_t dim, int32_t center, uint32_t scale);
int SFVL_Normalize(const SFVL_Model *m, const int32_t *raw, int32_t *norm);
SFVL_Status SFVL_Process(SFVL_Model *m, const int32_t *norm, uint16_t sensor_quality_q, SFVL_Result *out);
int SFVL_FeedbackLearnGated(SFVL_Model *m, const SFVL_LearnToken *token, const int32_t *validated_norm);

uint64_t SFVL_DistanceSq(const SFVL_Model *m, const SFVL_Prototype *p, const int32_t *norm);
uint32_t SFVL_Isqrt64(uint64_t x);
uint8_t SFVL_TemporalConfirm(const SFVL_Model *m, uint8_t cls, uint8_t n, uint8_t window);
uint64_t SFVL_Fingerprint(const int32_t *norm, uint8_t dimensions);

void SFVL_ObserveUnknown(SFVL_Model *m, const int32_t *norm);
int SFVL_PromoteUnknown(SFVL_Model *m, uint8_t slot, uint8_t target_class);

/* NEW: exposed so tests/telemetry can inspect current trust without duplicating the decay formula */
uint32_t SFVL_DecayedTrust(const SFVL_Model *m, const SFVL_Prototype *p);

/* Commissioning-time trusted seed: initializes one known healthy/reference prototype. */
int SFVL_SeedPrototype(SFVL_Model *m, uint8_t target_class, uint8_t slot,
                      const int32_t *center, uint32_t initial_radius, uint32_t initial_hits);

int SFVL_SeedPrototypeFull(SFVL_Model *m, uint8_t target_class, uint8_t slot,
                          const int32_t *center, const uint32_t *scale,
                          uint32_t radius_mean, uint32_t radius_mad, uint32_t hits);

#endif
