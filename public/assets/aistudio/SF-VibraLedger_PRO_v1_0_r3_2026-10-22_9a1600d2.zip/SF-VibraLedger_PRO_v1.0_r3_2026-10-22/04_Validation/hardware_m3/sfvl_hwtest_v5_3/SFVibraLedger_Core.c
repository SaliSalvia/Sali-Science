#include "SFVibraLedger_Core.h"
#include <string.h>

static uint64_t sq_i64(int64_t x) {
    uint64_t a = (x < 0) ? (uint64_t)(-x) : (uint64_t)x;
    if (a != 0u && a > UINT64_MAX / a) return UINT64_MAX;
    return a * a;
}

static int32_t sat_i32(int64_t x) {
    if (x > INT32_MAX) return INT32_MAX;
    if (x < INT32_MIN) return INT32_MIN;
    return (int32_t)x;
}

uint32_t SFVL_Isqrt64(uint64_t x) {
    uint64_t op = x, res = 0, one = (uint64_t)1 << 62;
    while (one > op) one >>= 2;
    while (one != 0) {
        if (op >= res + one) { op -= res + one; res = (res >> 1) + one; }
        else { res >>= 1; }
        one >>= 2;
    }
    return (res > UINT32_MAX) ? UINT32_MAX : (uint32_t)res;
}

uint64_t SFVL_Fingerprint(const int32_t *norm, uint8_t dimensions) {
    uint64_t h = 1469598103934665603ULL;
    if (!norm) return 0u;
    for (uint8_t i = 0; i < dimensions; ++i) {
        uint32_t v = (uint32_t)norm[i];
        for (uint8_t b = 0; b < 4u; ++b) {
            h ^= (uint8_t)(v >> (8u * b));
            h *= 1099511628211ULL;
        }
    }
    return h;
}

static uint32_t alpha_for_maturity(const SFVL_Model *m, uint32_t hits) {
    uint32_t a = m->base_alpha_fp;
    if (a > SFVL_Q) a = SFVL_Q;
    if (hits >= 256u) a >>= 3;
    else if (hits >= 64u) a >>= 2;
    else if (hits >= 16u) a >>= 1;
    return a ? a : 1u;
}

static int64_t ema_i64(int64_t current, int64_t target, uint32_t alpha) {
    int64_t delta = target - current;
    return current + ((int64_t)alpha * delta) / (int64_t)SFVL_Q;
}

static uint32_t ema_u32(uint32_t current, uint32_t target, uint32_t alpha) {
    int64_t v = ema_i64((int64_t)current, (int64_t)target, alpha);
    if (v < 0) return 0u;
    if ((uint64_t)v > UINT32_MAX) return UINT32_MAX;
    return (uint32_t)v;
}

static uint64_t threshold_from_radius(uint32_t mean_radius, uint32_t mad_radius) {
    uint64_t r = (uint64_t)mean_radius + 3u * (uint64_t)mad_radius + 2u;
    if (r > UINT32_MAX) r = UINT32_MAX;
    return sq_i64((int64_t)r);
}

/* --- Trust Ledger: O(1), deterministic, linear decay with a floor at zero. ---
 * No loop: worst-case cost is one subtraction and one 64-bit multiply,
 * independent of how many epochs have elapsed. */
static uint32_t decayed_trust_calc(uint32_t now_epoch, uint32_t trust_epoch, uint32_t trust_q, uint32_t decay_per_epoch_q) {
    uint32_t elapsed = now_epoch - trust_epoch; /* unsigned wraparound-safe for monotonic epoch */
    uint64_t loss = (uint64_t)elapsed * (uint64_t)decay_per_epoch_q;
    if (loss >= (uint64_t)trust_q) return 0u;
    return (uint32_t)((uint64_t)trust_q - loss);
}

uint32_t SFVL_DecayedTrust(const SFVL_Model *m, const SFVL_Prototype *p) {
    if (!m || !p) return 0u;
    return decayed_trust_calc(m->epoch, p->trust_epoch, p->trust_q, m->trust_decay_per_epoch_q);
}

static uint32_t trust_gain_for_mask(uint8_t mask) {
    unsigned c = 0u;
    c += (mask & SFVL_EVIDENCE_TEMPORAL) != 0u;
    c += (mask & SFVL_EVIDENCE_MARGIN) != 0u;
    c += (mask & SFVL_EVIDENCE_SLACK) != 0u;
    c += (mask & SFVL_EVIDENCE_SENSOR_QUALITY) != 0u;
    return 4u + 8u * c; /* base 4 for any accepted match, +8 per corroborating bit, max 36 */
}

void SFVL_Init(SFVL_Model *m, uint8_t dimensions, uint8_t classes, uint8_t prototypes_per_class) {
    if (!m) return;
    memset(m, 0, sizeof(*m));
    m->active_dimensions = dimensions > SFVL_MAX_DIMENSIONS ? SFVL_MAX_DIMENSIONS : dimensions;
    m->active_classes = classes > SFVL_MAX_CLASSES ? SFVL_MAX_CLASSES : classes;
    m->prototypes_per_class = prototypes_per_class > SFVL_MAX_PROTOTYPES_PER_CLASS ? SFVL_MAX_PROTOTYPES_PER_CLASS : prototypes_per_class;
    m->base_alpha_fp = 102u;
    m->learn_margin_sq = 256u;
    m->learn_slack_sq = 1024u;
    m->unknown_join_threshold_sq = 2500u;
    m->unknown_promote_hits = 16u;
    m->min_sensor_quality_q = 700u;
    m->generation = 1u;
    /* Trust Ledger defaults - PROPOSED starting point, not yet tuned via a parameter sweep. */
    m->epoch = 0u;
    m->trust_decay_per_epoch_q = 1u;      /* ~1024 idle epochs (samples) to fully forget */
    m->trust_learn_cost_q = 96u;          /* > max single-sample gain (36): forces net loss while learning */
    m->min_trust_for_maturity_q = 200u;   /* MATURITY evidence bit floor */
    m->min_trust_for_learn_q = 256u;      /* stricter floor: required to authorize a learning update */
    for (uint8_t d = 0; d < m->active_dimensions; ++d) m->norm_scale[d] = SFVL_Q;
}

int SFVL_SetNormalizationReference(SFVL_Model *m, uint8_t dim, int32_t center, uint32_t scale) {
    if (!m || dim >= m->active_dimensions) return -1;
    if (scale < SFVL_MIN_SCALE) scale = SFVL_MIN_SCALE;
    if (scale > SFVL_MAX_SCALE) scale = SFVL_MAX_SCALE;
    m->norm_center[dim] = center;
    m->norm_scale[dim] = scale;
    return 0;
}

int SFVL_Normalize(const SFVL_Model *m, const int32_t *raw, int32_t *norm) {
    if (!m || !raw || !norm || m->active_dimensions == 0u) return -1;
    for (uint8_t d = 0; d < m->active_dimensions; ++d) {
        int64_t delta = (int64_t)raw[d] - (int64_t)m->norm_center[d];
        int64_t v = (delta * (int64_t)SFVL_Q) / (int64_t)m->norm_scale[d];
        norm[d] = sat_i32(v);
    }
    return 0;
}

uint64_t SFVL_DistanceSq(const SFVL_Model *m, const SFVL_Prototype *p, const int32_t *norm) {
    uint64_t total = 0u;
    if (!m || !p || !norm) return UINT64_MAX;
    for (uint8_t d = 0; d < m->active_dimensions; ++d) {
        int64_t diff = (int64_t)norm[d] - (int64_t)p->center[d];
        uint64_t sq = sq_i64(diff);
        uint64_t s = p->scale[d] ? p->scale[d] : 1u;
        uint64_t s2 = s > UINT64_MAX / s ? UINT64_MAX : s * s;
        if (s2 == 0u) return UINT64_MAX;
        uint64_t weighted = sq > UINT64_MAX / SFVL_Q ? UINT64_MAX : (sq * SFVL_Q) / s2;
        if (UINT64_MAX - total < weighted) return UINT64_MAX;
        total += weighted;
    }
    return total;
}

uint8_t SFVL_TemporalConfirm(const SFVL_Model *m, uint8_t cls, uint8_t n, uint8_t window) {
    if (!m || cls >= m->active_classes || n == 0u) return 0u;
    if (window > m->history_len) window = m->history_len;
    if (window == 0u || n > window) return 0u;
    uint8_t count = 0u;
    for (uint8_t i = 0; i < window; ++i) if (m->history[i] == cls) ++count;
    return count >= n;
}

static void push_history(SFVL_Model *m, uint8_t cls) {
    if (m->history_len < SFVL_HISTORY) { m->history[m->history_len++] = cls; return; }
    for (uint8_t i = 1u; i < SFVL_HISTORY; ++i) m->history[i - 1u] = m->history[i];
    m->history[SFVL_HISTORY - 1u] = cls;
}

SFVL_Status SFVL_Process(SFVL_Model *m, const int32_t *norm, uint16_t sensor_quality_q, SFVL_Result *out) {
    if (!m || !norm || !out || m->active_dimensions == 0u || m->active_classes == 0u || m->prototypes_per_class == 0u) return SFVL_STATUS_ERROR;
    memset(out, 0, sizeof(*out));
    out->status = SFVL_STATUS_BLOCKED;
    out->predicted_class = SFVL_UNKNOWN_CLASS;
    out->predicted_prototype = SFVL_UNKNOWN_CLASS;
    out->best_distance_sq = UINT64_MAX;
    out->second_distance_sq = UINT64_MAX;
    out->sensor_quality_q = sensor_quality_q > SFVL_Q ? SFVL_Q : sensor_quality_q;

    /* Trust Ledger clock: one tick per processed sample, independent of `generation`
     * (which only moves on authorized trusted-model mutation). Cheap, deterministic,
     * needs no wall clock / RTC - fits the project's existing sample-bound philosophy. */
    if (m->epoch != UINT32_MAX) ++m->epoch;

    uint8_t best_cls = SFVL_UNKNOWN_CLASS, best_p = SFVL_UNKNOWN_CLASS;
    for (uint8_t c = 0u; c < m->active_classes; ++c) {
        for (uint8_t p = 0u; p < m->prototypes_per_class; ++p) {
            const SFVL_Prototype *pr = &m->proto[c][p];
            if (!pr->valid) continue;
            uint64_t d2 = SFVL_DistanceSq(m, pr, norm);
            if (d2 < out->best_distance_sq) {
                out->second_distance_sq = out->best_distance_sq;
                out->best_distance_sq = d2;
                best_cls = c;
                best_p = p;
            } else if (d2 < out->second_distance_sq) {
                out->second_distance_sq = d2;
            }
        }
    }
    if (best_cls == SFVL_UNKNOWN_CLASS) { SFVL_ObserveUnknown(m, norm); return out->status; }

    const SFVL_Prototype *best = &m->proto[best_cls][best_p];
    uint64_t slack = best->threshold_sq > out->best_distance_sq ? best->threshold_sq - out->best_distance_sq : 0u;
    uint64_t margin = out->second_distance_sq > out->best_distance_sq ? out->second_distance_sq - out->best_distance_sq : 0u;
    uint8_t accepted = out->best_distance_sq <= best->threshold_sq;
    out->predicted_class = best_cls;
    out->predicted_prototype = best_p;

    if (!accepted) {
        push_history(m, SFVL_UNKNOWN_CLASS);
        SFVL_ObserveUnknown(m, norm);
        return out->status;
    }

    push_history(m, best_cls);
    out->status = SFVL_STATUS_SUCCESS;
    out->temporally_confirmed = SFVL_TemporalConfirm(m, best_cls, 3u, SFVL_HISTORY);

    /* Decayed trust BEFORE this sample's own contribution: a sample cannot vote for
     * its own MATURITY/eligibility status - it can only spend or build trust for the
     * *next* sample. Prevents a single-sample self-confirmation loophole. */
    uint32_t trust_pre = decayed_trust_calc(m->epoch, best->trust_epoch, best->trust_q, m->trust_decay_per_epoch_q);
    out->trust_q = trust_pre;

    uint8_t mask = SFVL_EVIDENCE_NONE;
    if (out->temporally_confirmed) mask |= SFVL_EVIDENCE_TEMPORAL;
    if (margin >= m->learn_margin_sq) mask |= SFVL_EVIDENCE_MARGIN;
    if (slack >= m->learn_slack_sq) mask |= SFVL_EVIDENCE_SLACK;
    if (out->sensor_quality_q >= m->min_sensor_quality_q) mask |= SFVL_EVIDENCE_SENSOR_QUALITY;
    if (trust_pre >= m->min_trust_for_maturity_q) mask |= SFVL_EVIDENCE_MATURITY; /* CHANGED: now trust-driven */
    out->evidence_mask = mask;

    /* Require three independent evidence channels before issuing the token, PLUS
     * (CHANGED) the trust budget must have headroom - this is the new, enforced gate. */
    unsigned evidence_count = 0u;
    evidence_count += (mask & SFVL_EVIDENCE_TEMPORAL) != 0u;
    evidence_count += (mask & SFVL_EVIDENCE_MARGIN) != 0u;
    evidence_count += (mask & SFVL_EVIDENCE_SLACK) != 0u;
    evidence_count += (mask & SFVL_EVIDENCE_SENSOR_QUALITY) != 0u;
    out->learn_eligible = (evidence_count >= 3u &&
                           (mask & SFVL_EVIDENCE_TEMPORAL) != 0u &&
                           (mask & SFVL_EVIDENCE_SENSOR_QUALITY) != 0u &&
                           trust_pre >= m->min_trust_for_learn_q) ? 1u : 0u;

    if (out->learn_eligible) {
        memset(&out->token, 0, sizeof(out->token));
        out->token.magic = SFVL_TOKEN_MAGIC;
        out->token.model_generation = m->generation;
        out->token.predicted_class = best_cls;
        out->token.predicted_prototype = best_p;
        out->token.evidence_mask = mask;
        out->token.sensor_quality_q = out->sensor_quality_q;
        out->token.best_distance_sq = out->best_distance_sq;
        out->token.second_distance_sq = out->second_distance_sq;
        out->token.sample_fingerprint = SFVL_Fingerprint(norm, m->active_dimensions);
        out->token.trust_at_issue_q = trust_pre;
    }

    /* Passive confirmation credit applies regardless of learn_eligible: being correctly
     * and repeatedly recognized is itself evidence worth banking, at a rate deliberately
     * smaller than the cost of an actual learning update (see trust_learn_cost_q). */
    {
        SFVL_Prototype *bp = &m->proto[best_cls][best_p];
        uint32_t gain = trust_gain_for_mask(mask);
        uint64_t updated = (uint64_t)trust_pre + gain;
        bp->trust_q = (updated > SFVL_Q) ? SFVL_Q : (uint32_t)updated;
        bp->trust_epoch = m->epoch;
    }
    return out->status;
}

int SFVL_FeedbackLearnGated(SFVL_Model *m, const SFVL_LearnToken *token, const int32_t *validated_norm) {
    if (!m || !token || !validated_norm) return -1;
    if (token->magic != SFVL_TOKEN_MAGIC || token->model_generation != m->generation) return -2;
    if (token->predicted_class >= m->active_classes || token->predicted_prototype >= m->prototypes_per_class) return -3;
    if ((token->evidence_mask & SFVL_EVIDENCE_TEMPORAL) == 0u ||
        (token->evidence_mask & SFVL_EVIDENCE_SENSOR_QUALITY) == 0u) return -4;
    if (token->sensor_quality_q < m->min_sensor_quality_q) return -5;
    if (SFVL_Fingerprint(validated_norm, m->active_dimensions) != token->sample_fingerprint) return -6;

    SFVL_Prototype *p = &m->proto[token->predicted_class][token->predicted_prototype];
    if (!p->valid) return -7;
    uint64_t now_d2 = SFVL_DistanceSq(m, p, validated_norm);
    uint64_t slack = p->threshold_sq > now_d2 ? p->threshold_sq - now_d2 : 0u;
    if (slack < m->learn_slack_sq) return -8;

    /* NEW: re-check trust at redemption time (not just at issuance) against the CURRENT
     * decayed value, and require the floor again. A token issued when trust was adequate
     * can still be refused if enough idle epochs (or an intervening spend) passed before
     * it was redeemed. */
    uint32_t trust_now = decayed_trust_calc(m->epoch, p->trust_epoch, p->trust_q, m->trust_decay_per_epoch_q);
    if (trust_now < m->min_trust_for_learn_q) return -9;

    uint32_t alpha = alpha_for_maturity(m, p->hits);
    for (uint8_t d = 0u; d < m->active_dimensions; ++d) {
        int64_t diff = (int64_t)validated_norm[d] - (int64_t)p->center[d];
        uint32_t absdiff = (uint32_t)(diff < 0 ? -diff : diff);
        p->center[d] = sat_i32(ema_i64(p->center[d], validated_norm[d], alpha));
        p->scale[d] = ema_u32(p->scale[d], absdiff, alpha);
        if (p->scale[d] < SFVL_MIN_SCALE) p->scale[d] = SFVL_MIN_SCALE;
        if (p->scale[d] > SFVL_MAX_SCALE) p->scale[d] = SFVL_MAX_SCALE;
    }
    /* Radius statistics use the PRE-update distance (now_d2): that is how far a fresh sample lies from the
     * prototype that will judge future samples. Measuring it after the centre has already moved toward the
     * sample under-estimates the radius by ~alpha per update and made the acceptance boundary shrink
     * under stationary conditions (found by the simulated-vibration benchmark, see Validation/BUGFIX_REPORT). */
    uint32_t radius = SFVL_Isqrt64(now_d2);
    uint32_t old_mean = p->radius_mean;
    p->radius_mean = ema_u32(p->radius_mean, radius, alpha);
    uint32_t err = radius > old_mean ? radius - old_mean : old_mean - radius;
    p->radius_mad = ema_u32(p->radius_mad, err, alpha);
    p->threshold_sq = threshold_from_radius(p->radius_mean, p->radius_mad);
    if (p->hits != UINT32_MAX) ++p->hits;

    /* NEW: learning itself spends trust - net effect (this cost minus the passive
     * gain already credited for this same sample in SFVL_Process) is a DECREASE,
     * which is the actual rate limiter on consecutive learning updates. */
    uint32_t spent = (trust_now > m->trust_learn_cost_q) ? (trust_now - m->trust_learn_cost_q) : 0u;
    p->trust_q = spent;
    p->trust_epoch = m->epoch;

    ++m->generation;
    return 0;
}

void SFVL_ObserveUnknown(SFVL_Model *m, const int32_t *norm) {
    if (!m || !norm) return;
    uint8_t best = SFVL_UNKNOWN_CLASS; uint64_t best_d2 = UINT64_MAX;
    for (uint8_t i = 0u; i < SFVL_MAX_UNKNOWN_PROTOTYPES; ++i) {
        if (!m->unknown[i].valid) continue;
        SFVL_Prototype t; memset(&t, 0, sizeof(t)); t.valid = 1u;
        for (uint8_t d = 0u; d < m->active_dimensions; ++d) { t.center[d] = m->unknown[i].center[d]; t.scale[d] = SFVL_UNKNOWN_SCALE; }
        uint64_t d2 = SFVL_DistanceSq(m, &t, norm);
        if (d2 < best_d2) { best_d2 = d2; best = i; }
    }
    if (best != SFVL_UNKNOWN_CLASS && best_d2 <= m->unknown_join_threshold_sq) {
        SFVL_UnknownPrototype *u = &m->unknown[best];
        for (uint8_t d = 0u; d < m->active_dimensions; ++d) u->center[d] = sat_i32(ema_i64(u->center[d], norm[d], 128u));
        if (u->hits != UINT32_MAX) ++u->hits;
        return;
    }
    for (uint8_t i = 0u; i < SFVL_MAX_UNKNOWN_PROTOTYPES; ++i) {
        if (!m->unknown[i].valid) {
            m->unknown[i].valid = 1u; m->unknown[i].hits = 1u;
            for (uint8_t d = 0u; d < m->active_dimensions; ++d) m->unknown[i].center[d] = norm[d];
            return;
        }
    }
}

int SFVL_PromoteUnknown(SFVL_Model *m, uint8_t slot, uint8_t target_class) {
    if (!m || slot >= SFVL_MAX_UNKNOWN_PROTOTYPES || target_class >= m->active_classes) return -1;
    SFVL_UnknownPrototype *u = &m->unknown[slot];
    if (!u->valid || u->hits < m->unknown_promote_hits) return -2;
    for (uint8_t p = 0u; p < m->prototypes_per_class; ++p) {
        if (!m->proto[target_class][p].valid) {
            SFVL_Prototype *np = &m->proto[target_class][p]; memset(np, 0, sizeof(*np)); np->valid = 1u; np->hits = u->hits;
            np->threshold_sq = m->unknown_join_threshold_sq; np->radius_mean = SFVL_Isqrt64(np->threshold_sq);
            for (uint8_t d = 0u; d < m->active_dimensions; ++d) { np->center[d] = u->center[d]; np->scale[d] = SFVL_UNKNOWN_SCALE; }
            memset(u, 0, sizeof(*u)); ++m->generation; return 0;
        }
    }
    return -3;
}


int SFVL_SeedPrototype(SFVL_Model *m, uint8_t target_class, uint8_t slot,
                      const int32_t *center, uint32_t initial_radius, uint32_t initial_hits) {
    if (!m || !center) return -1;
    if (target_class >= m->active_classes || slot >= m->prototypes_per_class) return -2;
    if (initial_radius == 0u) return -3;
    SFVL_Prototype *p = &m->proto[target_class][slot];
    memset(p, 0, sizeof(*p));
    p->valid = 1u;
    p->hits = initial_hits;
    p->radius_mean = initial_radius;
    p->radius_mad = initial_radius / 4u;
    p->threshold_sq = threshold_from_radius(p->radius_mean, p->radius_mad);
    p->trust_q = m->min_trust_for_learn_q;
    p->trust_epoch = m->epoch;
    for (uint8_t d = 0u; d < m->active_dimensions; ++d) {
        p->center[d] = center[d];
        p->scale[d] = initial_radius ? initial_radius : 1u;
        if (p->scale[d] < SFVL_MIN_SCALE) p->scale[d] = SFVL_MIN_SCALE;
        if (p->scale[d] > SFVL_MAX_SCALE) p->scale[d] = SFVL_MAX_SCALE;
    }
    ++m->generation;
    return 0;
}

/* Full commissioning seed (host-side commissioning tool): explicit per-dimension scale and
 * radius statistics measured on healthy reference data. The prototype is created with a trust
 * budget equal to the learn floor, exactly like SFVL_SeedPrototype. */
int SFVL_SeedPrototypeFull(SFVL_Model *m, uint8_t target_class, uint8_t slot,
                          const int32_t *center, const uint32_t *scale,
                          uint32_t radius_mean, uint32_t radius_mad, uint32_t hits) {
    if (!m || !center || !scale) return -1;
    if (target_class >= m->active_classes || slot >= m->prototypes_per_class) return -2;
    if (radius_mean == 0u) return -3;
    SFVL_Prototype *p = &m->proto[target_class][slot];
    memset(p, 0, sizeof(*p));
    p->valid = 1u;
    p->hits = hits;
    p->radius_mean = radius_mean;
    p->radius_mad = radius_mad;
    p->threshold_sq = threshold_from_radius(radius_mean, radius_mad);
    p->trust_q = m->min_trust_for_learn_q;
    p->trust_epoch = m->epoch;
    for (uint8_t d = 0u; d < m->active_dimensions; ++d) {
        uint32_t sc = scale[d];
        if (sc < SFVL_MIN_SCALE) sc = SFVL_MIN_SCALE;
        if (sc > SFVL_MAX_SCALE) sc = SFVL_MAX_SCALE;
        p->center[d] = center[d];
        p->scale[d] = sc;
    }
    ++m->generation;
    return 0;
}
