#include "SFVibraLedger_Monitor.h"
#include <string.h>

void SFVLM_ConfigDefaults(SFVLM_Config *c) {
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->warn_persistence = 3u; c->alarm_persistence = 3u; c->recover_windows = 5u;
    c->watch_ratio_q = 800u; c->alarm_ratio_q = 2048u; c->drift_limit_q = 2048u;
    c->adapt_enabled = 1u; c->audit_every_n_learn = 16u;
}

int SFVLM_Init(SFVLM_Monitor *mon, uint8_t dims, uint8_t classes, uint8_t ppc, const SFVLM_Config *cfg,
              const uint8_t *key, size_t key_len) {
    if (!mon || !key || key_len == 0u || key_len > sizeof(mon->key)) return -1;
    memset(mon, 0, sizeof(*mon));
    SFVL_Init(&mon->model, dims, classes, ppc);
    if (cfg) mon->cfg = *cfg; else SFVLM_ConfigDefaults(&mon->cfg);
    memcpy(mon->key, key, key_len); mon->key_len = (uint8_t)key_len;
    SFVLAL_Init(&mon->audit);
    return 0;
}

int SFVLM_Arm(SFVLM_Monitor *mon) {
    if (!mon) return -1;
    int any = 0;
    for (uint8_t p = 0; p < mon->model.prototypes_per_class; ++p) {
        const SFVL_Prototype *pr = &mon->model.proto[0][p];
        if (!pr->valid) continue;
        for (uint8_t d = 0; d < mon->model.active_dimensions; ++d) mon->ref_center[p][d] = pr->center[d];
        uint32_t r = SFVL_Isqrt64(pr->threshold_sq); mon->ref_radius[p] = r ? r : 1u;
        any = 1;
    }
    if (!any) return -2;
    mon->armed = 1u; mon->latched = SFVLM_HEALTHY;
    return 0;
}

static uint32_t ratio_q(uint64_t d2, uint64_t thr) {
    if (d2 == UINT64_MAX) return UINT32_MAX;
    uint32_t a = SFVL_Isqrt64(d2), b = SFVL_Isqrt64(thr); if (b == 0u) b = 1u;
    uint64_t r = ((uint64_t)a * 1024u) / b; return r > UINT32_MAX ? UINT32_MAX : (uint32_t)r;
}

/* cumulative displacement of a healthy prototype from its commissioned centre, Q10 of commissioned radius */
static uint32_t drift_of(const SFVLM_Monitor *mon, uint8_t p) {
    const SFVL_Prototype *pr = &mon->model.proto[0][p];
    if (!pr->valid) return 0u;
    SFVL_Prototype tmp = *pr;   /* live metric, live centre */
    uint64_t d2 = SFVL_DistanceSq(&mon->model, &tmp, mon->ref_center[p]);
    uint32_t a = SFVL_Isqrt64(d2);
    uint64_t r = ((uint64_t)a * 1024u) / mon->ref_radius[p];
    return r > UINT32_MAX ? UINT32_MAX : (uint32_t)r;
}

static void audit(SFVLM_Monitor *mon, uint8_t outcome, int8_t code, uint32_t gen_before, const SFVL_Result *r, uint64_t fp) {
    if (!mon->armed) return;
    (void)SFVLAL_Append(&mon->audit, mon->key, mon->key_len, mon->model.epoch, gen_before, mon->model.generation,
                       r ? r->predicted_class : 255u, r ? r->predicted_prototype : 255u, r ? r->evidence_mask : 0u,
                       outcome, code, r ? r->trust_q : 0u, fp);
}

int SFVLM_Update(SFVLM_Monitor *mon, const int32_t *raw, uint16_t quality_q, SFVLM_Output *out) {
    if (!mon || !raw || !out || !mon->armed) return -1;
    memset(out, 0, sizeof(*out)); out->matched_class = 255u; out->matched_prototype = 255u;
    out->window_index = mon->window_index++;
    int32_t norm[SFVL_MAX_DIMENSIONS];
    if (SFVL_Normalize(&mon->model, raw, norm) != 0) return -2;
    SFVL_Result r;
    if (SFVL_Process(&mon->model, norm, quality_q, &r) == SFVL_STATUS_ERROR) return -3;

    uint32_t worst_drift = 0u;
    for (uint8_t p = 0; p < mon->model.prototypes_per_class; ++p) {
        if (!mon->model.proto[0][p].valid) continue;
        uint32_t dq = drift_of(mon, p); if (dq > worst_drift) worst_drift = dq;
        if (mon->cfg.drift_limit_q && dq >= mon->cfg.drift_limit_q) mon->drift_frozen[p] = 1u;
    }
    out->drift_q = worst_drift;

    int accepted = (r.status == SFVL_STATUS_SUCCESS);
    const SFVL_Prototype *bp = (r.predicted_class < mon->model.active_classes && r.predicted_prototype < mon->model.prototypes_per_class)
                              ? &mon->model.proto[r.predicted_class][r.predicted_prototype] : NULL;
    uint32_t dev = bp ? ratio_q(r.best_distance_sq, bp->threshold_sq) : UINT32_MAX;
    out->deviation_q = dev;
    out->health_q = (dev >= 1024u) ? 0u : (uint16_t)(1024u - dev);
    if (accepted) { out->matched_class = r.predicted_class; out->matched_prototype = r.predicted_prototype; }

    SFVLM_Status st = SFVLM_HEALTHY;
    if (quality_q < mon->model.min_sensor_quality_q) {
        st = SFVLM_TRANSIENT;                          /* judge nothing, learn nothing, keep counters */
    } else if (accepted && r.predicted_class == 0u) {
        mon->bad_run = 0u; mon->severe_run = 0u;
        if (mon->healthy_run < UINT16_MAX) ++mon->healthy_run;
        st = (dev >= mon->cfg.watch_ratio_q) ? SFVLM_WATCH : SFVLM_HEALTHY;
        if (mon->cfg.adapt_enabled && r.learn_eligible && !mon->drift_frozen[r.predicted_prototype]) {
            uint32_t g0 = mon->model.generation;
            int rc = SFVL_FeedbackLearnGated(&mon->model, &r.token, norm);
            if (rc == 0) {
                out->learned = 1u; ++mon->learn_total;
                if (mon->cfg.audit_every_n_learn && ++mon->learn_since_audit >= mon->cfg.audit_every_n_learn) {
                    audit(mon, SFVLAL_OUTCOME_APPLIED, 0, g0, &r, r.token.sample_fingerprint); mon->learn_since_audit = 0u;
                }
            } else { ++mon->learn_rejected; audit(mon, SFVLAL_OUTCOME_REJECTED, (int8_t)rc, g0, &r, r.token.sample_fingerprint); }
        }
    } else if (accepted) {                            /* matched a commissioned fault signature */
        mon->healthy_run = 0u; st = SFVLM_ALARM;
    } else {                                          /* outside every boundary */
        mon->healthy_run = 0u;
        if (mon->bad_run < UINT16_MAX) ++mon->bad_run;
        if (dev >= mon->cfg.alarm_ratio_q) { if (mon->severe_run < UINT16_MAX) ++mon->severe_run; } else mon->severe_run = 0u;
        if (mon->severe_run >= mon->cfg.alarm_persistence) st = SFVLM_ALARM;
        else if (mon->bad_run >= mon->cfg.warn_persistence) st = SFVLM_WARNING;
        else st = SFVLM_WATCH;
    }
    /* drift supervision: once any healthy prototype hit the cumulative-drift envelope, adaptation
     * for it is frozen and the status is at least DRIFT_LIMIT until a human re-commissions. */
    uint8_t frozen_any = 0u;
    for (uint8_t p = 0; p < mon->model.prototypes_per_class; ++p) frozen_any |= mon->drift_frozen[p];
    if (frozen_any && st != SFVLM_ALARM && st != SFVLM_WARNING) st = SFVLM_DRIFT_LIMIT;

    /* latch / hysteresis for WARNING and ALARM */
    if (st == SFVLM_WARNING || st == SFVLM_ALARM) { if (st > mon->latched) mon->latched = st; }
    else if (mon->latched == SFVLM_WARNING || mon->latched == SFVLM_ALARM) {
        if (mon->healthy_run >= mon->cfg.recover_windows) mon->latched = SFVLM_HEALTHY;
        else if (st != SFVLM_TRANSIENT && st < mon->latched) st = mon->latched;
    }
    out->status = st;
    /* audit every escalation to WARNING or above (once per transition) */
    if (st >= SFVLM_WARNING && st > mon->prev_status)
        audit(mon, SFVLAL_OUTCOME_ESCALATION, (int8_t)st, mon->model.generation, &r, SFVL_Fingerprint(norm, mon->model.active_dimensions));
    if (st != SFVLM_TRANSIENT) mon->prev_status = st;
    return 0;
}

int SFVLM_PromoteCandidate(SFVLM_Monitor *mon, uint8_t slot, uint8_t target_class) {
    if (!mon) return -1;
    uint32_t g0 = mon->model.generation;
    int rc = SFVL_PromoteUnknown(&mon->model, slot, target_class);
    if (rc == 0) audit(mon, SFVLAL_OUTCOME_APPLIED, 0, g0, NULL, 0u);
    return rc;
}
