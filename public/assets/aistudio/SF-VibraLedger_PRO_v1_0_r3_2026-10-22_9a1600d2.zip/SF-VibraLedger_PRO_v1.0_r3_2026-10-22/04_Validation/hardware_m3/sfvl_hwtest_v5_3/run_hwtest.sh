#!/usr/bin/env bash
# =============================================================================
#  SF-VibraLedger - one-shot real-hardware validation on FIT IoT-LAB
#
#  usage:   bash run_hwtest.sh            (run on the IoT-LAB SSH frontend)
#           bash run_hwtest.sh help
#
#  What it does, end to end (idempotent, safe to re-run):
#    1 preflight   tools, files, RIOT checkout, IoT-LAB login
#    2 build       forced rebuild of the app (never a stale ELF), size/RAM budget
#    3 experiment  reuse a running one with an m3 node, else reserve a fresh one
#    4 flash       iotlab-node --flash (auto-falls back to a new experiment)
#    5 capture     opens the serial port FIRST, then resets the node, so the
#                  one-shot firmware output is never missed; retries
#    6 verdict     parses CHECK lines, PASS/FAIL, exit code, summary + debug files
#
#  Knobs (environment variables):
#    SITE=grenoble ARCHI=m3:at86rf231 DURATION=30  CAPTURE_SECS=45 ATTEMPTS=3
#    EXP_ID=<id>   reuse that experiment      NODE=m3-10   force a node name
#    SKIP_BUILD=1  SKIP_FLASH=1 (re-run capture only)   KEEP=1 (never stop exp)
#    DEBUG=1       shell trace into run.log
#    REPEATS=5     after a PASS, reset+capture N-1 more times and tabulate the timing medians per run
#    FORCE=1       allow SKIP_BUILD=1 with an ELF that is not bound to the current sources
#
#  Exit codes: 0 PASS | 1 device ran but FAILED | 2 no serial output
#              3 build failed | 4 experiment/flash problem | 5 preflight problem
# =============================================================================
set -u
set -o pipefail

if [ "${1:-}" = "help" ] || [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then
  sed -n '2,28p' "$0"; exit 0
fi

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE" || exit 5
PROJ="$(cd "$HERE/.." && pwd)"

SITE="${SITE:-grenoble}"
ARCHI="${ARCHI:-m3:at86rf231}"
BOARD="${BOARD:-iotlab-m3}"
DURATION="${DURATION:-30}"
SERIAL_PORT="${SERIAL_PORT:-20000}"
CAPTURE_SECS="${CAPTURE_SECS:-45}"
ATTEMPTS="${ATTEMPTS:-3}"
WAIT_TIMEOUT="${WAIT_TIMEOUT:-600}"
EXP_ID="${EXP_ID:-}"
NODE="${NODE:-}"
KEEP="${KEEP:-0}"
DEBUG="${DEBUG:-0}"
SKIP_BUILD="${SKIP_BUILD:-0}"
SKIP_FLASH="${SKIP_FLASH:-0}"
REPEATS="${REPEATS:-1}"
APP="sfvl_hwtest"
ELF="$HERE/bin/$BOARD/$APP.elf"
MIN_CHECKS=26                 # the shipped firmware prints at least this many CHECK lines
EXPECT_SHA_MAIN="a9d683d8dec9f2c06f3c31fccbbf2daae751af103e309f882a2f67136c79cba7"  # filled in at packaging time
EXPECT_SHA_DATA="40117f765cf9b09b0e9d7f655ccec4888fc2eef1cb38d55969fef49a8a9a9995"

INVOKED="$0 $*"
STAMP="$(date +%Y%m%d_%H%M%S)"
LOGROOT="$PROJ/logs"
LOGDIR="$LOGROOT/run_$STAMP"
mkdir -p "$LOGDIR" || { echo "cannot create $LOGDIR"; exit 5; }
ln -sfn "$LOGDIR" "$LOGROOT/latest" 2>/dev/null
SUMMARY="$LOGDIR/summary.txt"
exec > >(tee -a "$LOGDIR/run.log") 2>&1
[ "$DEBUG" = "1" ] && { PS4='+ ${BASH_SOURCE##*/}:${LINENO}: '; set -x; }

CREATED_EXP=0; REUSED=0; NCPID=""; NOCYC=0; PRE_MAX=0; BUILD_ARGS=""; SKEW_WARN=0; BUILD_FLAVOUR="${SKIP_BUILD:+prebuilt}"
RESULT_TEXT="not run"; CHECKS_TEXT=""; DEV_RESULT=""

ts()   { date +%H:%M:%S; }
say()  { printf '[%s] %s\n' "$(ts)" "$*"; }
warn() { say "WARN: $*"; }
hr()   { printf '%s\n' "------------------------------------------------------------"; }
clip() { tr '\n' ' ' | cut -c1-"${1:-220}"; }

# The serial log can start with the tail of an earlier run (the node boots and runs right after flashing, and
# `nc` may attach while it is still printing).  Everything is therefore judged on the LAST run block only.
BANNER='==== SF-VibraLedger real-hardware validation ===='
last_run_block() {   # from the last banner line to EOF (CR stripped); whole file if there is no banner
  tr -d '\r' < "$1" | awk -v b="$BANNER" 'index($0,b)==1{buf=""} {buf=buf $0 "\n"} END{printf "%s", buf}'
}
run_complete() {     # last block starts with the banner and contains the end marker
  local blk; blk="$(last_run_block "$1")"
  [ "${blk%%$'\n'*}" = "$BANNER" ] && printf '%s' "$blk" | grep -q '^SFVL_DONE'
}

write_debug() {
  local f="$LOGDIR/debug_report.txt" t
  {
    echo "== when/where =="; date; uname -a; whoami; hostname
    echo "== knobs =="; echo "SITE=$SITE ARCHI=$ARCHI BOARD=$BOARD EXP_ID=$EXP_ID NODE=$NODE REUSED=$REUSED CREATED_EXP=$CREATED_EXP NOCYC=$NOCYC"
    echo "== tools =="
    for t in iotlab-experiment iotlab-node make arm-none-eabi-gcc arm-none-eabi-size nc timeout python3; do
      printf '%-22s %s\n' "$t" "$(command -v "$t" 2>/dev/null || echo MISSING)"
    done
    arm-none-eabi-gcc --version 2>&1 | head -1; python3 -V 2>&1
    echo "== files =="; ls -l --time-style=long-iso "$HERE" 2>&1 | head -40
    echo "== sha256 =="; sha256sum "$HERE/main.c" "$HERE/sfvl_hwtest_data.h" "$ELF" 2>&1
    echo "== elf size =="; arm-none-eabi-size "$ELF" 2>&1
    echo "== iotlab: active experiments =="; timeout 30 iotlab-experiment get --active 2>&1 | head -40
    if [ -n "$EXP_ID" ]; then echo "== iotlab: experiment $EXP_ID nodes =="; timeout 30 iotlab-experiment get -i "$EXP_ID" -r 2>&1 | head -40; fi
    if [ -n "$NODE" ]; then echo "== serial port reachability =="; timeout 8 nc -zv "$NODE" "$SERIAL_PORT" 2>&1; fi
    echo "== build log (tail) =="; tail -40 "$LOGDIR/build.log" 2>&1
    for t in "$LOGDIR"/flash_*.log "$LOGDIR"/reset_*.log "$LOGDIR"/nc_*.err; do [ -f "$t" ] && { echo "== $(basename "$t") =="; head -20 "$t"; }; done
    for t in "$LOGDIR"/serial_[0-9]*.log; do [ -f "$t" ] && { echo "== $(basename "$t") ($(wc -c < "$t") bytes, last 60 lines) =="; tr -d '\r' < "$t" | tail -60; }; done
  } > "$f" 2>&1
  say "debug report: $f"
}

finish() {
  local code="$1"
  {
    echo "SF-VibraLedger hardware validation summary"
    echo "time        : $(date)"
    echo "experiment  : ${EXP_ID:-none}  node: ${NODE:-none}  site: $SITE  (reused=$REUSED created=$CREATED_EXP)"
    echo "firmware    : $ELF"
    [ -f "$ELF" ] && echo "elf sha256  : $(sha256sum "$ELF" | cut -d' ' -f1)"
    [ -n "${SIZE_TEXT:-}" ] && echo "size        : $SIZE_TEXT"
    echo "build       : ${BUILD_FLAVOUR:-unknown}"
    echo "build args  : ${BUILD_ARGS:-n/a}   clock-skew warnings: ${SKEW_WARN:-0}"
    echo "source hash : $(source_hash 2>/dev/null)"
    echo "command     : ${INVOKED:-bash run_hwtest.sh}  (env: SKIP_BUILD=$SKIP_BUILD SKIP_FLASH=$SKIP_FLASH KEEP=$KEEP SITE=$SITE)"
    if [ -s "$LOGDIR/prebytes.txt" ]; then
      echo "serial      : bytes seen before each reset: $(awk '{printf "%s=%s ",$1,$2}' "$LOGDIR/prebytes.txt")-> captures with 0 bytes before reset (fresh by construction): $(awk '$2==0' "$LOGDIR/prebytes.txt" | wc -l) of $(wc -l < "$LOGDIR/prebytes.txt")"
    fi
    if [ -s "$LOGDIR/serial_final.log" ]; then
      case "$(last_run_block "$LOGDIR/serial_final.log" | grep -E '^TIMING_VALID:' | head -1)" in
        "TIMING_VALID: yes"*)     echo "timing      : VALID - cycles measured, clock confirmed against an independent ztimer; microseconds usable" ;;
        "TIMING_VALID: partial"*) echo "timing      : PARTIAL - cycle counts are real DWT measurements; microseconds / CPU-share use the NOMINAL clock macro and are NOT confirmed" ;;
        "TIMING_VALID: no"*)      echo "timing      : INVALID - cycle counter did not advance" ;;
        *)                        echo "timing      : not measured in this build" ;;
      esac
    fi
    echo "device      : ${DEV_RESULT:-<no RESULT line>}"
    echo "checks      : ${CHECKS_TEXT:-<none>}"
    echo "verdict     : $RESULT_TEXT"
    echo "exit code   : $code"
    echo "logs        : $LOGDIR"
    [ -s "$LOGDIR/bench_summary.txt" ] && { echo "---- repeated runs ----"; cat "$LOGDIR/bench_summary.txt"; }
    if [ -s "$LOGDIR/serial_final.log" ]; then
      echo "---- device report (from serial) ----"
      last_run_block "$LOGDIR/serial_final.log" | grep -E '^(platform|sizes|dims|cycle counter|configured|actual|stack|timing|TIMING_VALID|realtime|feature windows|wire (tamper|wrong|truncated|pristine)|audit tampered|stack introspection|ABORT|MISMATCH|run[123]:)' | cut -c1-200
    fi
  } > "$SUMMARY"
  hr; cat "$SUMMARY"; hr
  if [ "$code" -ne 0 ]; then
    write_debug
    [ -n "$EXP_ID" ] && say "experiment $EXP_ID left running so you can simply re-run:  bash run_hwtest.sh"
  elif [ "$CREATED_EXP" = "1" ] && [ "$KEEP" != "1" ] && [ -n "$EXP_ID" ]; then
    say "stopping experiment $EXP_ID (KEEP=1 to prevent)"
    timeout 60 iotlab-experiment stop -i "$EXP_ID" > "$LOGDIR/stop.log" 2>&1
  fi
  say "send me:  cat $SUMMARY   (and $LOGDIR/debug_report.txt if exit code != 0)"
  sleep 1
  exit "$code"
}

cleanup() { [ -n "$NCPID" ] && kill "$NCPID" 2>/dev/null; }
trap cleanup EXIT
trap 'say "interrupted"; RESULT_TEXT="interrupted by user"; finish 5' INT TERM

# ------------------------------------------------------------------ 1 preflight
preflight() {
  hr; say "1/6 preflight"
  local bad=0 t f
  for t in make nc timeout python3 grep sed awk tr sha256sum arm-none-eabi-gcc iotlab-experiment iotlab-node; do
    command -v "$t" >/dev/null 2>&1 || { say "MISSING tool: $t"; bad=1; }
  done
  command -v arm-none-eabi-size >/dev/null 2>&1 || warn "arm-none-eabi-size missing (size report skipped)"
  for f in Makefile main.c hwt_hash.h sfvl_hwtest_data.h SFVibraLedger_SHA256.h \
           SFVibraLedger_Core.c SFVibraLedger_Core.h SFVibraLedger_Wire.c SFVibraLedger_Wire.h \
           SFVibraLedger_AuditLog.c SFVibraLedger_AuditLog.h SFVibraLedger_Features.c SFVibraLedger_Features.h \
           SFVibraLedger_Monitor.c SFVibraLedger_Monitor.h; do
    [ -f "$f" ] || { say "MISSING file: $HERE/$f"; bad=1; }
  done
  [ -f "$PROJ/RIOT/Makefile.include" ] || { say "MISSING RIOT checkout at $PROJ/RIOT (git clone https://github.com/RIOT-OS/RIOT.git $PROJ/RIOT)"; bad=1; }
  case "$EXPECT_SHA_MAIN" in
    @*) ;;   # placeholder not filled in (running from a source checkout): skip
    *)
      [ "$(sha256sum main.c | cut -d' ' -f1)" = "$EXPECT_SHA_MAIN" ] || warn "main.c differs from the packaged version (edited or old copy?)"
      [ "$(sha256sum sfvl_hwtest_data.h | cut -d' ' -f1)" = "$EXPECT_SHA_DATA" ] || { say "sfvl_hwtest_data.h differs from the packaged version -> broken or old transfer, re-copy the zip"; bad=1; }
      ;;
  esac
  local out; out="$(timeout 60 iotlab-experiment get --active 2>&1)"; printf '%s\n' "$out" > "$LOGDIR/get_active.log"
  if printf '%s' "$out" | grep -qiE 'unauthori|401|credential|not authenticated|authentication'; then
    say "IoT-LAB login problem: run  iotlab-auth -u <your-login>  and re-run"; bad=1
  else
    say "IoT-LAB API reachable"
  fi
  if [ "$bad" -ne 0 ]; then RESULT_TEXT="preflight failed"; finish 5; fi
  say "preflight OK"
}


# hash of everything that determines the firmware: sources + Makefile (+ build args)
source_hash() {
  ( cd "$HERE" && cat Makefile main.c hwt_hash.h sfvl_hwtest_data.h SFVibraLedger_*.[ch] 2>/dev/null | sha256sum | cut -d' ' -f1 )
}

# ---------------------------------------------------------------------- 2 build
build_fw() {
  hr; say "2/6 build"
  if [ "$SKIP_BUILD" = "1" ]; then
    [ -f "$ELF" ] || { RESULT_TEXT="SKIP_BUILD=1 but no ELF"; finish 3; }
    say "SKIP_BUILD=1 -> using existing ELF"
    if [ -f "$ELF.srchash" ]; then
      if [ "$(cat "$ELF.srchash")" = "$(source_hash)" ]; then say "ELF is bound to the CURRENT sources (source hash matches the build stamp)"
      elif [ "${FORCE:-0}" = "1" ]; then warn "ELF was built from DIFFERENT sources (FORCE=1, continuing)"
      else RESULT_TEXT="SKIP_BUILD=1 but the ELF was built from different sources (rebuild, or FORCE=1)"; finish 5; fi
    else
      warn "no build stamp next to the ELF: nothing ties it to the current sources (the result will say so)"
      BUILD_FLAVOUR="prebuilt ELF, NOT bound to the current sources"
    fi
  else
    # force the app to rebuild: never flash a stale ELF (clock skew / old timestamps)
    rm -rf "$HERE/bin/$BOARD/application_$APP" "$HERE/bin/$BOARD/$APP".{elf,bin,hex,map} 2>/dev/null
    local rc tier=1 args flavour
    BUILD_FLAVOUR=""
    for tier in 1 2 3 4 5; do
      case "$tier" in
        1) args=();                                                flavour="full (timing + ztimer clock check + stack info)" ;;
        2) args=(HWT_STACKINFO=0);                                 flavour="no stack introspection (timing + ztimer clock check kept)" ;;
        3) args=(HWT_TIMERCAL=0);                                  flavour="no ztimer clock check (timing validity will be partial; stack info kept)" ;;
        4) args=(HWT_TIMERCAL=0 HWT_STACKINFO=0);                  flavour="timing without clock check, no stack introspection" ;;
        5) args=(HWT_CYCLES=0 HWT_TIMERCAL=0 HWT_STACKINFO=0);     flavour="no timing, no stack introspection" ;;
      esac
      rm -rf "$HERE/bin/$BOARD/application_$APP" "$HERE/bin/$BOARD/$APP".{elf,bin,hex,map} 2>/dev/null
      make BOARD="$BOARD" "${args[@]}" > "$LOGDIR/build_tier$tier.log" 2>&1; rc=$?
      if [ $rc -eq 0 ]; then BUILD_FLAVOUR="$flavour"; BUILD_ARGS="${args[*]:-<defaults>}"; cp "$LOGDIR/build_tier$tier.log" "$LOGDIR/build.log"; break; fi
      warn "build tier $tier ($flavour) FAILED - error excerpt:"
      grep -E 'error|Error' "$LOGDIR/build_tier$tier.log" | head -8 | cut -c1-200
      cp "$LOGDIR/build_tier$tier.log" "$LOGDIR/build.log"
    done
    if [ $rc -ne 0 ]; then
      say "BUILD FAILED - last lines:"; tail -25 "$LOGDIR/build.log"
      RESULT_TEXT="build failed"; finish 3
    fi
    [ "$tier" -gt 1 ] && warn "built as: $BUILD_FLAVOUR (see build_tier1.log for the reason the full build failed)"
    source_hash > "$ELF.srchash"
    SKEW_WARN="$(grep -ciE 'clock skew|modification time .* in the future|dans le futur' "$LOGDIR/build.log" 2>/dev/null)"
    [ "${SKEW_WARN:-0}" -gt 0 ] && warn "clock-skew warnings in the build: $SKEW_WARN (NFS vs frontend clock; the build may be incomplete - the app objects are force-rebuilt, RIOT objects are not)"
  fi
  [ -f "$ELF" ] || { RESULT_TEXT="build produced no ELF"; finish 3; }
  local w; w="$(grep -c 'warning:' "$LOGDIR/build.log" 2>/dev/null)"; say "compiler warnings: ${w:-0}"
  if command -v arm-none-eabi-size >/dev/null 2>&1; then
    SIZE_TEXT="$(arm-none-eabi-size "$ELF" | tail -1 | awk '{print "text="$1" data="$2" bss="$3}')"
    local text data bss
    read -r text data bss <<<"$(arm-none-eabi-size "$ELF" | tail -1 | awk '{print $1,$2,$3}')"
    say "flash=$((text+data)) B of 524288, static RAM=$((data+bss)) B of 65536 ($SIZE_TEXT)"
    [ $((data+bss)) -gt 56000 ] && warn "static RAM above 56000 B - little stack headroom"
    [ $((text+data)) -gt 480000 ] && warn "flash above 480000 B"
  fi
  say "ELF sha256: $(sha256sum "$ELF" | cut -d' ' -f1)"
}

# ----------------------------------------------------------------- 3 experiment
PY_RUNNING='
import sys, json, re
t = sys.stdin.read()
m = re.search(r"[\[{]", t)
ids = []
if m:
    try:
        d = json.JSONDecoder().raw_decode(t[m.start():])[0]
    except Exception:
        d = None
    bad = ("terminated", "stopped", "error", "cancel", "finish")
    def walk(o):
        if isinstance(o, dict):
            st = str(o.get("state", "")).lower()
            if isinstance(o.get("id"), int) and not any(b in st for b in bad):
                ids.append(o["id"])
            for k, v in o.items():
                if str(k).lower() == "running" and isinstance(v, list):
                    ids.extend(i for i in v if isinstance(i, int))
                walk(v)
        elif isinstance(o, list):
            for x in o:
                walk(x)
    walk(d)
print(" ".join(str(i) for i in sorted(set(ids), reverse=True)))
'

discover_node() {
  local out pat="${ARCHI%%:*}-[0-9]+" flag
  NODE_STATE=""
  [ -n "$NODE" ] && return 0
  for flag in "-r" "--nodes" "-ni"; do
    out="$(timeout 60 iotlab-experiment get -i "$EXP_ID" $flag 2>&1)"
    printf '%s\n' "$out" > "$LOGDIR/nodes_$EXP_ID.log"
    NODE="$(printf '%s' "$out" | grep -oE "$pat" | head -1)"
    [ -n "$NODE" ] && { NODE_STATE="$(printf '%s' "$out" | grep -oE '"state"[[:space:]]*:[[:space:]]*"[A-Za-z]+"' | head -1 | grep -oE '"[A-Za-z]+"$' | tr -d '"')"; return 0; }
  done
  return 1
}

try_reuse_running() {
  local ids id
  ids="$(timeout 60 iotlab-experiment get --active 2>&1 | python3 -c "$PY_RUNNING" 2>/dev/null)"
  [ -z "$ids" ] && ids="$(timeout 60 iotlab-experiment get -l --state Running 2>&1 | python3 -c "$PY_RUNNING" 2>/dev/null)"
  say "running experiments found: ${ids:-none}"
  for id in $ids; do
    EXP_ID="$id"; NODE=""
    if discover_node; then REUSED=1; say "reusing experiment $EXP_ID (node $NODE)"; return 0; fi
  done
  EXP_ID=""; NODE=""; return 1
}

submit_new() {
  local try out id
  for try in 1 2 3; do
    out="$(timeout 90 iotlab-experiment submit -n sfvl-hwtest -d "$DURATION" -l "1,archi=${ARCHI}+site=${SITE}" 2>&1)"
    printf '%s\n' "$out" > "$LOGDIR/submit_$try.log"
    id="$(printf '%s' "$out" | grep -oE '"id"[[:space:]]*:[[:space:]]*[0-9]+' | head -1 | grep -oE '[0-9]+$')"
    if [ -n "$id" ]; then EXP_ID="$id"; CREATED_EXP=1; REUSED=0; NODE=""; say "submitted experiment $EXP_ID"; return 0; fi
    warn "submit attempt $try failed: $(printf '%s' "$out" | clip 200)"
    sleep 15
  done
  return 1
}

acquire_experiment() {
  local force_new="${1:-0}"
  hr; say "3/6 experiment ($SITE, archi=$ARCHI)"
  if [ "$force_new" = "1" ]; then EXP_ID=""; NODE=""; REUSED=0
  elif [ -n "$EXP_ID" ]; then REUSED=1; say "using EXP_ID=$EXP_ID from environment"
  else try_reuse_running; fi
  if [ -z "$EXP_ID" ]; then
    submit_new || { say "could not reserve a node. Other site? run this script on that site's frontend with SITE=<site>"; RESULT_TEXT="experiment submit failed"; finish 4; }
  fi
  say "waiting for experiment $EXP_ID to be Running (timeout ${WAIT_TIMEOUT}s)"
  timeout $((WAIT_TIMEOUT + 30)) iotlab-experiment wait -i "$EXP_ID" --timeout "$WAIT_TIMEOUT" > "$LOGDIR/wait_$EXP_ID.log" 2>&1
  local wrc=$?
  [ $wrc -ne 0 ] && { warn "wait returned $wrc: $(clip 200 < "$LOGDIR/wait_$EXP_ID.log")"; }
  discover_node || { RESULT_TEXT="no ${ARCHI%%:*} node found in experiment $EXP_ID"; finish 4; }
  say "node: $NODE ${NODE_STATE:+(state: $NODE_STATE)}"
  case "$NODE_STATE" in ""|Alive) ;; *) warn "node state is '$NODE_STATE' (expected Alive)";; esac
}

# ---------------------------------------------------------------------- 4 flash
flash_node() {
  hr; say "4/6 flash $APP.elf -> $NODE"
  if [ "$SKIP_FLASH" = "1" ]; then say "SKIP_FLASH=1 -> not flashing"; return 0; fi
  local try out rc
  for try in 1 2; do
    out="$(timeout 240 iotlab-node -i "$EXP_ID" --flash "$ELF" 2>&1)"; rc=$?
    printf '%s\n' "$out" > "$LOGDIR/flash_$try.log"
    if [ $rc -eq 0 ] && printf '%s' "$out" | grep -qE '"0"[[:space:]]*:[[:space:]]*\[' && ! printf '%s' "$out" | grep -qE '"1"[[:space:]]*:[[:space:]]*\['; then
      say "flash OK (attempt $try)"; return 0
    fi
    warn "flash attempt $try failed (rc=$rc): $(printf '%s' "$out" | clip 220)"
    sleep 5
  done
  return 1
}

# -------------------------------------------------------------------- 5 capture
stop_nc() {
  local k
  [ -z "$NCPID" ] && return 0
  kill "$NCPID" 2>/dev/null
  for k in 1 2 3 4 5 6; do kill -0 "$NCPID" 2>/dev/null || break; sleep 0.5; done
  kill -9 "$NCPID" 2>/dev/null
  wait "$NCPID" 2>/dev/null
  NCPID=""
}

CRASH_RE='Context before hardfault|Stack pointer corrupted|kernel panic|HARD FAULT|HardFault'
CRASH=0

# Start the serial client and make sure it STAYS connected. The IoT-LAB serial forwarder
# serves one client at a time and needs a moment to release the port after a previous one.
attach_serial() {
  local log="$1" err="$2" life=$((CAPTURE_SECS + 60)) k
  pkill -u "$(id -u)" -f "nc $NODE $SERIAL_PORT" 2>/dev/null   # stale clients from earlier runs
  for k in 1 2 3 4 5 6; do
    : > "$log"
    # stdin kept open (fd 9) so no netcat flavour exits on stdin EOF.  Not a pipeline:
    # `wait` on a pipeline job would block until the sleep ends.
    exec 9< <(sleep "$life")
    timeout "$life" nc "$NODE" "$SERIAL_PORT" <&9 > "$log" 2> "$err" &
    NCPID=$!
    exec 9<&-
    sleep 2
    if kill -0 "$NCPID" 2>/dev/null; then return 0; fi
    warn "serial attach try $k/6 failed: $(head -c 160 "$err" | clip 160)"
    wait "$NCPID" 2>/dev/null; NCPID=""
    sleep 3
  done
  return 1
}

capture_attempt() {
  local n="$1" i out extra=0 log err pre nb0 nb
  log="$LOGDIR/serial_$n.log"; err="$LOGDIR/nc_$n.err"
  attach_serial "$log" "$err" || { warn "could not attach to $NODE:$SERIAL_PORT"; : > "$LOGDIR/serial_${n}_clean.log"; return 1; }
  pre="$(wc -c < "$log" | tr -d ' ')"; [ "${pre:-0}" -gt "$PRE_MAX" ] && PRE_MAX="$pre"
  printf '%s %s\n' "$n" "${pre:-0}" >> "$LOGDIR/prebytes.txt"
  [ "${pre:-0}" -gt 0 ] && warn "serial delivered $pre bytes BEFORE the reset (most likely the node was still running its post-flash boot); judged on the last run block only"
  nb0="$(tr -d '\r' < "$log" | grep -c "$BANNER")"
  say "capture $n: serial attached ($pre bytes before reset, $nb0 run banner(s)), resetting node"
  out="$(timeout 90 iotlab-node -i "$EXP_ID" --reset 2>&1)"; printf '%s\n' "$out" > "$LOGDIR/reset_$n.log"
  say "reset: $(printf '%s' "$out" | clip 120)"
  i=0
  while [ "$i" -lt "$CAPTURE_SECS" ]; do
    nb="$(tr -d '\r' < "$log" | grep -c "$BANNER")"
    # a run that was already complete BEFORE the reset does not count: wait for a new banner after it
    if run_complete "$log" && { [ "$nb0" -eq 0 ] || [ "$nb" -gt "$nb0" ]; }; then break; fi
    if tr -d '\r' < "$log" | grep -qE "$CRASH_RE"; then
      CRASH=1; extra=$((extra + 1)); [ "$extra" -ge 4 ] && break   # let the register dump finish
    fi
    kill -0 "$NCPID" 2>/dev/null || break
    sleep 1; i=$((i + 1))
  done
  sleep 1
  stop_nc
  tr -d '\r' < "$log" > "$LOGDIR/serial_${n}_clean.log"
  say "captured $(wc -c < "$log") bytes in ${i}s"
  [ "$CRASH" = "1" ] && return 1
  run_complete "$LOGDIR/serial_${n}_clean.log" && { [ "$nb0" -eq 0 ] || [ "$(grep -c "$BANNER" "$LOGDIR/serial_${n}_clean.log")" -gt "$nb0" ]; }
}

capture_loop() {
  hr; say "5/6 capture (serial first, then reset)"
  local n
  for n in $(seq 1 "$ATTEMPTS"); do
    if capture_attempt "$n"; then cp "$LOGDIR/serial_${n}_clean.log" "$LOGDIR/serial_final.log"; return 0; fi
    cp "$LOGDIR/serial_${n}_clean.log" "$LOGDIR/serial_final.log" 2>/dev/null
    if [ "$CRASH" = "1" ]; then warn "firmware crashed (hardfault) - not retrying, a crash is deterministic"; return 1; fi
    warn "attempt $n produced no complete output"
    if [ "$n" -eq 2 ]; then
      warn "power-cycling the node before the last try"
      timeout 60 iotlab-node -i "$EXP_ID" --stop  > "$LOGDIR/stop_node.log" 2>&1; sleep 3
      timeout 60 iotlab-node -i "$EXP_ID" --start > "$LOGDIR/start_node.log" 2>&1; sleep 5
    fi
  done
  # keep the best partial capture for debugging
  cp "$LOGDIR/serial_${ATTEMPTS}_clean.log" "$LOGDIR/serial_final.log" 2>/dev/null
  return 1
}

# ------------------------------------------------------------------- 6 verdict
analyze() {
  hr; say "6/6 verdict"
  local f="$LOGDIR/serial_final.log" r="$LOGDIR/serial_run_final.log" nfail ntot declared
  last_run_block "$f" > "$r"
  hr; cat "$r"; hr
  head -1 "$r" | grep -q "$BANNER" || { RESULT_TEXT="output seen but not from this firmware version"; return 1; }
  DEV_RESULT="$(grep -E '^RESULT:' "$r" | tail -1)"
  CHECKS_TEXT="$(grep -E '^CHECKS:' "$r" | tail -1)"
  nfail="$(grep -cE '^CHECK .*: FAIL' "$r")"
  ntot="$(grep -cE '^CHECK ' "$r")"
  declared="$(printf '%s' "$CHECKS_TEXT" | sed -n 's/.*total=\([0-9]*\).*/\1/p')"
  if [ "$nfail" -gt 0 ]; then RESULT_TEXT="FAIL - $nfail of $ntot checks failed"; grep -E '^CHECK .*: FAIL|^MISMATCH' "$r"; return 1; fi
  if [ "$ntot" -lt "$MIN_CHECKS" ]; then RESULT_TEXT="incomplete - only $ntot checks seen (expected >= $MIN_CHECKS)"; return 1; fi
  if [ -n "$declared" ] && [ "$declared" != "$ntot" ]; then RESULT_TEXT="inconsistent - firmware declared $declared checks but $ntot CHECK lines were captured"; return 1; fi
  case "$DEV_RESULT" in "RESULT: PASS"*) RESULT_TEXT="PASS - $ntot/$ntot checks (firmware declared ${declared:-n/a}), real Cortex-M3 matches host reference"; return 0;; esac
  RESULT_TEXT="no PASS line from device"; return 1
}

# ------------------------------------------------- optional: repeat runs for timing statistics
median_of() {   # $1=file $2=name-prefix : median (cycles) from the 'cycles' line of a timing stat
  last_run_block "$1" | grep -E "^timing $2.*cycles min=" | head -1 | sed -n 's/.*median=\([0-9]*\).*/\1/p'
}
bench_repeats() {
  [ "$REPEATS" -gt 1 ] || return 0
  hr; say "repeat runs for timing statistics (REPEATS=$REPEATS)"
  local i f out="$LOGDIR/bench_summary.txt"
  cp "$LOGDIR/serial_final.log" "$LOGDIR/serial_rep1.log"
  for i in $(seq 2 "$REPEATS"); do
    capture_attempt "rep$i" && cp "$LOGDIR/serial_rep${i}_clean.log" "$LOGDIR/serial_rep$i.log" || warn "repeat $i did not complete"
  done
  {
    echo "timing medians per hardware run (cycles; firmware sha256 $(sha256sum "$ELF" | cut -d' ' -f1))"
    printf '%-4s %-12s %-14s %-12s %-12s\n' run update_plain update_audit extract wire_stage
    for i in $(seq 1 "$REPEATS"); do
      f="$LOGDIR/serial_rep$i.log"; [ -f "$f" ] || continue
      printf '%-4s %-12s %-14s %-12s %-12s\n' "$i" "$(median_of "$f" 'SFVLM_Update \(no audit')" "$(median_of "$f" 'SFVLM_Update \(audit')" \
             "$(median_of "$f" 'SFVLF_Extract')" "$(median_of "$f" 'SFVL_WireStageToStore')"
    done
    echo "(per-run detail: serial_rep<N>.log; each run = 630 Update samples, 18 Extract, 3 WireStage; see TIMING_VALID lines for the clock confirmation)"
  } > "$out"
  cat "$out"
}

# ------------------------------------------------------------------------ main
say "SF-VibraLedger hardware validation  ($STAMP)  logs: $LOGDIR"
preflight
build_fw
acquire_experiment 0
if ! flash_node; then
  if [ "$REUSED" = "1" ]; then
    warn "flash failed on a reused experiment (probably expired) -> creating a fresh one"
    acquire_experiment 1
    flash_node || { RESULT_TEXT="flash failed"; finish 4; }
  else
    RESULT_TEXT="flash failed"; finish 4
  fi
fi
if ! capture_loop; then
  if [ "$CRASH" = "1" ]; then
    hr; say "FIRMWARE CRASH - everything the device printed:"; cat "$LOGDIR/serial_final.log"; hr
    say "typical cause on Cortex-M: stack overflow (check 'configured main stack' / HWT_STACK) or an unaligned/invalid access"
    RESULT_TEXT="firmware crashed with a hardfault after $(grep -cE '^CHECK ' "$LOGDIR/serial_final.log") checks"
    finish 1
  fi
  if [ -s "$LOGDIR/serial_final.log" ]; then
    analyze > /dev/null 2>&1; RESULT_TEXT="no complete NEW run was captured after the reset (last block: ${RESULT_TEXT})"; finish 1
  fi
  RESULT_TEXT="no serial output from $NODE after $ATTEMPTS attempts"; finish 2
fi
if analyze; then bench_repeats; finish 0; else finish 1; fi
