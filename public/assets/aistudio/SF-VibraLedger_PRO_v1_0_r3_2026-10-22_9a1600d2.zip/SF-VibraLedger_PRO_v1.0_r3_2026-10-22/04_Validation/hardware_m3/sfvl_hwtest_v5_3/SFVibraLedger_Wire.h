#ifndef SFVIBRALEDGER_WIRE_H
#define SFVIBRALEDGER_WIRE_H
#include "SFVibraLedger_Core.h"
#include <stddef.h>
#include <stdint.h>

#define SFVL_WIRE_MAGIC 0x33574658u /* XFW3 */
#define SFVL_WIRE_VERSION 3u
#define SFVL_WIRE_ALG 3u
#define SFVL_WIRE_AUTH_HMAC_SHA256 1u
#define SFVL_WIRE_TAG_LEN 32u
#define SFVL_WIRE_HEADER_LEN 32u
#define SFVL_WIRE_MAX_LEN 10000u
#define SFVL_WIRE_CAP_CORE 0x00000001u
#define SFVL_WIRE_CAP_EVIDENCE_GATE 0x00000002u
#define SFVL_WIRE_CAP_UNKNOWN_POOL 0x00000004u
#define SFVL_WIRE_CAP_CONTEXT_CAL 0x00000008u
#define SFVL_WIRE_CAP_TRUST_LEDGER 0x00000010u

typedef enum {
    SFVL_WIRE_OK=0, SFVL_WIRE_NULL=1, SFVL_WIRE_LENGTH=2, SFVL_WIRE_MAGIC_ERR=3,
    SFVL_WIRE_VERSION_ERR=4, SFVL_WIRE_ALG_ERR=5, SFVL_WIRE_AUTH_ERR=6,
    SFVL_WIRE_ROLLBACK_ERR=7, SFVL_WIRE_SCHEMA_ERR=8, SFVL_WIRE_SELFTEST_ERR=9
} SFVL_WireStatus;

typedef struct { SFVL_Model slot[2]; uint8_t active_slot; uint8_t reserved[3]; } SFVL_WireStore;

size_t SFVL_WireSerialize(const SFVL_Model *m, uint32_t capabilities, const uint8_t *key, size_t key_len, uint8_t *buf, size_t cap);
SFVL_WireStatus SFVL_WireStageToStore(const uint8_t *buf, size_t len, const uint8_t *key, size_t key_len, SFVL_WireStore *store);
void SFVL_WireStoreInit(SFVL_WireStore *store, const SFVL_Model *initial);
const SFVL_Model *SFVL_WireStoreActive(const SFVL_WireStore *store);

#endif
