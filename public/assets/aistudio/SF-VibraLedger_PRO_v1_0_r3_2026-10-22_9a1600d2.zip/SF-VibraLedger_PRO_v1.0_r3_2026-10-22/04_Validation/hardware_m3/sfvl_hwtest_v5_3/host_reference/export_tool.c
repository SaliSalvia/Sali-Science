/* Host-side reference generator: commissions exactly like sfvibraledger_eval,
 * serialises the model to the authenticated wire format, replays the monitoring
 * windows on a monitor loaded ONLY from that blob, and emits everything the
 * device needs to verify itself bit-exactly (outputs fingerprint, audit lines,
 * audit chain head, data-integrity hashes). */
#define _POSIX_C_SOURCE 200809L
#include "SFVibraLedger_Commission.h"
#include "SFVibraLedger_Features.h"
#include "SFVibraLedger_Wire.h"
#include "hwt_hash.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int parse_row(char *line, int skip, double *vals, int max) {
    int n = 0, col = 0; char *save = NULL;
    for (char *tok = strtok_r(line, ",;\t \r\n", &save); tok; tok = strtok_r(NULL, ",;\t \r\n", &save), ++col) {
        if (col < skip) continue;
        char *end; double v = strtod(tok, &end); if (end == tok) return -1;
        if (n < max) vals[n++] = v;
    }
    return n;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: export_tool data.csv > sfvl_hwtest_data.h\n"); return 2; }
    const char *in = argv[1];
    const char *key = "sfvibraledger-eval-default-key";
    double fs = 10240.0; unsigned win = 2048, calib = 90; int skip = 1; int32_t full = 32767;
    double freqs[4] = {24.7, 49.4}; int nb = 2;

    FILE *fp = fopen(in, "r"); if (!fp) { perror("input"); return 2; }
    size_t cap = 1u << 16, rows = 0; double *data = NULL; int ch = -1; static char line[65536]; double vals[64];
    while (fgets(line, sizeof(line), fp)) {
        static char tmp[65536]; strncpy(tmp, line, sizeof(tmp) - 1); tmp[sizeof(tmp) - 1] = 0; int n = parse_row(tmp, skip, vals, 64);
        if (n <= 0) { if (rows == 0) continue; fprintf(stderr, "bad row %zu\n", rows + 1); return 2; }
        if (ch < 0) { ch = n; data = (double *)malloc(cap * (size_t)ch * sizeof(double)); } if (n != ch) { fprintf(stderr, "row %zu columns mismatch\n", rows + 1); return 2; }
        if (rows >= cap) { cap *= 2; data = (double *)realloc(data, cap * (size_t)ch * sizeof(double)); } memcpy(&data[rows * (size_t)ch], vals, (size_t)ch * sizeof(double)); ++rows;
    }
    fclose(fp);
    unsigned per = 3u + (unsigned)nb, dims = (unsigned)ch * per;
    SFVLF_Config fc; SFVLF_ConfigInit(&fc); fc.full_scale = full; fc.bands = (uint8_t)nb;
    for (int b = 0; b < nb; ++b) fc.goertzel_coeff_q22[b] = (int32_t)llround(2.0 * cos(6.283185307179586 * freqs[b] / fs) * 4194304.0);

    unsigned nwin = (unsigned)(rows / win);
    int32_t *F = (int32_t *)calloc((size_t)nwin * dims, sizeof(int32_t));
    uint16_t *Q = (uint16_t *)calloc(nwin, sizeof(uint16_t));
    int32_t *buf = (int32_t *)malloc(win * sizeof(int32_t));
    for (unsigned w = 0; w < nwin; ++w) {
        uint16_t qmin = 1024;
        for (int c = 0; c < ch; ++c) {
            for (unsigned i = 0; i < win; ++i) { double v = data[((size_t)w * win + i) * (size_t)ch + (size_t)c]; buf[i] = (int32_t)llround(v); }
            SFVLF_Features f; SFVLF_Extract(buf, win, &fc, &f);
            SFVLF_ToModelVector(&f, &fc, &F[(size_t)w * dims + (unsigned)c * per]); if (f.quality_q < qmin) qmin = f.quality_q;
        }
        Q[w] = qmin;
    }

    static SFVLM_Monitor mon; SFVLM_Config cfg; SFVLM_ConfigDefaults(&cfg);
    SFVLM_Init(&mon, (uint8_t)dims, 1, 4, &cfg, (const uint8_t *)key, strlen(key));
    SFVLC_Report rep;
    if (SFVLC_Commission(&mon, F, Q, calib, NULL, &rep) != 0) { fprintf(stderr, "commission failed\n"); return 3; }

    static uint8_t wire[SFVL_WIRE_MAX_LEN];
    size_t wire_len = SFVL_WireSerialize(&mon.model, SFVL_WIRE_CAP_CORE | SFVL_WIRE_CAP_EVIDENCE_GATE | SFVL_WIRE_CAP_UNKNOWN_POOL | SFVL_WIRE_CAP_TRUST_LEDGER, (const uint8_t *)key, strlen(key), wire, sizeof(wire));
    if (wire_len == 0) { fprintf(stderr, "wire serialize failed\n"); return 4; }

    /* Reference replay: fresh monitor loaded only from the wire blob. */
    static SFVLM_Monitor mon2; SFVLM_Init(&mon2, (uint8_t)dims, 1, 4, &cfg, (const uint8_t *)key, strlen(key));
    static SFVL_WireStore store; SFVL_WireStatus wst = SFVL_WireStageToStore(wire, wire_len, (const uint8_t *)key, strlen(key), &store);
    if (wst != SFVL_WIRE_OK) { fprintf(stderr, "wire stage failed rc=%d\n", (int)wst); return 5; }
    mon2.model = *SFVL_WireStoreActive(&store);
    SFVLM_Arm(&mon2);

    unsigned nmon = nwin - calib;
    int *expected_status = (int *)malloc(nmon * sizeof(int));
    unsigned counts[6] = {0}; long first_alert = -1; uint32_t out_hash = HWT_FNV_INIT;
    for (unsigned w = calib; w < nwin; ++w) {
        SFVLM_Output o; SFVLM_Update(&mon2, &F[(size_t)w * dims], Q[w], &o);
        expected_status[w - calib] = (int)o.status; ++counts[o.status]; out_hash = hwt_hash_output(out_hash, &o);
        if (o.status >= SFVLM_WARNING && first_alert < 0) first_alert = (long)(w - calib);
    }
    int audit_ok = (SFVLAL_Verify(&mon2.audit, (const uint8_t *)key, strlen(key)) == 0);
    unsigned acount = (unsigned)SFVLAL_Count(&mon2.audit);

    /* hashes over the embedded data so a corrupted transfer is caught on-device */
    uint32_t fh = HWT_FNV_INIT, qh = HWT_FNV_INIT;
    for (unsigned w = 0; w < nmon; ++w) { for (unsigned d = 0; d < dims; ++d) fh = hwt_fnv_u32(fh, (uint32_t)F[(size_t)(w + calib) * dims + d]); qh = hwt_fnv_u16(qh, Q[w + calib]); }

    /* ---- raw-sample windows for the on-device feature-extractor cross-check ----
     * Pick windows that cover every status that occurs, plus the last one (max 6).
     * Raw samples are embedded as int16 (checked below) -> ~12 KB of flash per window. */
    unsigned raw_idx[8], nraw = 0;
    {
        int want[4] = {0, 2, 3, 4};
        for (int k = 0; k < 4; ++k) for (unsigned w = 0; w < nmon; ++w) if (expected_status[w] == want[k]) { raw_idx[nraw++] = w; break; }
        raw_idx[nraw++] = nmon - 1u;
        raw_idx[nraw++] = nmon / 3u;
        for (unsigned a = 0; a < nraw; ++a) for (unsigned b = a + 1; b < nraw; ++b) if (raw_idx[b] < raw_idx[a]) { unsigned t = raw_idx[a]; raw_idx[a] = raw_idx[b]; raw_idx[b] = t; }
        unsigned m = 0; for (unsigned a = 0; a < nraw; ++a) if (m == 0 || raw_idx[a] != raw_idx[m - 1]) raw_idx[m++] = raw_idx[a];
        nraw = m;
    }
    uint32_t raw_hash = HWT_FNV_INIT;
    for (unsigned r = 0; r < nraw; ++r) {
        unsigned w = raw_idx[r] + calib;
        for (int c = 0; c < ch; ++c) for (unsigned i = 0; i < win; ++i) {
            long v = llround(data[((size_t)w * win + i) * (size_t)ch + (size_t)c]);
            if (v < -32768 || v > 32767) { fprintf(stderr, "sample %ld does not fit int16\n", v); return 6; }
            raw_hash = hwt_fnv_u16(raw_hash, (uint16_t)(int16_t)v);
        }
    }

    /* ---- emit header ---- */
    printf("/* AUTO-GENERATED by export_tool.c from the shipped demo recording - do not hand-edit. */\n");
    printf("#ifndef SFVL_HWTEST_DATA_H\n#define SFVL_HWTEST_DATA_H\n#include <stdint.h>\n\n");
    printf("#define HWT_DIMS %u\n#define HWT_NMON %u\n#define HWT_WIRE_LEN %zu\n\n", dims, nmon, wire_len);
    printf("static const char HWT_KEY[] = \"%s\";\n\n", key);
    printf("static const uint8_t HWT_WIRE[HWT_WIRE_LEN] = {");
    for (size_t i = 0; i < wire_len; ++i) printf("%s0x%02x", i ? "," : "", wire[i]);
    printf("};\n\n");
    printf("static const int32_t HWT_F[HWT_NMON][HWT_DIMS] = {\n");
    for (unsigned w = 0; w < nmon; ++w) { printf(" {"); for (unsigned d = 0; d < dims; ++d) printf("%s%d", d ? "," : "", F[(size_t)(w + calib) * dims + d]); printf("},\n"); }
    printf("};\n\n");
    printf("static const uint16_t HWT_Q[HWT_NMON] = {"); for (unsigned w = 0; w < nmon; ++w) printf("%s%u", w ? "," : "", Q[w + calib]); printf("};\n\n");
    printf("static const uint8_t HWT_EXPECTED_STATUS[HWT_NMON] = {"); for (unsigned w = 0; w < nmon; ++w) printf("%s%d", w ? "," : "", expected_status[w]); printf("};\n\n");
    printf("#define HWT_EXPECTED_COUNTS_HEALTHY %uu\n#define HWT_EXPECTED_COUNTS_TRANSIENT %uu\n#define HWT_EXPECTED_COUNTS_WATCH %uu\n", counts[0], counts[1], counts[2]);
    printf("#define HWT_EXPECTED_COUNTS_WARNING %uu\n#define HWT_EXPECTED_COUNTS_ALARM %uu\n#define HWT_EXPECTED_COUNTS_DRIFT_LIMIT %uu\n", counts[3], counts[4], counts[5]);
    printf("#define HWT_EXPECTED_FIRST_ALERT %ldl\n#define HWT_EXPECTED_AUDIT_OK %d\n", first_alert, audit_ok);
    printf("#define HWT_EXPECTED_AUDIT_COUNT %uu\n#define HWT_EXPECTED_LEARN_TOTAL %luu\n#define HWT_EXPECTED_LEARN_REJECTED %luu\n", acount, (unsigned long)mon2.learn_total, (unsigned long)mon2.learn_rejected);
    printf("#define HWT_EXPECTED_OUT_HASH 0x%08xu\n#define HWT_F_HASH 0x%08xu\n#define HWT_Q_HASH 0x%08xu\n\n", out_hash, fh, qh);
    printf("static const char *const HWT_EXPECTED_AUDIT_LINES[%u] = {\n", acount);
    for (unsigned i = 0; i < acount; ++i) { char l[512]; SFVLAL_ExportLine(&mon2.audit, i, l, sizeof(l)); printf("  \"%s\"%s\n", l, i + 1 < acount ? "," : ""); }
    printf("};\n\n");
    unsigned head = (mon2.audit.next_index + SFVLAL_CAPACITY - 1u) % SFVLAL_CAPACITY;
    printf("static const uint8_t HWT_EXPECTED_AUDIT_HEAD[32] = {");
    for (unsigned i = 0; i < 32; ++i) printf("%s0x%02x", i ? "," : "", mon2.audit.entries[head].chain_hash[i]);
    printf("};\n\n");
    printf("/* ---- raw samples for the feature-extractor cross-check ---- */\n");
    printf("#define HWT_CH %d\n#define HWT_WIN %u\n#define HWT_BANDS %d\n#define HWT_FULL_SCALE %d\n#define HWT_NRAW %u\n#define HWT_RAW_HASH 0x%08xu\n", ch, win, nb, (int)full, nraw, raw_hash);
    printf("static const int32_t HWT_GOERTZEL_Q22[%d] = {", nb);
    for (int b = 0; b < nb; ++b) printf("%s%d", b ? "," : "", fc.goertzel_coeff_q22[b]);
    printf("};\n");
    printf("static const uint16_t HWT_RAW_IDX[HWT_NRAW] = {"); for (unsigned r = 0; r < nraw; ++r) printf("%s%u", r ? "," : "", raw_idx[r]); printf("};\n");
    printf("static const int16_t HWT_RAW[HWT_NRAW][HWT_CH][HWT_WIN] = {\n");
    for (unsigned r = 0; r < nraw; ++r) {
        unsigned w = raw_idx[r] + calib; printf(" {\n");
        for (int c = 0; c < ch; ++c) {
            printf("  {");
            for (unsigned i = 0; i < win; ++i) printf("%s%lld%s", i ? "," : "", (long long)llround(data[((size_t)w * win + i) * (size_t)ch + (size_t)c]), (i % 24 == 23 && i + 1 < win) ? "\n   " : "");
            printf("}%s\n", c + 1 < ch ? "," : "");
        }
        printf(" }%s\n", r + 1 < nraw ? "," : "");
    }
    printf("};\n\n#endif\n");

    fprintf(stderr, "OK: dims=%u nmon=%u wire_len=%zu counts H=%u T=%u W=%u Wn=%u A=%u D=%u first_alert=%ld audit_ok=%d audit_count=%u out_hash=0x%08x raw_windows=%u\n",
            dims, nmon, wire_len, counts[0], counts[1], counts[2], counts[3], counts[4], counts[5], first_alert, audit_ok, acount, out_hash, nraw);
    return 0;
}
