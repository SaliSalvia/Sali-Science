export_tool.c - how sfvl_hwtest_data.h was generated (host only, needs the full SF-VibraLedger package
because commissioning uses libm/doubles).  From the package's 07_Source directory:

  cc -std=c11 -O2 -ICore -IAudit -IFeatures -IMonitor -IHost -I<this dir>/.. \
     host_reference/export_tool.c Core/SFVibraLedger_Core.c Core/SFVibraLedger_Wire.c \
     Audit/SFVibraLedger_AuditLog.c Features/SFVibraLedger_Features.c Monitor/SFVibraLedger_Monitor.c \
     Host/SFVibraLedger_Commission.c -o export_tool -lm
  ./export_tool 03_Product_Demo/sample_data/demo_simulated_3ch_10240Hz.csv > sfvl_hwtest_data.h

(hwt_hash.h from the parent directory must be on the include path.)
