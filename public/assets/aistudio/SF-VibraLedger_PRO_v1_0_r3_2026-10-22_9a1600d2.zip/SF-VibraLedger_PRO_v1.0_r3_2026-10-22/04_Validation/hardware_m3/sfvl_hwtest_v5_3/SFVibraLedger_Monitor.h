#ifndef SFVIBRALEDGER_MONITOR_H
#define SFVIBRALEDGER_MONITOR_H
/*
 * SF-VibraLedger Monitor: the condition-monitoring application layer.
 *
 *   window features -> normalisation -> multi-prototype reference field (SFVL_Process)
 *   -> deviation ratio -> persistence / hysteresis status machine
 *   -> evidence-gated, trust-budgeted adaptation (SFVL_FeedbackLearnGated)
 *   -> cumulative drift-limit supervision -> tamper-evident audit log
 *
 * Embedded-safe: fixed-size state, integer arithmetic, no dynamic memory, no libm.
 * Commissioning (clustering, robust statistics) is a HOST-side step (see Host/SFVibraLedger_Commission.h)
 * whose result is an ordinary SFVL_Model that can also be shipped as an authenticated wire blob.
 */
#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_AuditLog.h"

typedef enum {
    SFVLM_HEALTHY = 0,
    SFVLM_TRANSIENT = 1,    /* sensor-quality too low to judge; nothing is learned */
    SFVLM_WATCH = 2,        /* approaching the boundary or first out-of-boundary windows */
    SFVLM_WARNING = 3,      /* sustained out-of-boundary state (or drift limit reached) */
    SFVLM_ALARM = 4,        /* sustained large deviation, or a commissioned fault signature matched */
    SFVLM_DRIFT_LIMIT = 5   /* cumulative adaptation reached the configured envelope: needs a human */
} SFVLM_Status;

typedef struct {
    uint8_t  warn_persistence;    /* consecutive out-of-boundary windows -> WARNING (default 3) */
    uint8_t  alarm_persistence;   /* consecutive windows beyond alarm ratio -> ALARM (default 3) */
    uint16_t recover_windows;     /* consecutive healthy windows needed to clear a latched status (default 5) */
    uint32_t watch_ratio_q;       /* deviation ratio (Q10, 1024 = boundary) where WATCH starts (default 800) */
    uint32_t alarm_ratio_q;       /* ratio above which windows count towards ALARM (default 2048) */
    uint32_t drift_limit_q;       /* max cumulative centre displacement in commissioned radii, Q10 (default 2048; 0 = off) */
    uint8_t  adapt_enabled;       /* 1 = evidence-gated adaptation on (default 1) */
    uint8_t  audit_every_n_learn; /* audit checkpoint cadence for applied learning events (default 16) */
    uint8_t  reserved[2];
} SFVLM_Config;

typedef struct {
    SFVLM_Status status;
    uint8_t  matched_class;       /* 255 = none */
    uint8_t  matched_prototype;
    uint8_t  learned;             /* 1 if an authorised adaptation was applied on this window */
    uint16_t health_q;            /* 0..1024, 1024 = at reference centre */
    uint32_t deviation_q;         /* distance / boundary, Q10 (1024 = on the boundary) */
    uint32_t drift_q;             /* worst cumulative drift, Q10 of commissioned radius */
    uint32_t window_index;
} SFVLM_Output;

typedef struct {
    SFVL_Model model;
    SFVLM_Config cfg;
    int32_t  ref_center[SFVL_MAX_PROTOTYPES_PER_CLASS][SFVL_MAX_DIMENSIONS]; /* commissioned centres (class 0) */
    uint32_t ref_radius[SFVL_MAX_PROTOTYPES_PER_CLASS];                     /* commissioned boundary radius */
    uint8_t  armed;
    SFVLM_Status latched, prev_status;
    uint16_t healthy_run, bad_run, severe_run;
    uint16_t learn_since_audit;
    uint32_t window_index;
    uint32_t learn_total, learn_rejected;
    uint8_t  drift_frozen[SFVL_MAX_PROTOTYPES_PER_CLASS];
    SFVLAL_Log audit;
    uint8_t  key[32];
    uint8_t  key_len;
} SFVLM_Monitor;

void SFVLM_ConfigDefaults(SFVLM_Config *cfg);
/* Init sets model defaults and stores the HMAC key (<= 32 bytes) used by the audit chain. */
int  SFVLM_Init(SFVLM_Monitor *mon, uint8_t dimensions, uint8_t classes, uint8_t prototypes_per_class,
               const SFVLM_Config *cfg, const uint8_t *key, size_t key_len);
/* After commissioning has filled mon->model, arm supervision (records reference centres / radii). */
int  SFVLM_Arm(SFVLM_Monitor *mon);
int  SFVLM_Update(SFVLM_Monitor *mon, const int32_t *raw_features, uint16_t quality_q, SFVLM_Output *out);
/* Operator action: promote a matured unknown-state candidate into a labelled class. */
int  SFVLM_PromoteCandidate(SFVLM_Monitor *mon, uint8_t slot, uint8_t target_class);

#endif
