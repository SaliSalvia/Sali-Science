/* SF-VibraLedger - real-hardware validation firmware (RIOT app / native host build).
 *
 * Goal: show that the integer-only core behaves on real Cortex-M3 silicon exactly
 * as it does on x86-64, using the SAME embedded code the product ships
 * (Core, Wire, AuditLog, Features, Monitor - no libm, no heap).
 *
 * The model is commissioned on the host (libm/doubles, host-only by design),
 * shipped as an authenticated wire blob, and replayed here.  Everything printed
 * as a CHECK is compared against host-computed reference values.
 *
 * All integers are printed through long/unsigned long casts so the code is
 * format-clean on every ABI (uint32_t is `unsigned long` on arm-none-eabi). */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "SFVibraLedger_Core.h"
#include "SFVibraLedger_Wire.h"
#include "SFVibraLedger_Monitor.h"
#include "SFVibraLedger_Features.h"
#include "hwt_hash.h"
#include "sfvl_hwtest_data.h"

/* ---- optional cycle counter (Cortex-M DWT CYCCNT); silently disabled elsewhere ---------------
 * HWT_FAKE_CYCLES is a HOST-ONLY test hook: it lets the statistics/self-test logic be exercised
 * natively.  Numbers from a host run mean nothing about the target. */
#if defined(HWT_FAKE_CYCLES)
#include <time.h>
#define HWT_HAVE_CYCLES 1
#define HWT_HAVE_TIMERCAL 1
#define CLOCK_CORECLOCK 4000000000U           /* fake 4 GHz so a host loop looks slower than 1 cycle/iter */
static int cyc_init(void) { return 1; }
static uint32_t cyc_now(void)
{
    struct timespec ts;
    unsigned long long ns;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    ns = (unsigned long long)ts.tv_sec * 1000000000ULL + (unsigned long long)ts.tv_nsec;
    return (uint32_t)(ns * 4ULL);                   /* 4 GHz equivalent */
}
static void sleep_ms(unsigned ms)
{
    struct timespec t;
    t.tv_sec = (time_t)(ms / 1000u);
    t.tv_nsec = (long)(ms % 1000u) * 1000000L;
    nanosleep(&t, NULL);
}
#else
#if !defined(HWT_NO_CYCLES) && defined(__ARM_ARCH_7M__)
#include "cpu.h"
#if defined(__has_include)
#if __has_include("periph_conf.h")
#include "periph_conf.h"
#endif
#endif
#if defined(DWT) && defined(CoreDebug) && defined(DWT_CTRL_CYCCNTENA_Msk) && \
    defined(DWT_CTRL_NOCYCCNT_Msk) && defined(CoreDebug_DEMCR_TRCENA_Msk)
#define HWT_HAVE_CYCLES 1
#endif
#endif

#ifdef HWT_HAVE_CYCLES
static int cyc_init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    if (DWT->CTRL & DWT_CTRL_NOCYCCNT_Msk) { return 0; }
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    return 1;
}
static uint32_t cyc_now(void) { return DWT->CYCCNT; }
#else
static int cyc_init(void) { return 0; }
static uint32_t cyc_now(void) { return 0; }
#endif

/* independent time base (RIOT ztimer, ms) used ONLY to calibrate the cycle counter */
#if defined(HWT_HAVE_CYCLES) && defined(HWT_TIMERCAL) && defined(RIOT_VERSION)
#include "ztimer.h"
#define HWT_HAVE_TIMERCAL 1
static void sleep_ms(unsigned ms) { ztimer_sleep(ZTIMER_MSEC, ms); }
#endif
#endif /* HWT_FAKE_CYCLES */

/* ---- optional stack introspection (RIOT + DEVELHELP) -------------------------------------
 * Real-hardware finding: SFVL_WireStageToStore keeps a whole SFVL_Model (~5.6 KB) on the
 * stack, so it needs roughly 6.5 KB; RIOT's default main-thread stack is only ~2 KB.
 * The Makefile raises it (HWT_STACK); this code measures what is really configured/used. */
#define HWT_STACK_NEEDED 8192L
#if defined(RIOT_VERSION) && defined(DEVELHELP) && !defined(HWT_NO_STACKINFO)
#include "thread.h"
#define HWT_HAVE_STACKINFO 1
static long stack_total(void) { thread_t *t = thread_get_active(); return t ? (long)t->stack_size : -1L; }
/* Same algorithm as RIOT's thread_measure_stack_free(): with DEVELHELP the stack is pre-painted with
 * each word's own address; the first word that no longer matches marks the high-water mark.  Done here
 * by hand because the library function's parameter type differs between RIOT versions/configs
 * (real build error: "incompatible pointer type").  Returns -1 when no paint is found. */
static long stack_free(void)
{
    thread_t *t = thread_get_active();
    uintptr_t start, *p, *end;
    if (!t) { return -1L; }
    start = (uintptr_t)t->stack_start;
    p = (uintptr_t *)start;
    end = (uintptr_t *)(start + (uintptr_t)t->stack_size);
    while (p < end && *p == (uintptr_t)p) { ++p; }
    return ((uintptr_t)p == start) ? -1L : (long)((uintptr_t)p - start);
}
#elif defined(HWT_FAKE_STACK)   /* host-side test hook for the abort path */
#define HWT_HAVE_STACKINFO 1
static long stack_total(void) { return (long)HWT_FAKE_STACK; }
static long stack_free(void)  { return (long)HWT_FAKE_STACK / 2L; }
#endif

static void report_stack(const char *tag)
{
#ifdef HWT_HAVE_STACKINFO
    long total = stack_total(), fr = stack_free();
    if (total > 0 && fr >= 0) {
        printf("stack[%s]: size=%ld free_min=%ld used_max=%ld\n", tag, total, fr, total - fr);
    }
#else
    (void)tag;
#endif
}

static const char *const STATUS_NAME[6] = {"HEALTHY", "TRANSIENT", "WATCH", "WARNING", "ALARM", "DRIFT_LIMIT"};

/* ---- RAM: everything big is static (no stack pressure, no heap) ---- */
static SFVLM_Monitor g_mon;
static SFVL_WireStore g_store;
/* one scratch area shared by two phases that never overlap in time */
static union { uint8_t blob[HWT_WIRE_LEN]; int32_t win[HWT_WIN]; uint32_t sortbuf[3u * HWT_NMON]; } g_scratch;
#define g_blob (g_scratch.blob)
static uint8_t g_wrongkey[sizeof(HWT_KEY)];
static SFVLAL_Log g_alog;

static unsigned long g_checks, g_failed;

static void check(const char *name, int ok)
{
    ++g_checks;
    if (!ok) { ++g_failed; }
    printf("CHECK %s: %s\n", name, ok ? "PASS" : "FAIL");
}

/* ============================ timing measurement ============================ */
static int g_have_cyc;
#ifdef HWT_HAVE_CYCLES
#define HWT_RUNS 3u
#define HWT_MAXSAMPLES (HWT_RUNS * HWT_NMON)
#define HWT_FS_HZ 10240UL                      /* sample rate of the demo recording */
static unsigned long g_clock_mhz_x100;         /* core clock in MHz*100, 0 = unknown */
static unsigned long g_overhead;
static uint32_t g_dt_upd[HWT_MAXSAMPLES];
static uint8_t g_dt_upd_audit[HWT_MAXSAMPLES];
static unsigned g_n_upd;
static uint32_t g_dt_stage[8];
static unsigned g_n_stage;
static uint32_t g_dt_ext[HWT_NRAW * HWT_CH];
static unsigned g_n_ext;

typedef struct { unsigned long n, min, med, p95, max, mean; } stats_t;

static void rec_update(uint32_t dt, int audit)
{
    if (g_n_upd < HWT_MAXSAMPLES) { g_dt_upd[g_n_upd] = dt; g_dt_upd_audit[g_n_upd] = (uint8_t)(audit != 0); ++g_n_upd; }
}
static void rec_stage(uint32_t dt) { if (g_n_stage < 8u) { g_dt_stage[g_n_stage++] = dt; } }
static void rec_ext(uint32_t dt)   { if (g_n_ext < (unsigned)(HWT_NRAW * HWT_CH)) { g_dt_ext[g_n_ext++] = dt; } }

static void sort_u32(uint32_t *a, unsigned n)
{
    for (unsigned i = 1u; i < n; ++i) {
        uint32_t v = a[i];
        unsigned j = i;
        while (j > 0u && a[j - 1u] > v) { a[j] = a[j - 1u]; --j; }
        a[j] = v;
    }
}

/* flag == NULL: all samples; otherwise only those with flag[i] == want */
static int stats_of(stats_t *st, const uint32_t *src, const uint8_t *flag, int want, unsigned n)
{
    uint32_t *b = g_scratch.sortbuf;
    unsigned m = 0u, idx;
    unsigned long sum = 0UL;
    for (unsigned i = 0u; i < n; ++i) {
        if (flag == NULL || flag[i] == (uint8_t)want) { b[m++] = src[i]; sum += src[i]; }
    }
    if (m == 0u) { return 0; }
    sort_u32(b, m);
    idx = (m * 95u + 99u) / 100u;
    if (idx > 0u) { --idx; }
    st->n = m; st->min = b[0]; st->max = b[m - 1u]; st->p95 = b[idx];
    st->med = (m & 1u) ? b[m / 2u] : ((unsigned long)b[m / 2u - 1u] + (unsigned long)b[m / 2u]) / 2UL;
    st->mean = sum / m;
    return 1;
}

static unsigned long to_us(unsigned long cyc)
{
    if (g_clock_mhz_x100 == 0UL) { return 0UL; }
    return (cyc / g_clock_mhz_x100) * 100UL + ((cyc % g_clock_mhz_x100) * 100UL) / g_clock_mhz_x100;
}

static void print_stats(const char *name, const stats_t *s)
{
    printf("timing %s: n=%lu cycles min=%lu median=%lu p95=%lu max=%lu mean=%lu\n",
           name, s->n, s->min, s->med, s->p95, s->max, s->mean);
    if (g_clock_mhz_x100 != 0UL) {
        printf("timing %s: n=%lu us     min=%lu median=%lu p95=%lu max=%lu mean=%lu\n",
               name, s->n, to_us(s->min), to_us(s->med), to_us(s->p95), to_us(s->max), to_us(s->mean));
    }
}

/* Is the counter real, and is the clock what we think it is?  Cross-checked against an
 * independent time base (ztimer, ms) when available; no number is reported as valid otherwise. */
static void timing_selftest(void)
{
    uint32_t best = 0xffffffffu, t0, t1;
    volatile unsigned spin;
    int ok_tick;
    unsigned long nominal_x100 = 0UL;
    int have_cal = 0, ok_cal = 0;
    unsigned long implied_x100 = 0UL;
#ifdef CLOCK_CORECLOCK
    nominal_x100 = (unsigned long)CLOCK_CORECLOCK / 10000UL;
#endif
    for (unsigned i = 0u; i < 200u; ++i) {
        uint32_t a = cyc_now();
        uint32_t b = cyc_now();
        if ((uint32_t)(b - a) < best) { best = (uint32_t)(b - a); }
    }
    g_overhead = best;
    t0 = cyc_now();
    for (spin = 0u; spin < 2000u; ++spin) { }
    t1 = cyc_now();
    ok_tick = ((uint32_t)(t1 - t0) >= 2000u) && ((uint32_t)(t1 - t0) < 4000000u);
    printf("timing selftest: counter read overhead=%lu cycles, 2000-iteration busy loop=%lu cycles (%s)\n",
           g_overhead, (unsigned long)(uint32_t)(t1 - t0), ok_tick ? "counter ticks" : "COUNTER NOT TICKING");
#ifdef HWT_HAVE_TIMERCAL
    if (ok_tick) {
        uint32_t cal[3];
        unsigned long spread;
        for (unsigned i = 0u; i < 3u; ++i) {
            uint32_t c0 = cyc_now();
            sleep_ms(100u);
            cal[i] = (uint32_t)(cyc_now() - c0);
        }
        sort_u32(cal, 3u);
        implied_x100 = (unsigned long)cal[1] / 1000UL;     /* cycles per 100 ms -> MHz*100 */
        spread = (cal[1] != 0u) ? (unsigned long)(cal[2] - cal[0]) * 1000UL / cal[1] : 1000UL;
        have_cal = 1;
        printf("timing selftest: 3 x ztimer 100 ms = %lu / %lu / %lu cycles -> implied core clock %lu.%02lu MHz (spread %lu permille)\n",
               (unsigned long)cal[0], (unsigned long)cal[1], (unsigned long)cal[2],
               implied_x100 / 100UL, implied_x100 % 100UL, spread);
        if (nominal_x100 != 0UL) {
            unsigned long diff = (implied_x100 > nominal_x100) ? implied_x100 - nominal_x100 : nominal_x100 - implied_x100;
            ok_cal = (diff * 1000UL <= nominal_x100 * 30UL);
            printf("timing selftest: nominal core clock %lu.%02lu MHz -> %s (tolerance 3%%)\n",
                   nominal_x100 / 100UL, nominal_x100 % 100UL, ok_cal ? "agrees" : "DISAGREES");
        } else {
            ok_cal = (implied_x100 >= 800UL && implied_x100 <= 20000UL);
        }
        if (spread > 30UL) { ok_cal = 0; }
    }
#endif
    if (!ok_tick) {
        g_have_cyc = 0;
        printf("TIMING_VALID: no (cycle counter does not advance) - no timing will be reported\n");
        return;
    }
    if (have_cal && ok_cal) {
        g_clock_mhz_x100 = implied_x100;
        printf("TIMING_VALID: yes (counter ticks; core clock %lu.%02lu MHz confirmed against an independent ztimer)\n",
               g_clock_mhz_x100 / 100UL, g_clock_mhz_x100 % 100UL);
    } else if (have_cal) {
        g_clock_mhz_x100 = 0UL;
        printf("TIMING_VALID: partial (counter ticks but the clock could not be confirmed - cycles only)\n");
    } else {
        g_clock_mhz_x100 = nominal_x100;
        printf("TIMING_VALID: partial (counter ticks; no independent time base - %s)\n",
               nominal_x100 ? "microseconds use the NOMINAL clock macro, unverified" : "cycles only");
    }
}

static void timing_report(void)
{
    stats_t su, sa, sl, se, ss;
    int h_su, h_sa, h_sl, h_se, h_ss;
    if (!g_have_cyc) { return; }
    printf("timing report: DWT CYCCNT, %lu cycles counter-read overhead included, RTOS-tick interrupts NOT masked (max/p95 may include them; min/median are the stable figures)\n", g_overhead);
    h_sl = stats_of(&sl, g_dt_upd, NULL, 0, g_n_upd);
    h_su = stats_of(&su, g_dt_upd, g_dt_upd_audit, 0, g_n_upd);
    h_sa = stats_of(&sa, g_dt_upd, g_dt_upd_audit, 1, g_n_upd);
    if (h_sl) { print_stats("SFVLM_Update (all windows)", &sl); }
    if (h_su) { print_stats("SFVLM_Update (no audit entry)", &su); }
    if (h_sa) { print_stats("SFVLM_Update (audit entry appended, HMAC-SHA256)", &sa); }
    h_se = stats_of(&se, g_dt_ext, NULL, 0, g_n_ext);
    if (h_se) { print_stats("SFVLF_Extract (1 channel, 2048 samples)", &se); }
    h_ss = stats_of(&ss, g_dt_stage, NULL, 0, g_n_stage);
    if (h_ss) { print_stats("SFVL_WireStageToStore (5558-byte blob, verify+selftest)", &ss); }
    if (h_su && h_se && g_clock_mhz_x100 != 0UL) {
        unsigned long win_us = ((unsigned long)HWT_WIN * 1000000UL) / HWT_FS_HZ;
        unsigned long cpu_us = to_us(se.med) * (unsigned long)HWT_CH + to_us(su.med);
        printf("timing realtime budget: window=%lu samples @ %lu Hz = %lu us; typical CPU per window = %lu us (%lu channels x Extract median + Update median) = %lu.%02lu %% of one core\n",
               (unsigned long)HWT_WIN, HWT_FS_HZ, win_us, cpu_us, (unsigned long)HWT_CH,
               (cpu_us * 100UL) / win_us, ((cpu_us * 10000UL) / win_us) % 100UL);
    }
}
#else  /* no cycle counter in this build */
static void rec_update(uint32_t dt, int audit) { (void)dt; (void)audit; }
static void rec_stage(uint32_t dt) { (void)dt; }
static void rec_ext(uint32_t dt)   { (void)dt; }
static void timing_selftest(void) { }
static void timing_report(void) { printf("timing: not measured in this build (no usable cycle counter, or built with HWT_CYCLES=0)\n"); }
#endif

typedef struct {
    unsigned long counts[6];
    long first_alert;
    unsigned long mismatches;
    uint32_t out_hash;
    int rc;
} replay_t;

static size_t keylen(void) { return sizeof(HWT_KEY) - 1u; }

static int load_model(SFVL_WireStatus *st_out)
{
    SFVLM_Config cfg;
    SFVLM_ConfigDefaults(&cfg);
    if (SFVLM_Init(&g_mon, HWT_DIMS, 1, 4, &cfg, (const uint8_t *)HWT_KEY, keylen()) != 0) { return -1; }
    memset(&g_store, 0, sizeof(g_store));
    {
        uint32_t t0 = g_have_cyc ? cyc_now() : 0u;
        *st_out = SFVL_WireStageToStore(HWT_WIRE, HWT_WIRE_LEN, (const uint8_t *)HWT_KEY, keylen(), &g_store);
        if (g_have_cyc) { rec_stage((uint32_t)(cyc_now() - t0)); }
    }
    if (*st_out != SFVL_WIRE_OK) { return -2; }
    g_mon.model = *SFVL_WireStoreActive(&g_store);
    if (SFVLM_Arm(&g_mon) != 0) { return -3; }
    return 0;
}

static void replay(replay_t *r, int measure)
{
    SFVL_WireStatus st = SFVL_WIRE_OK;
    memset(r, 0, sizeof(*r));
    r->first_alert = -1;
    r->out_hash = HWT_FNV_INIT;
    r->rc = load_model(&st);
    if (r->rc != 0) { printf("replay: load_model rc=%ld wire_status=%ld\n", (long)r->rc, (long)st); return; }

    for (unsigned w = 0; w < HWT_NMON; ++w) {
        SFVLM_Output o;
        unsigned a0 = (unsigned)SFVLAL_Count(&g_mon.audit);
        uint32_t t0 = (measure && g_have_cyc) ? cyc_now() : 0u;
        int urc = SFVLM_Update(&g_mon, HWT_F[w], HWT_Q[w], &o);
        uint32_t dt = (measure && g_have_cyc) ? (uint32_t)(cyc_now() - t0) : 0u;
        if (urc != 0) { r->rc = 100; printf("replay: SFVLM_Update failed at window %lu rc=%ld\n", (unsigned long)w, (long)urc); return; }
        if (measure && g_have_cyc) { rec_update(dt, (unsigned)SFVLAL_Count(&g_mon.audit) != a0); }
        r->counts[o.status]++;
        r->out_hash = hwt_hash_output(r->out_hash, &o);
        if (o.status >= SFVLM_WARNING && r->first_alert < 0) { r->first_alert = (long)w; }
        if ((uint8_t)o.status != HWT_EXPECTED_STATUS[w]) {
            if (r->mismatches < 5u) {
                printf("MISMATCH window %lu: device=%s expected=%s\n", (unsigned long)w,
                       STATUS_NAME[o.status], STATUS_NAME[HWT_EXPECTED_STATUS[w]]);
            }
            r->mismatches++;
        }
    }
}

static int counts_match(const replay_t *r)
{
    return r->counts[0] == HWT_EXPECTED_COUNTS_HEALTHY && r->counts[1] == HWT_EXPECTED_COUNTS_TRANSIENT &&
           r->counts[2] == HWT_EXPECTED_COUNTS_WATCH && r->counts[3] == HWT_EXPECTED_COUNTS_WARNING &&
           r->counts[4] == HWT_EXPECTED_COUNTS_ALARM && r->counts[5] == HWT_EXPECTED_COUNTS_DRIFT_LIMIT;
}

static void print_counts(const char *tag, const replay_t *r)
{
    printf("%s: HEALTHY=%lu TRANSIENT=%lu WATCH=%lu WARNING=%lu ALARM=%lu DRIFT_LIMIT=%lu first_alert=%ld out_hash=0x%08lx\n",
           tag, r->counts[0], r->counts[1], r->counts[2], r->counts[3], r->counts[4], r->counts[5],
           r->first_alert, (unsigned long)r->out_hash);
}

/* On-device feature extraction from RAW samples vs the host's SFVLF_Extract on the same samples.
 * This is the integer DSP front end (RMS, crest, kurtosis, Goertzel tones, quality) that the
 * pre-extracted replay below does not exercise. Must be bit-exact. */
static void feature_tests(void)
{
    SFVLF_Config fc;
    uint32_t rh = HWT_FNV_INIT;
    unsigned long bad_dims = 0, bad_q = 0, calls = 0;
    const unsigned per = 3u + (unsigned)HWT_BANDS;
    static int32_t vec[HWT_DIMS];

    for (unsigned r = 0; r < HWT_NRAW; ++r)
        for (unsigned c = 0; c < HWT_CH; ++c)
            for (unsigned i = 0; i < HWT_WIN; ++i) { rh = hwt_fnv_u16(rh, (uint16_t)HWT_RAW[r][c][i]); }
    check("features_raw_data_intact", rh == HWT_RAW_HASH);

    SFVLF_ConfigInit(&fc);
    fc.full_scale = HWT_FULL_SCALE;
    fc.bands = (uint8_t)HWT_BANDS;
    for (unsigned b = 0; b < (unsigned)HWT_BANDS; ++b) { fc.goertzel_coeff_q22[b] = HWT_GOERTZEL_Q22[b]; }

    for (unsigned r = 0; r < HWT_NRAW; ++r) {
        unsigned idx = HWT_RAW_IDX[r];
        uint16_t qmin = 1024u;
        memset(vec, 0, sizeof(vec));
        for (unsigned c = 0; c < HWT_CH; ++c) {
            SFVLF_Features f;
            uint32_t t0, dt;
            for (unsigned i = 0; i < HWT_WIN; ++i) { g_scratch.win[i] = (int32_t)HWT_RAW[r][c][i]; }
            t0 = g_have_cyc ? cyc_now() : 0u;
            (void)SFVLF_Extract(g_scratch.win, HWT_WIN, &fc, &f);
            dt = g_have_cyc ? (uint32_t)(cyc_now() - t0) : 0u;
            if (g_have_cyc) { rec_ext(dt); }
            ++calls;
            (void)SFVLF_ToModelVector(&f, &fc, &vec[c * per]);
            if (f.quality_q < qmin) { qmin = f.quality_q; }
        }
        for (unsigned d = 0; d < HWT_DIMS; ++d) { if (vec[d] != HWT_F[idx][d]) { ++bad_dims; } }
        if (qmin != HWT_Q[idx]) { ++bad_q; }
        if (bad_dims && r == 0) { printf("feature mismatch in window %lu\n", (unsigned long)idx); }
    }
    printf("feature windows checked: %lu (%lu channel extractions, window=%lu samples)\n",
           (unsigned long)HWT_NRAW, calls, (unsigned long)HWT_WIN);
    check("features_extract_bit_exact_vs_host", bad_dims == 0UL);
    check("features_quality_bit_exact_vs_host", bad_q == 0UL);
}

static void wire_negative_tests(void)
{
    SFVL_WireStatus st;

    memcpy(g_blob, HWT_WIRE, HWT_WIRE_LEN);
    g_blob[HWT_WIRE_LEN / 2u] ^= 0x01u;
    memset(&g_store, 0, sizeof(g_store));
    st = SFVL_WireStageToStore(g_blob, HWT_WIRE_LEN, (const uint8_t *)HWT_KEY, keylen(), &g_store);
    printf("wire tamper(payload bit)   -> status %ld\n", (long)st);
    check("wire_rejects_payload_tamper", st != SFVL_WIRE_OK);

    memcpy(g_blob, HWT_WIRE, HWT_WIRE_LEN);
    g_blob[HWT_WIRE_LEN - 1u] ^= 0x80u;
    memset(&g_store, 0, sizeof(g_store));
    st = SFVL_WireStageToStore(g_blob, HWT_WIRE_LEN, (const uint8_t *)HWT_KEY, keylen(), &g_store);
    printf("wire tamper(auth tag bit)  -> status %ld\n", (long)st);
    check("wire_rejects_tag_tamper", st != SFVL_WIRE_OK);

    memcpy(g_wrongkey, HWT_KEY, sizeof(HWT_KEY));
    g_wrongkey[0] ^= 0x01u;
    memset(&g_store, 0, sizeof(g_store));
    st = SFVL_WireStageToStore(HWT_WIRE, HWT_WIRE_LEN, g_wrongkey, keylen(), &g_store);
    printf("wire wrong key             -> status %ld\n", (long)st);
    check("wire_rejects_wrong_key", st != SFVL_WIRE_OK);

    memset(&g_store, 0, sizeof(g_store));
    st = SFVL_WireStageToStore(HWT_WIRE, HWT_WIRE_LEN - 1u, (const uint8_t *)HWT_KEY, keylen(), &g_store);
    printf("wire truncated by 1 byte   -> status %ld\n", (long)st);
    check("wire_rejects_truncation", st != SFVL_WIRE_OK);

    printf("wire pristine blob         -> staging (deepest stack user)...\n");
    memset(&g_store, 0, sizeof(g_store));
    st = SFVL_WireStageToStore(HWT_WIRE, HWT_WIRE_LEN, (const uint8_t *)HWT_KEY, keylen(), &g_store);
    printf("wire pristine blob         -> status %ld\n", (long)st);
    check("wire_accepts_pristine_blob", st == SFVL_WIRE_OK);
}

static void audit_tests(void)
{
    const uint8_t *key = (const uint8_t *)HWT_KEY;
    char line[200];
    unsigned long n = (unsigned long)SFVLAL_Count(&g_mon.audit);

    check("audit_count_matches_host", n == HWT_EXPECTED_AUDIT_COUNT);
    check("audit_chain_verifies", SFVLAL_Verify(&g_mon.audit, key, keylen()) == 0);

    memcpy(g_wrongkey, HWT_KEY, sizeof(HWT_KEY));
    g_wrongkey[1] ^= 0x04u;
    check("audit_chain_rejects_wrong_key", SFVLAL_Verify(&g_mon.audit, g_wrongkey, keylen()) != 0);

    memcpy(&g_alog, &g_mon.audit, sizeof(g_alog));
    g_alog.entries[1].trust_at_decision_q ^= 1u;
    {
        int vr = SFVLAL_Verify(&g_alog, key, keylen());
        printf("audit tampered entry 1     -> verify rc %ld (expect non-zero)\n", (long)vr);
        check("audit_chain_detects_tamper", vr != 0);
    }

    {
        int same = (n == HWT_EXPECTED_AUDIT_COUNT);
        for (unsigned long i = 0; same && i < n; ++i) {
            line[0] = '\0';
            (void)SFVLAL_ExportLine(&g_mon.audit, (uint32_t)i, line, sizeof(line));
            if (strcmp(line, HWT_EXPECTED_AUDIT_LINES[i]) != 0) {
                same = 0;
                printf("audit line %lu differs:\n  device  : %s\n  expected: %s\n", i, line, HWT_EXPECTED_AUDIT_LINES[i]);
            }
        }
        check("audit_lines_identical_to_host", same);
    }

    {
        unsigned head = (g_mon.audit.next_index + SFVLAL_CAPACITY - 1u) % SFVLAL_CAPACITY;
        check("audit_hmac_chain_head_identical_to_host",
              memcmp(g_mon.audit.entries[head].chain_hash, HWT_EXPECTED_AUDIT_HEAD, 32u) == 0);
    }
    check("learn_total_matches_host", (unsigned long)g_mon.learn_total == HWT_EXPECTED_LEARN_TOTAL);
    check("learn_rejected_matches_host", (unsigned long)g_mon.learn_rejected == HWT_EXPECTED_LEARN_REJECTED);
}

int main(void)
{
    replay_t r1, r2, r3;
    uint32_t fh = HWT_FNV_INIT, qh = HWT_FNV_INIT;
    const unsigned one = 1u;

    printf("\n==== SF-VibraLedger real-hardware validation ====\n");
    printf("platform: sizeof(int)=%lu sizeof(long)=%lu sizeof(void*)=%lu little_endian=%lu\n",
           (unsigned long)sizeof(int), (unsigned long)sizeof(long), (unsigned long)sizeof(void *),
           (unsigned long)(*(const uint8_t *)&one));
    printf("sizes: SFVLM_Monitor=%lu SFVL_WireStore=%lu SFVL_Model=%lu SFVLAL_Log=%lu wire_blob=%lu\n",
           (unsigned long)sizeof(SFVLM_Monitor), (unsigned long)sizeof(SFVL_WireStore), (unsigned long)sizeof(SFVL_Model),
           (unsigned long)sizeof(SFVLAL_Log), (unsigned long)HWT_WIRE_LEN);
    printf("dims=%lu monitoring_windows=%lu\n", (unsigned long)HWT_DIMS, (unsigned long)HWT_NMON);

    g_have_cyc = cyc_init();
    printf("cycle counter: %s\n", g_have_cyc ? "DWT CYCCNT enabled" : "not available (timing skipped)");
    if (g_have_cyc) { timing_selftest(); }
#ifdef HWT_MAIN_STACK
    printf("configured main stack: %lu bytes\n", (unsigned long)HWT_MAIN_STACK);
#endif
#ifdef HWT_HAVE_STACKINFO
    {
        long total = stack_total();
        printf("actual main thread stack: %ld bytes (SFVL_WireStageToStore needs ~6.5 KB)\n", total);
        check("main_stack_sufficient_for_wire_stage", total >= HWT_STACK_NEEDED);
        if (total < HWT_STACK_NEEDED) {
            printf("ABORT: refusing to run - the stack would overflow. Build with HWT_STACK>=12288.\n");
            printf("CHECKS: total=%lu passed=%lu failed=%lu\n", g_checks, g_checks - g_failed, g_failed);
            printf("RESULT: FAIL - %lu check(s) failed, see CHECK lines above\n", g_failed);
            printf("SFVL_DONE\n");
            return 1;
        }
    }
#else
    printf("stack introspection: not available (assuming the build raised the main stack)\n");
#endif

    /* 1. the embedded test data survived transfer/flash */
    for (unsigned w = 0; w < HWT_NMON; ++w) {
        for (unsigned d = 0; d < HWT_DIMS; ++d) { fh = hwt_fnv_u32(fh, (uint32_t)HWT_F[w][d]); }
        qh = hwt_fnv_u16(qh, HWT_Q[w]);
    }
    check("embedded_feature_data_intact", fh == HWT_F_HASH);
    check("embedded_quality_data_intact", qh == HWT_Q_HASH);

    /* 2. authenticated-update path on real silicon */
    wire_negative_tests();

    report_stack("after wire tests");

    /* 2b. integer feature front end on raw samples */
    feature_tests();
    report_stack("after feature tests");

    /* 3. full replay, three independent times from a fresh load each time */
    replay(&r1, 1);
    print_counts("run1", &r1);
    check("run1_loaded_and_ran", r1.rc == 0);
    check("run1_status_sequence_identical_to_host", r1.mismatches == 0);
    check("run1_counts_identical_to_host", counts_match(&r1));
    check("run1_first_alert_identical_to_host", r1.first_alert == HWT_EXPECTED_FIRST_ALERT);
    check("run1_all_output_fields_identical_to_host", r1.out_hash == HWT_EXPECTED_OUT_HASH);

    audit_tests();   /* uses the monitor state left by run 1 */

    replay(&r2, 1);
    print_counts("run2", &r2);
    replay(&r3, 1);
    print_counts("run3", &r3);
    check("run2_identical_to_host", r2.rc == 0 && r2.mismatches == 0 && r2.out_hash == HWT_EXPECTED_OUT_HASH && counts_match(&r2));
    check("run3_identical_to_host", r3.rc == 0 && r3.mismatches == 0 && r3.out_hash == HWT_EXPECTED_OUT_HASH && counts_match(&r3));
    check("deterministic_across_runs", r1.out_hash == r2.out_hash && r2.out_hash == r3.out_hash);

    /* 4. timing (informational, not a pass/fail criterion) */
    timing_report();

    report_stack("end of test");
#ifdef HWT_HAVE_STACKINFO
    {
        long total = stack_total(), fr = stack_free();
        if (total > 0 && fr >= 0) { check("stack_headroom_at_least_25_percent", fr * 4L >= total); }
    }
#endif
    printf("CHECKS: total=%lu passed=%lu failed=%lu\n", g_checks, g_checks - g_failed, g_failed);
    if (g_failed == 0UL) {
        printf("RESULT: PASS - real hardware matches host reference exactly\n");
    } else {
        printf("RESULT: FAIL - %lu check(s) failed, see CHECK lines above\n", g_failed);
    }
    printf("SFVL_DONE\n");
    return (g_failed == 0UL) ? 0 : 1;
}
