/* Shared by the host export tool and the on-device test so both compute the
 * IDENTICAL fingerprint of the monitor outputs.  FNV-1a 32-bit over an
 * explicit little-endian byte serialisation (no struct padding, no ISA
 * dependence). */
#ifndef HWT_HASH_H
#define HWT_HASH_H
#include <stdint.h>
#include "SFVibraLedger_Monitor.h"

static inline uint32_t hwt_fnv_byte(uint32_t h, uint8_t b) { return (h ^ (uint32_t)b) * 16777619u; }
static inline uint32_t hwt_fnv_u16(uint32_t h, uint16_t v) { h = hwt_fnv_byte(h, (uint8_t)(v & 0xffu)); return hwt_fnv_byte(h, (uint8_t)((v >> 8) & 0xffu)); }
static inline uint32_t hwt_fnv_u32(uint32_t h, uint32_t v) { h = hwt_fnv_u16(h, (uint16_t)(v & 0xffffu)); return hwt_fnv_u16(h, (uint16_t)((v >> 16) & 0xffffu)); }
#define HWT_FNV_INIT 2166136261u

static inline uint32_t hwt_hash_output(uint32_t h, const SFVLM_Output *o) {
    h = hwt_fnv_byte(h, (uint8_t)o->status);
    h = hwt_fnv_byte(h, o->matched_class);
    h = hwt_fnv_byte(h, o->matched_prototype);
    h = hwt_fnv_byte(h, o->learned);
    h = hwt_fnv_u16(h, o->health_q);
    h = hwt_fnv_u32(h, o->deviation_q);
    h = hwt_fnv_u32(h, o->drift_q);
    h = hwt_fnv_u32(h, o->window_index);
    return h;
}
#endif
