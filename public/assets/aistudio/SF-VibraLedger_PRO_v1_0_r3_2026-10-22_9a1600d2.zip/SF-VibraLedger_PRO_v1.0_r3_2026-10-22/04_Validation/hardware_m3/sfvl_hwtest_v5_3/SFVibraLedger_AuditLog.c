#include "SFVibraLedger_AuditLog.h"
#include "SFVibraLedger_SHA256.h"
#include <string.h>
#include <stdio.h>

static void hash_prev_and_fields(const uint8_t *key, size_t key_len,
                                  const uint8_t prev_hash[32], const SFVLAL_Entry *e,
                                  uint8_t out[32]) {
    uint8_t buf[32 + sizeof(SFVLAL_Entry)];
    size_t off = 0;
    memcpy(buf + off, prev_hash, 32); off += 32;
    memcpy(buf + off, &e->epoch, sizeof(e->epoch)); off += sizeof(e->epoch);
    memcpy(buf + off, &e->generation_before, sizeof(e->generation_before)); off += sizeof(e->generation_before);
    memcpy(buf + off, &e->generation_after, sizeof(e->generation_after)); off += sizeof(e->generation_after);
    buf[off++] = e->predicted_class;
    buf[off++] = e->predicted_prototype;
    buf[off++] = e->evidence_mask;
    buf[off++] = e->outcome;
    buf[off++] = (uint8_t)e->reject_code;
    memcpy(buf + off, &e->trust_at_decision_q, sizeof(e->trust_at_decision_q)); off += sizeof(e->trust_at_decision_q);
    memcpy(buf + off, &e->sample_fingerprint, sizeof(e->sample_fingerprint)); off += sizeof(e->sample_fingerprint);
    sf_hmac_sha256(key, key_len, buf, off, out);
}

void SFVLAL_Init(SFVLAL_Log *log) {
    if (!log) return;
    memset(log, 0, sizeof(*log));
    /* Fixed genesis anchor: SHA-256("SFVibraLedger_AuditLog_Genesis_v1"), computed
     * at init time so it's reproducible without embedding a magic 32-byte blob by hand. */
    static const uint8_t seed[] = "SFVibraLedger_AuditLog_Genesis_v1";
    sf_sha256(seed, sizeof(seed) - 1u, log->genesis_hash);
    memcpy(log->window_anchor_hash, log->genesis_hash, 32);
}

static const uint8_t *prev_hash_ptr(const SFVLAL_Log *log) {
    if (log->count == 0u) return log->genesis_hash;
    uint32_t last = (log->next_index + SFVLAL_CAPACITY - 1u) % SFVLAL_CAPACITY;
    return log->entries[last].chain_hash;
}

int SFVLAL_Append(SFVLAL_Log *log, const uint8_t *key, size_t key_len,
                uint32_t epoch, uint32_t generation_before, uint32_t generation_after,
                uint8_t predicted_class, uint8_t predicted_prototype, uint8_t evidence_mask,
                uint8_t outcome, int8_t reject_code, uint32_t trust_at_decision_q,
                uint64_t sample_fingerprint) {
    if (!log || !key) return -1;
    SFVLAL_Entry e;
    memset(&e, 0, sizeof(e));
    e.epoch = epoch;
    e.generation_before = generation_before;
    e.generation_after = generation_after;
    e.predicted_class = predicted_class;
    e.predicted_prototype = predicted_prototype;
    e.evidence_mask = evidence_mask;
    e.outcome = outcome;
    e.reject_code = reject_code;
    e.trust_at_decision_q = trust_at_decision_q;
    e.sample_fingerprint = sample_fingerprint;

    hash_prev_and_fields(key, key_len, prev_hash_ptr(log), &e, e.chain_hash);

    if (log->count == SFVLAL_CAPACITY) {
        /* This write evicts entries[next_index]. That entry is exactly the
         * chronological predecessor of the entry that becomes the new
         * oldest (next_index+1), so its hash becomes the new verification
         * anchor for the retained window. */
        memcpy(log->window_anchor_hash, log->entries[log->next_index].chain_hash, 32);
    }

    log->entries[log->next_index] = e;
    log->next_index = (log->next_index + 1u) % SFVLAL_CAPACITY;
    if (log->count < SFVLAL_CAPACITY) ++log->count;
    ++log->total_appended;
    return 0;
}

uint64_t SFVLAL_DroppedCount(const SFVLAL_Log *log) {
    if (!log) return 0u;
    return (log->total_appended > log->count) ? (log->total_appended - log->count) : 0u;
}

uint32_t SFVLAL_Count(const SFVLAL_Log *log) {
    return log ? log->count : 0u;
}

static uint32_t oldest_index(const SFVLAL_Log *log) {
    if (log->count < SFVLAL_CAPACITY) return 0u;
    return log->next_index; /* buffer full: next_index points at the oldest (about to be overwritten) slot */
}

int SFVLAL_Verify(const SFVLAL_Log *log, const uint8_t *key, size_t key_len) {
    if (!log || !key) return -1;
    const uint8_t *prev = log->window_anchor_hash;
    uint32_t start = oldest_index(log);
    for (uint32_t i = 0u; i < log->count; ++i) {
        uint32_t idx = (start + i) % SFVLAL_CAPACITY;
        const SFVLAL_Entry *e = &log->entries[idx];
        uint8_t recomputed[32];
        hash_prev_and_fields(key, key_len, prev, e, recomputed);
        if (memcmp(recomputed, e->chain_hash, 32) != 0) return (int)(i + 1u);
        prev = e->chain_hash;
    }
    return 0;
}

size_t SFVLAL_ExportLine(const SFVLAL_Log *log, uint32_t window_index, char *buf, size_t buf_cap) {
    if (!log || !buf || buf_cap == 0u || window_index >= log->count) return 0u;
    uint32_t idx = (oldest_index(log) + window_index) % SFVLAL_CAPACITY;
    const SFVLAL_Entry *e = &log->entries[idx];
    const char *outcome_str = e->outcome == SFVLAL_OUTCOME_APPLIED ? "APPLIED" :
                               e->outcome == SFVLAL_OUTCOME_ISSUED_NOT_REDEEMED ? "ISSUED_NOT_REDEEMED" :
                               e->outcome == SFVLAL_OUTCOME_ESCALATION ? "ESCALATION" : "REJECTED";
    int n = snprintf(buf, buf_cap,
        "epoch=%u gen=%u->%u class=%u proto=%u evidence=0x%02x trust=%u outcome=%s reject_code=%d",
        (unsigned)e->epoch, (unsigned)e->generation_before, (unsigned)e->generation_after,
        (unsigned)e->predicted_class, (unsigned)e->predicted_prototype, (unsigned)e->evidence_mask,
        (unsigned)e->trust_at_decision_q, outcome_str, (int)e->reject_code);
    return (n > 0) ? (size_t)n : 0u;
}
