#include "SFVibraLedger_Wire.h"
#include "SFVibraLedger_SHA256.h"
#include <string.h>

static void wr16(uint8_t*p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void wr32(uint8_t*p,uint32_t v){for(uint8_t i=0;i<4u;++i)p[i]=(uint8_t)(v>>(8u*i));}
static void wr64(uint8_t*p,uint64_t v){for(uint8_t i=0;i<8u;++i)p[i]=(uint8_t)(v>>(8u*i));}
static uint16_t rd16(const uint8_t*p){return (uint16_t)p[0]|((uint16_t)p[1]<<8);}
static uint32_t rd32(const uint8_t*p){uint32_t v=0;for(uint8_t i=0;i<4u;++i)v|=((uint32_t)p[i])<<(8u*i);return v;}
static uint64_t rd64(const uint8_t*p){uint64_t v=0;for(uint8_t i=0;i<8u;++i)v|=((uint64_t)p[i])<<(8u*i);return v;}
static int32_t rdi32(const uint8_t*p){return (int32_t)rd32(p);}
static int ct_eq(const uint8_t*a,const uint8_t*b,size_t n){uint8_t d=0;for(size_t i=0;i<n;++i)d|=(uint8_t)(a[i]^b[i]);return d==0;}

static size_t payload_size(void){
    return 4u + 16u*4u + 16u*4u + 4u + 8u + 8u + 8u + 4u + 4u + 4u +
           4u + 4u + 4u + 4u + 4u +
           (size_t)SFVL_MAX_CLASSES*SFVL_MAX_PROTOTYPES_PER_CLASS*(1u+4u+4u+4u+8u+4u+4u+16u*4u+16u*4u) +
           (size_t)SFVL_MAX_UNKNOWN_PROTOTYPES*(1u+4u+16u*4u) + 2u;
}

static int selftest(const SFVL_Model*m){
    if(!m||m->active_dimensions==0u||m->active_dimensions>SFVL_MAX_DIMENSIONS||m->active_classes==0u||m->active_classes>SFVL_MAX_CLASSES||m->prototypes_per_class==0u||m->prototypes_per_class>SFVL_MAX_PROTOTYPES_PER_CLASS) return 0;
    if(m->base_alpha_fp>SFVL_Q||m->min_sensor_quality_q>SFVL_Q||m->trust_decay_per_epoch_q>SFVL_Q||m->trust_learn_cost_q>SFVL_Q||m->min_trust_for_maturity_q>SFVL_Q||m->min_trust_for_learn_q>SFVL_Q) return 0;
    for(uint8_t d=0;d<m->active_dimensions;++d) if(m->norm_scale[d]<SFVL_MIN_SCALE||m->norm_scale[d]>SFVL_MAX_SCALE) return 0;
    for(uint8_t c=0;c<m->active_classes;++c) for(uint8_t p=0;p<m->prototypes_per_class;++p){
        const SFVL_Prototype*pr=&m->proto[c][p]; if(!pr->valid) continue;
        if(pr->threshold_sq==0u||pr->trust_q>SFVL_Q) return 0;
        for(uint8_t d=0;d<m->active_dimensions;++d) if(pr->scale[d]<SFVL_MIN_SCALE||pr->scale[d]>SFVL_MAX_SCALE) return 0;
    }
    return 1;
}

void SFVL_WireStoreInit(SFVL_WireStore*store,const SFVL_Model*initial){if(!store)return;memset(store,0,sizeof(*store));if(initial){store->slot[0]=*initial;store->slot[1]=*initial;}}
const SFVL_Model *SFVL_WireStoreActive(const SFVL_WireStore*store){if(!store)return NULL;return &store->slot[store->active_slot&1u];}

size_t SFVL_WireSerialize(const SFVL_Model*m,uint32_t caps,const uint8_t*key,size_t key_len,uint8_t*buf,size_t cap){
    if(!m||!key||!buf)return 0u;
    size_t ps=payload_size(), total=SFVL_WIRE_HEADER_LEN+ps+SFVL_WIRE_TAG_LEN;
    if(total>cap||total>SFVL_WIRE_MAX_LEN)return 0u;
    memset(buf,0,total);
    wr32(buf+0,SFVL_WIRE_MAGIC);wr16(buf+4,SFVL_WIRE_VERSION);wr16(buf+6,SFVL_WIRE_ALG);wr32(buf+8,(uint32_t)ps);wr64(buf+12,m->generation);wr32(buf+20,caps);wr32(buf+24,0x00030001u);wr16(buf+28,0u);wr16(buf+30,0u);
    size_t o=SFVL_WIRE_HEADER_LEN;
    buf[o++]=m->active_dimensions;buf[o++]=m->active_classes;buf[o++]=m->prototypes_per_class;buf[o++]=m->reserved;
    for(uint8_t i=0;i<16u;++i){wr32(buf+o,(uint32_t)m->norm_center[i]);o+=4u;} for(uint8_t i=0;i<16u;++i){wr32(buf+o,m->norm_scale[i]);o+=4u;}
    wr32(buf+o,m->base_alpha_fp);o+=4u;wr64(buf+o,m->learn_margin_sq);o+=8u;wr64(buf+o,m->learn_slack_sq);o+=8u;wr64(buf+o,m->unknown_join_threshold_sq);o+=8u;wr32(buf+o,m->unknown_promote_hits);o+=4u;wr32(buf+o,m->min_sensor_quality_q);o+=4u;wr32(buf+o,m->generation);o+=4u;
    wr32(buf+o,m->epoch);o+=4u;wr32(buf+o,m->trust_decay_per_epoch_q);o+=4u;wr32(buf+o,m->trust_learn_cost_q);o+=4u;wr32(buf+o,m->min_trust_for_maturity_q);o+=4u;wr32(buf+o,m->min_trust_for_learn_q);o+=4u;
    for(uint8_t c=0;c<SFVL_MAX_CLASSES;++c)for(uint8_t p=0;p<SFVL_MAX_PROTOTYPES_PER_CLASS;++p){
        const SFVL_Prototype*pr=&m->proto[c][p];buf[o++]=pr->valid;wr32(buf+o,pr->hits);o+=4u;wr32(buf+o,pr->trust_q);o+=4u;wr32(buf+o,pr->trust_epoch);o+=4u;wr64(buf+o,pr->threshold_sq);o+=8u;wr32(buf+o,pr->radius_mean);o+=4u;wr32(buf+o,pr->radius_mad);o+=4u;for(uint8_t d=0;d<16u;++d){wr32(buf+o,(uint32_t)pr->center[d]);o+=4u;}for(uint8_t d=0;d<16u;++d){wr32(buf+o,pr->scale[d]);o+=4u;}}
    for(uint8_t i=0;i<SFVL_MAX_UNKNOWN_PROTOTYPES;++i){const SFVL_UnknownPrototype*u=&m->unknown[i];buf[o++]=u->valid;wr32(buf+o,u->hits);o+=4u;for(uint8_t d=0;d<16u;++d){wr32(buf+o,(uint32_t)u->center[d]);o+=4u;}}buf[o++]=0u;buf[o++]=0u;
    if(o!=SFVL_WIRE_HEADER_LEN+ps)return 0u;
    uint8_t tag[SFVL_WIRE_TAG_LEN];sf_hmac_sha256(key,key_len,buf,SFVL_WIRE_HEADER_LEN+ps,tag);memcpy(buf+SFVL_WIRE_HEADER_LEN+ps,tag,SFVL_WIRE_TAG_LEN);return total;
}

SFVL_WireStatus SFVL_WireStageToStore(const uint8_t*buf,size_t len,const uint8_t*key,size_t key_len,SFVL_WireStore*store){
    if(!buf||!key||!store)return SFVL_WIRE_NULL;
    if(len<SFVL_WIRE_HEADER_LEN+SFVL_WIRE_TAG_LEN||len>SFVL_WIRE_MAX_LEN)return SFVL_WIRE_LENGTH;
    if(rd32(buf)!=SFVL_WIRE_MAGIC)return SFVL_WIRE_MAGIC_ERR;
    if(rd16(buf+4)!=SFVL_WIRE_VERSION)return SFVL_WIRE_VERSION_ERR;
    if(rd16(buf+6)!=SFVL_WIRE_ALG)return SFVL_WIRE_ALG_ERR;
    uint32_t ps=rd32(buf+8);if((size_t)ps+SFVL_WIRE_HEADER_LEN+SFVL_WIRE_TAG_LEN!=len||ps!=payload_size())return SFVL_WIRE_LENGTH;
    uint8_t tag[SFVL_WIRE_TAG_LEN];sf_hmac_sha256(key,key_len,buf,SFVL_WIRE_HEADER_LEN+ps,tag);if(!ct_eq(tag,buf+SFVL_WIRE_HEADER_LEN+ps,SFVL_WIRE_TAG_LEN))return SFVL_WIRE_AUTH_ERR;
    uint64_t gen=rd64(buf+12);uint32_t caps=rd32(buf+20);const uint32_t supported=SFVL_WIRE_CAP_CORE|SFVL_WIRE_CAP_EVIDENCE_GATE|SFVL_WIRE_CAP_UNKNOWN_POOL|SFVL_WIRE_CAP_CONTEXT_CAL|SFVL_WIRE_CAP_TRUST_LEDGER;
    if((caps&SFVL_WIRE_CAP_CORE)==0u||(caps&SFVL_WIRE_CAP_TRUST_LEDGER)==0u||(caps&~supported)!=0u)return SFVL_WIRE_SCHEMA_ERR;
    const SFVL_Model*active=SFVL_WireStoreActive(store);if(active&&gen<=(uint64_t)active->generation)return SFVL_WIRE_ROLLBACK_ERR;
    SFVL_Model shadow;memset(&shadow,0,sizeof(shadow));size_t o=SFVL_WIRE_HEADER_LEN;
    shadow.active_dimensions=buf[o++];shadow.active_classes=buf[o++];shadow.prototypes_per_class=buf[o++];shadow.reserved=buf[o++];
    for(uint8_t i=0;i<16u;++i){shadow.norm_center[i]=rdi32(buf+o);o+=4u;}for(uint8_t i=0;i<16u;++i){shadow.norm_scale[i]=rd32(buf+o);o+=4u;}
    shadow.base_alpha_fp=rd32(buf+o);o+=4u;shadow.learn_margin_sq=rd64(buf+o);o+=8u;shadow.learn_slack_sq=rd64(buf+o);o+=8u;shadow.unknown_join_threshold_sq=rd64(buf+o);o+=8u;shadow.unknown_promote_hits=rd32(buf+o);o+=4u;shadow.min_sensor_quality_q=rd32(buf+o);o+=4u;shadow.generation=rd32(buf+o);o+=4u;
    shadow.epoch=rd32(buf+o);o+=4u;shadow.trust_decay_per_epoch_q=rd32(buf+o);o+=4u;shadow.trust_learn_cost_q=rd32(buf+o);o+=4u;shadow.min_trust_for_maturity_q=rd32(buf+o);o+=4u;shadow.min_trust_for_learn_q=rd32(buf+o);o+=4u;
    for(uint8_t c=0;c<SFVL_MAX_CLASSES;++c)for(uint8_t p=0;p<SFVL_MAX_PROTOTYPES_PER_CLASS;++p){SFVL_Prototype*pr=&shadow.proto[c][p];pr->valid=buf[o++];pr->hits=rd32(buf+o);o+=4u;pr->trust_q=rd32(buf+o);o+=4u;pr->trust_epoch=rd32(buf+o);o+=4u;pr->threshold_sq=rd64(buf+o);o+=8u;pr->radius_mean=rd32(buf+o);o+=4u;pr->radius_mad=rd32(buf+o);o+=4u;for(uint8_t d=0;d<16u;++d){pr->center[d]=rdi32(buf+o);o+=4u;}for(uint8_t d=0;d<16u;++d){pr->scale[d]=rd32(buf+o);o+=4u;}}
    for(uint8_t i=0;i<SFVL_MAX_UNKNOWN_PROTOTYPES;++i){SFVL_UnknownPrototype*u=&shadow.unknown[i];u->valid=buf[o++];u->hits=rd32(buf+o);o+=4u;for(uint8_t d=0;d<16u;++d){u->center[d]=rdi32(buf+o);o+=4u;}}o+=2u;
    if(o!=SFVL_WIRE_HEADER_LEN+ps)return SFVL_WIRE_LENGTH;
    if((uint64_t)shadow.generation!=gen)return SFVL_WIRE_SCHEMA_ERR;
    if(!selftest(&shadow))return SFVL_WIRE_SELFTEST_ERR;
    uint8_t inactive=(uint8_t)(1u-(store->active_slot&1u));store->slot[inactive]=shadow;store->active_slot=inactive;return SFVL_WIRE_OK;
}
