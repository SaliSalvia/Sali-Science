#!/usr/bin/env bash
# =============================================================================
#  Re-derive the verdict from the SAVED logs of a run (hardware is not touched, originals are not modified).
#  usage: bash reanalyze.sh [LOGDIR]        (default ~/sfvl_project/logs/latest)
#  Output: <LOGDIR>/summary_reanalyzed.txt
#  Why: the serial log of a capture can begin with the tail of an earlier run (the node runs right after
#  flashing).  This judges each capture on its LAST run block only and cross-checks the number of CHECK
#  lines against the total the firmware itself declared.
# =============================================================================
set -u
LOGDIR="$(readlink -f "${1:-$HOME/sfvl_project/logs/latest}")"
[ -d "$LOGDIR" ] || { echo "no such log dir: $LOGDIR"; exit 5; }
BANNER='==== SF-VibraLedger real-hardware validation ===='
OUT="$LOGDIR/summary_reanalyzed.txt"
last_block() { tr -d '\r' < "$1" | awk -v b="$BANNER" 'index($0,b)==1{buf=""} {buf=buf $0 "\n"} END{printf "%s", buf}'; }
meta() { grep -E "^$1" "$LOGDIR/summary.txt" 2>/dev/null | head -1 | sed 's/  */ /g'; }
med() { printf '%s\n' "$1" | grep -E "^timing $2.*$3 min=" | head -1 | sed -n 's/.*median=\([0-9]*\).*/\1/p'; }

files=()
for i in 1 2 3 4 5 6 7 8 9; do [ -f "$LOGDIR/serial_rep$i.log" ] && files+=("$LOGDIR/serial_rep$i.log"); done
[ ${#files[@]} -eq 0 ] && [ -f "$LOGDIR/serial_final.log" ] && files=("$LOGDIR/serial_final.log")
[ ${#files[@]} -eq 0 ] && { echo "no serial logs in $LOGDIR"; exit 5; }

{
echo "SF-VibraLedger - re-analysis of saved logs (hardware not touched, originals unmodified)"
echo "log dir     : $LOGDIR"
for k in "experiment" "firmware" "elf sha256" "size" "build " "build args" "source hash" "command"; do m="$(meta "$k")"; [ -n "$m" ] && echo "$m"; done
echo
echo "captures    : ${#files[@]}"
printf '%-8s %-9s %-9s %-9s %-12s %-12s %-12s %-12s\n' capture checks declared result upd_plain upd_audit extract wire_stage
pass=0; hashes=""; valid=""; n=0
for f in "${files[@]}"; do
  n=$((n+1)); b="$(last_block "$f")"
  ok=1; [ "$(printf '%s\n' "$b" | head -1)" = "$BANNER" ] || ok=0
  printf '%s\n' "$b" | grep -q '^SFVL_DONE' || ok=0
  ntot="$(printf '%s\n' "$b" | grep -cE '^CHECK ')"; nfail="$(printf '%s\n' "$b" | grep -cE '^CHECK .*: FAIL')"
  decl="$(printf '%s\n' "$b" | grep -E '^CHECKS:' | tail -1 | sed -n 's/.*total=\([0-9]*\).*/\1/p')"
  res="$(printf '%s\n' "$b" | sed -n 's/^RESULT: \([A-Z]*\).*/\1/p' | tail -1)"
  [ "$ok" = 1 ] && [ "$nfail" = 0 ] && [ "$ntot" = "$decl" ] && [ "$res" = "PASS" ] && pass=$((pass+1)) || res="${res:-none}!"
  hashes="$hashes $(printf '%s\n' "$b" | grep -E '^run1:' | sed -n 's/.*out_hash=\(0x[0-9a-f]*\).*/\1/p')"
  valid="$valid|$(printf '%s\n' "$b" | grep -E '^TIMING_VALID:' | cut -c1-20)"
  printf '%-8s %-9s %-9s %-9s %-12s %-12s %-12s %-12s\n' "$(basename "$f" .log | sed 's/serial_//')" "$ntot" "${decl:-n/a}" "$res" \
     "$(med "$b" 'SFVLM_Update \(no audit' cycles)" "$(med "$b" 'SFVLM_Update \(audit' cycles)" "$(med "$b" 'SFVLF_Extract' cycles)" "$(med "$b" 'SFVL_WireStageToStore' cycles)"
done
echo "(timing columns are median cycles per call)"
echo
echo "correctness : PASS in $pass of ${#files[@]} captures (each judged on its last run block; CHECK-line count == firmware-declared total)"
echo "run1 hash   : $(printf '%s\n' $hashes | sort -u | tr '\n' ' ')  <- identical across captures if only one value is listed"
echo "timing      : $(printf '%s' "$valid" | tr '|' '\n' | sort -u | grep -v '^$' | tr '\n' ' ')"
b="$(last_block "${files[0]}")"
printf '%s\n' "$b" | grep -E '^timing (selftest|SFVLM|SFVLF|SFVL_Wire|realtime)|^TIMING_VALID|^stack\[end' | cut -c1-210
echo
echo "serial freshness (bytes that arrived BEFORE each reset, from run.log):"
sed -n 's/.*\(attempt\|capture\) \([^ :/]*\)[^(]*(\([0-9]*\) bytes before reset).*/  capture \2: \3 bytes/p' "$LOGDIR/run.log" 2>/dev/null
echo "  0 bytes = output can only be from a run started after the reset; non-zero on the first capture is normally the node still printing its post-flash boot run."
} | tee "$OUT"
echo; echo "written: $OUT"
