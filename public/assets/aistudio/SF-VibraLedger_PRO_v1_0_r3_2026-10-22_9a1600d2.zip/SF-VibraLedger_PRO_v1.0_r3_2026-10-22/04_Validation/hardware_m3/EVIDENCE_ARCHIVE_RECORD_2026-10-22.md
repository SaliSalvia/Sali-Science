# Evidence archive record - on-target validation of SF-VibraLedger (Cortex-M3)

The raw evidence behind `04_Validation/HARDWARE_VALIDATION_M3.md` is kept **outside** this package (3.7 MB) in one archive. This file records its identity and what was checked against it.

| Item | Value |
|---|---|
| Archive | `evidence_20261022.tar.gz` (received as `evidence_20261022_tar.gz`) |
| Size | 3,683,073 bytes |
| SHA-256 | `0cbb64cc7815bfce28d149e08199720a7101741dac099c322c1e94df009cd574` |
| Made by | the operator, on the IoT-LAB Grenoble frontend, 2026-10-22: `tar -czf evidence_<date>.tar.gz logs verification_repro_* verification_20261011 sfvl_hwtest_v5_2/bin/iotlab-m3/sfvl_hwtest.elf` (run from `~/sfvl_project`) |
| Hash check | the operator's phone reported the SHA-256 above and the copy analysed here has the same value. **Not yet confirmed:** the hash of the file as it sits on the frontend (`sha256sum ~/sfvl_project/evidence_*.tar.gz` should print the same value) |
| Integrity | `tar -tzf` clean; 154 regular files + 1 symlink (`logs/latest`); per-file SHA-256 list: `EVIDENCE_ARCHIVE_MANIFEST_20261022.txt` (same folder) |

## Contents

* `logs/run_*` - one directory per `run_hwtest.sh` run: `summary.txt`, `run.log`, serial captures, flash/reset/build logs, `debug_report.txt` for failed runs.
* `verification_20261011/` - `original_release.elf` and `build_A_warning.elf` (a build made while checking the release; its flags are not recorded in the archive).
* `verification_repro_20261017_124329/` and `verification_repro_20261018_085622/` - two `repro_check.sh` runs: build logs, both ELFs, `repro_report.txt`.
* `sfvl_hwtest_v5_2/bin/iotlab-m3/sfvl_hwtest.elf` - the ELF of the firmware under test (rebuilt by the last `repro_check.sh`).

## Runs recorded in the archive (from each run's own `summary.txt`)

| Run directory | Experiment / node | ELF sha256 (first 16) | Result |
|---|---|---|---|
| `run_20261011_093606` | 453341 / m3-10 | `366ea6d742105d1a` (v2) | HardFault after 6 passed checks (2 data-integrity + 4 wire rejections); exit 1 |
| `run_20261011_093905` | 453341 / m3-10 (reused) | `366ea6d742105d1a` (v2) | same HardFault; exit 1 |
| `run_20261011_204537` | 453444 / m3-7 | `d490c9e1dc2c26df` (v3, 12 KB stack) | 23/23 PASS |
| `run_20261011_212027` | 453451 / m3-10 | `1c6125658e4dea57` (**release ELF**) | 25/25 PASS; stack used_max 6,992 B of 12,288 B (free_min 5,296 B); cycle counter off in this build |
| `run_20261017_124817` | 455502 / m3-100 | `92ecaa4d98470d90` (v5.1) | 26/26 PASS; timing `partial` |
| `run_20261017_213850` | 455517 / m3-100 (reused) | `88bd7416a0d9a32e` (v5.2) | 28/28 PASS, timing `VALID`; 5 captures. The run's own verdict line says "29/29" (runner v5.2 counted a stale tail; fixed in v5.3, the re-analysis shows 28/28 in 5 of 5 captures) |

## Cross-checks made on the received archive

* ELF hashes: `original_release.elf` = both `repro_A/B.elf` of 2026-10-17 = `1c6125658e4dea57...` (the ELF of run `212027`); `repro_A/B.elf` of 2026-10-18 = `sfvl_hwtest_v5_2/bin/.../sfvl_hwtest.elf` = `88bd7416a0d9a32e...` (the ELF of run `213850`). `build_A_warning.elf` = `c929373a2c3e3063...` (a different build, not used as evidence).
* No old-brand strings (`xsf`, `x-sfense`) in the release ELF or in the firmware-under-test ELF; the new `SFVL`/`VibraLedger` symbols are present in both.
* The transcriptions in `evidence_excerpts_2026-10-18.txt` match the raw `summary_reanalyzed.txt` (23 lines compared); the hashes quoted from both `repro_report.txt` files are present in the raw reports.
* Corrections to earlier statements, found by reading the raw files: the first two runs passed **6** checks before the HardFault (not 5); the release ELF itself was run on hardware (run `212027`) - it was missing from the r2 history table.

## Notes

* The ELFs are not stripped and carry debug information with absolute build paths (including the operator's IoT-LAB login). Fine for internal evidence; strip and review before distributing a firmware outside the team.
* The archive is a snapshot of the frontend's `~/sfvl_project` at 2026-10-22. Keep it unmodified; if more runs are added, make a new archive and a new record rather than editing this one.
