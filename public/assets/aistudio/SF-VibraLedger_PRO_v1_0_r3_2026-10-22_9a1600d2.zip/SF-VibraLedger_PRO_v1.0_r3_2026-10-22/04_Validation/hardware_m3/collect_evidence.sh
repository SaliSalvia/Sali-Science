#!/usr/bin/env bash
# Pack the raw evidence of an on-target run into ONE archive with an internal SHA-256 manifest.
# Run on the IoT-LAB frontend, after the hardware test:
#   bash collect_evidence.sh ~/sfvl_project/logs/run_20261017_213850 ~/sfvl_project/verification_repro_20261018_085622
# Everything listed is only READ; the archive is written to ~/sfvl_project/evidence_<timestamp>.tar.gz
set -u
[ $# -ge 1 ] || { echo "usage: bash collect_evidence.sh <log dir> [<more dirs/files> ...]"; exit 2; }
STAMP="$(date +%Y%m%d_%H%M%S)"; BASE="$(mktemp -d)"; ROOT="$BASE/evidence_$STAMP"; mkdir -p "$ROOT"
for p in "$@"; do
  [ -e "$p" ] || { echo "missing: $p"; exit 3; }
  cp -a "$p" "$ROOT/" || exit 3
done
{ echo "collected: $(date -u '+%F %T') UTC on $(hostname) by $(whoami)"; echo "inputs   : $*"; } > "$ROOT/COLLECTED.txt"
( cd "$ROOT" && find . -type f ! -name EVIDENCE_SHA256.txt -print0 | sort -z | xargs -0 sha256sum > EVIDENCE_SHA256.txt )
OUT="$HOME/sfvl_project/evidence_$STAMP.tar.gz"
tar -C "$BASE" -czf "$OUT" "evidence_$STAMP" || exit 4
tar -tzf "$OUT" > /dev/null || { echo "archive verification failed"; exit 4; }
rm -rf "$BASE"
echo "archive : $OUT"; echo "size    : $(wc -c < "$OUT") bytes"; echo "sha256  : $(sha256sum "$OUT" | cut -d' ' -f1)"
echo "Keep this archive and its sha256 with the release package (the package itself carries only excerpts)."
