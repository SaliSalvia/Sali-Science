"""Cross-check the integer feature extractor (real C code) against float64 numpy on 300 random windows. Exits non-zero on failure."""
import ctypes as C, math, sys, numpy as np, xs_bind as xb
fs = 12800.0; N = 1024; rng = np.random.default_rng(1)
def run(x, bands=()):
    coeffs = [xb.coeff_q22(f, fs) for f in bands]
    v, raw, q = xb.features(np.asarray(x, dtype=np.int64), fs_full=0, coeffs=coeffs); return raw, q
worst = dict(rms=0.0, peak=0.0, kurt=0.0, crest=0.0, tone=0.0)
for trial in range(300):
    t = np.arange(N) / fs; A = rng.uniform(200, 60000); f0 = rng.uniform(20, 300); imp = np.zeros(N)
    if rng.random() < 0.5: imp[rng.integers(0, N, rng.integers(1, 6))] = rng.uniform(1, 8) * A
    x = np.round(A * np.sin(2 * np.pi * f0 * t + rng.uniform(0, 6)) + rng.normal(0, rng.uniform(0.05, 1) * A, N) + imp + rng.uniform(-5000, 5000)).astype(np.int64)
    raw, q = run(x, bands=[f0]); y = x - int(np.trunc(x.mean())); yf = y.astype(float)
    rms = math.sqrt(np.mean(yf ** 2)); pk = np.abs(y).max(); k = np.mean(yf ** 4) / np.mean(yf ** 2) ** 2
    worst["rms"] = max(worst["rms"], abs(raw[1] - rms) / rms); worst["peak"] = max(worst["peak"], abs(raw[2] - pk) / pk)
    worst["kurt"] = max(worst["kurt"], abs(raw[4] / 1024 - k) / k); worst["crest"] = max(worst["crest"], abs(raw[3] / 1024 - pk / rms) / (pk / rms))
    w = 2 * np.pi * f0 / fs; amp = 2 * abs(np.sum(yf * np.exp(-1j * w * np.arange(N)))) / N; worst["tone"] = max(worst["tone"], abs(raw[5] - amp) / max(amp, 1))
print("max relative error vs float64 numpy (300 windows):", {k: round(v, 5) for k, v in worst.items()})
lim = dict(rms=0.01, peak=1e-9, kurt=0.01, crest=0.01, tone=0.02)
bad = {k: v for k, v in worst.items() if v > lim[k]}
if bad: print("FAIL", bad); sys.exit(1)
print("FEATURES_VS_NUMPY PASS (limits: %s)" % lim)
