"""ctypes binding to the REAL compiled SF-VibraLedger library (libsfvibraledger.so). No algorithm is re-implemented in Python."""
import ctypes as C, os, numpy as np, math

_HERE = os.path.dirname(os.path.abspath(__file__))
_LIBPATH = os.environ.get("SFVIBRALEDGER_LIB", os.path.join(_HERE, "..", "..", "07_Source", "libsfvibraledger.so"))
L = C.CDLL(_LIBPATH)
L.xs_new.restype = C.c_void_p; L.xs_free.argtypes = [C.c_void_p]
L.xs_init.argtypes = [C.c_void_p, C.c_int, C.c_int, C.c_int, C.c_char_p, C.c_int]; L.xs_init.restype = C.c_int
L.xs_set.argtypes = [C.c_void_p, C.c_int, C.c_uint64]; L.xs_set.restype = C.c_int
L.xs_commission.argtypes = [C.c_void_p, C.POINTER(C.c_int32), C.POINTER(C.c_uint16), C.c_uint32, C.POINTER(C.c_int64)]; L.xs_commission.restype = C.c_int
L.xs_update.argtypes = [C.c_void_p, C.POINTER(C.c_int32), C.c_int, C.POINTER(C.c_int64)]; L.xs_update.restype = C.c_int
L.xs_audit_verify.argtypes = [C.c_void_p, C.c_char_p, C.c_int]; L.xs_audit_verify.restype = C.c_int
L.xs_audit_count.argtypes = [C.c_void_p]; L.xs_audit_count.restype = C.c_uint32
L.xs_audit_dropped.argtypes = [C.c_void_p]; L.xs_audit_dropped.restype = C.c_uint64
L.xs_audit_line.argtypes = [C.c_void_p, C.c_uint32, C.c_char_p, C.c_size_t]; L.xs_audit_line.restype = C.c_size_t
L.xs_core_setnorm.argtypes = [C.c_void_p, C.c_int, C.c_int32, C.c_uint32]; L.xs_core_setnorm.restype = C.c_int
L.xs_core_seed.argtypes = [C.c_void_p, C.c_int, C.c_int, C.POINTER(C.c_int32), C.POINTER(C.c_uint32), C.c_uint32, C.c_uint32, C.c_uint32]; L.xs_core_seed.restype = C.c_int
L.xs_core_dist.argtypes = [C.c_void_p, C.c_int, C.c_int, C.POINTER(C.c_int32)]; L.xs_core_dist.restype = C.c_uint64
L.xs_core_process.argtypes = [C.c_void_p, C.POINTER(C.c_int32), C.c_int, C.POINTER(C.c_int64)]; L.xs_core_process.restype = C.c_int
L.xs_core_learn.argtypes = [C.c_void_p, C.POINTER(C.c_int32)]; L.xs_core_learn.restype = C.c_int
L.xs_core_center.argtypes = [C.c_void_p, C.c_int, C.c_int, C.POINTER(C.c_int32)]; L.xs_core_center.restype = C.c_int
L.xs_core_generation.argtypes = [C.c_void_p]; L.xs_core_generation.restype = C.c_uint32
L.xs_features.argtypes = [C.POINTER(C.c_int32), C.c_uint32, C.c_int32, C.c_int, C.POINTER(C.c_int32), C.POINTER(C.c_int32), C.POINTER(C.c_int64), C.POINTER(C.c_int)]; L.xs_features.restype = C.c_int

STATUS = ["HEALTHY", "TRANSIENT", "WATCH", "WARNING", "ALARM", "DRIFT_LIMIT"]
KEY = b"sf-vibraledger-bench-key-0123456789ab"[:32]
SET = dict(warn=0, alarm=1, recover=2, watch_ratio=3, alarm_ratio=4, drift_limit=5, adapt=6, audit_every=7,
           learn_margin=100, learn_slack=101, min_quality=102, min_trust_learn=103, trust_cost=104, trust_decay=105,
           alpha=106, unk_join=107, unk_hits=108, min_trust_maturity=109)

def _i32(a): a = np.ascontiguousarray(a, dtype=np.int32); return a, a.ctypes.data_as(C.POINTER(C.c_int32))

def coeff_q22(f_hz, fs): return int(round(2 * math.cos(2 * math.pi * f_hz / fs) * (1 << 22)))

def features(x, fs_full=32767, coeffs=()):
    """x: 1-D int array (one channel window). returns (model_vector[int32], raw[int64 x9], quality)"""
    xa, xp = _i32(x); nb = len(coeffs); cf = (C.c_int32 * 4)(*([int(c) for c in coeffs] + [0] * (4 - nb)))
    vec = (C.c_int32 * 16)(); raw = (C.c_int64 * 9)(); q = C.c_int()
    k = L.xs_features(xp, len(xa), fs_full, nb, cf, vec, raw, C.byref(q))
    if k < 0: raise ValueError("feature extraction rc=%d" % k)
    return np.array(vec[:k], dtype=np.int32), np.array(raw[:], dtype=np.int64), q.value

class Monitor:
    def __init__(self, dims, classes=1, ppc=4, key=KEY):
        self.h = L.xs_new(); self.dims = dims
        assert L.xs_init(self.h, dims, classes, ppc, key, len(key)) == 0
        self.key = key; self._out = (C.c_int64 * 16)()
    def set(self, name, v): assert L.xs_set(self.h, SET[name] if isinstance(name, str) else name, int(v)) == 0
    def commission(self, feats, quals):
        f, fp = _i32(feats); q = np.ascontiguousarray(quals, dtype=np.uint16)
        rep = (C.c_int64 * 32)(); rc = L.xs_commission(self.h, fp, q.ctypes.data_as(C.POINTER(C.c_uint16)), len(f), rep)
        return rc, list(rep)
    def update(self, feat, quality):
        f, fp = _i32(feat); rc = L.xs_update(self.h, fp, int(quality), self._out)
        if rc: raise RuntimeError("xs_update rc=%d" % rc)
        o = self._out; return dict(status=o[0], cls=o[1], proto=o[2], learned=o[3], health=o[4], dev=o[5], drift=o[6], win=o[7], learn_total=o[8], gen=o[9])
    def audit(self):
        cnt = L.xs_audit_count(self.h); lines = []
        buf = C.create_string_buffer(256)
        for i in range(cnt):
            n = L.xs_audit_line(self.h, i, buf, 256); lines.append(buf.value.decode())
        return dict(count=cnt, dropped=L.xs_audit_dropped(self.h), verify=L.xs_audit_verify(self.h, self.key, len(self.key)), lines=lines)
    def __del__(self):
        try: L.xs_free(self.h)
        except Exception: pass
