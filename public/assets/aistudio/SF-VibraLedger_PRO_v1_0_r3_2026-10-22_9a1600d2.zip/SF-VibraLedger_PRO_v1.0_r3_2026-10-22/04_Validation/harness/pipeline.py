import numpy as np, math
import xs_bind as xb, vib_sim as vs

F1_NOM = 1480 / 60.0
COEFFS = [xb.coeff_q22(F1_NOM, vs.FS), xb.coeff_q22(2 * F1_NOM, vs.FS)]

def extract(x3):
    """3 channels -> (15-dim model vector, min quality, per-channel raw rms list)"""
    vecs = []; qs = []; rms = []
    for c in range(3):
        v, raw, q = xb.features(x3[c], fs_full=32767, coeffs=COEFFS)
        vecs.append(v); qs.append(q); rms.append(int(raw[1]))
    return np.concatenate(vecs).astype(np.int32), min(qs), rms

def drift_gain(t, total, pct=0.10):
    return 1.0 + pct * t / total

def make_monitor(rng, n_comm=150, params=None):
    """Commission a Monitor on n_comm healthy windows cycling through the 3 operating modes."""
    F = []; Q = []; R = []
    for i in range(n_comm):
        mode = (i // 10) % 3
        x = vs.window(rng, mode, 1.0)
        v, q, r = extract(x); F.append(v); Q.append(q); R.append(max(r))
    mon = xb.Monitor(dims=15, classes=1, ppc=4)
    for k, v in (params or {}).items(): mon.set(k, v)
    rc, rep = mon.commission(np.array(F), np.array(Q))
    return mon, rc, rep, np.array(R)
