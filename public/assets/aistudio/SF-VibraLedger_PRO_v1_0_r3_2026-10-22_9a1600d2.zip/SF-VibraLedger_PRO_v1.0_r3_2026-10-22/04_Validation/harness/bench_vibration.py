"""Simulated-vibration benchmark: SF-VibraLedger Monitor (real C library) vs two conventional baselines.
ALL DATA HERE ARE SYNTHETIC (physics-informed simulator, vib_sim.py). Nothing in this file is field evidence."""
import json, sys, time, math, zlib, numpy as np
import xs_bind as xb, vib_sim as vs, pipeline as pl

N_SEEDS = int(sys.argv[1]) if len(sys.argv) > 1 else 20
SEED0 = int(sys.argv[2]) if len(sys.argv) > 2 else 0
OUT = sys.argv[3] if len(sys.argv) > 3 else "../results/bench_vibration_results.json"
T = 1400; DRIFT = 0.06
SCEN = {
    "benign":         dict(fault=None),
    "bearing":        dict(fault="bearing",   onset=600, ramp=150),
    "imbalance":      dict(fault="imbalance", onset=600, ramp=150),
    "looseness":      dict(fault="looseness", onset=600, ramp=150),
    "imbalance_slow": dict(fault="imbalance", onset=300, ramp=1000),   # very slow onset: tests absorption by adaptation
    "sensor_dropout": dict(fault=None, glitch=(600, 640)),             # must NOT raise a machine alarm
}
METHODS = {  # name -> monitor parameter overrides
    "xsf_noadapt":   dict(adapt=0),
    "xsf_gated":     dict(),                                            # shipped defaults
    "xsf_gated_nodrift_cap": dict(drift_limit=0),
    "xsf_naive":     dict(learn_margin=0, learn_slack=0, min_trust_learn=0, trust_cost=0),   # evidence gate + trust ledger disabled
}
ALERT = (3, 4, 5)   # WARNING, ALARM, DRIFT_LIMIT

def run_seed(name, sc, seed):
    rng = np.random.default_rng([seed, zlib.crc32(name.encode())])
    mons = {}
    F = []; Q = []; R = []
    for i in range(150):                                   # identical commissioning data for every method
        x = vs.window(rng, (i // 10) % 3, 1.0); v, q, r = pl.extract(x); F.append(v); Q.append(q); R.append(max(r))
    F = np.array(F); Q = np.array(Q); R = np.array(R)
    for m, params in METHODS.items():
        mon = xb.Monitor(dims=15, classes=1, ppc=4)
        for k, v in params.items(): mon.set(k, v)
        rc, rep = mon.commission(F, Q); assert rc == 0, rc
        mons[m] = mon
    # baseline 1: single RMS alarm level (1.25 x worst commissioning RMS, 3 consecutive windows)
    rms_thr = 1.25 * R.max()
    # baseline 2: frozen single-baseline z-score detector (mode-unaware), threshold = 1.2 x max training score
    mu = np.median(F, axis=0); sg = np.maximum(1.4826 * np.median(np.abs(F - mu), axis=0), 6.0)
    z_train = np.mean(np.abs(F - mu) / sg, axis=1); z_thr = 1.2 * z_train.max()
    status = {m: [] for m in list(METHODS) + ["base_rms", "base_z"]}
    run_rms = 0; run_z = 0; mode = 0; upd_us = []; ext_us = []
    for t in range(T):
        if t % 100 == 0: mode = int(rng.integers(0, 3))
        sev = 0.0
        if sc["fault"]:
            sev = float(np.clip((t - sc["onset"]) / sc["ramp"], 0, 1))
        glitch = None
        if "glitch" in sc and sc["glitch"][0] <= t < sc["glitch"][1]: glitch = "flatline"
        x = vs.window(rng, mode, pl.drift_gain(t, T, DRIFT), sc["fault"], sev, glitch)
        t0 = time.perf_counter(); v, q, r = pl.extract(x); ext_us.append((time.perf_counter() - t0) * 1e6)
        for m, mon in mons.items():
            t0 = time.perf_counter(); o = mon.update(v, q); upd_us.append((time.perf_counter() - t0) * 1e6)
            status[m].append(o["status"] in ALERT)
        run_rms = run_rms + 1 if (max(r) > rms_thr and q >= 700) else 0; status["base_rms"].append(run_rms >= 3)
        zs = float(np.mean(np.abs(v - mu) / sg)); run_z = run_z + 1 if (zs > z_thr and q >= 700) else 0; status["base_z"].append(run_z >= 3)
    res = {}
    for m, s in status.items():
        s = np.array(s); onset = sc.get("onset", T)
        pre = s[:onset] if sc["fault"] else s
        fa_windows = float(pre.mean()); fa_any = bool(pre.any())
        det = None; sev_at = None
        if sc["fault"]:
            idx = np.where(s[onset:])[0]
            if len(idx): det = int(idx[0]); sev_at = float(np.clip(det / sc["ramp"], 0, 1))
        glitch_alert = float(s[sc["glitch"][0]:sc["glitch"][1] + 5].mean()) if "glitch" in sc else None
        res[m] = dict(fa_window_rate=fa_windows, fa_any=fa_any, latency=det, sev_at_detection=sev_at, glitch_alert_rate=glitch_alert)
    timing = dict(feature_extract_us_per_window=float(np.median(ext_us)), monitor_update_us=float(np.median(upd_us)))
    aud = mons["xsf_gated"].audit()
    return res, timing, dict(audit_entries=aud["count"], audit_verify=aud["verify"])

if __name__ == "__main__":
    allres = {}; timings = []; audits = []
    for name, sc in SCEN.items():
        allres[name] = {m: [] for m in list(METHODS) + ["base_rms", "base_z"]}
        for s in range(SEED0, SEED0 + N_SEEDS):
            r, tm, au = run_seed(name, sc, s); timings.append(tm); audits.append(au)
            for m in r: allres[name][m].append(r[m])
        print("done", name, flush=True)
    summary = {}
    for name, d in allres.items():
        summary[name] = {}
        for m, runs in d.items():
            lat = [r["latency"] for r in runs if r["latency"] is not None]; sev = [r["sev_at_detection"] for r in runs if r["sev_at_detection"] is not None]
            e = dict(runs=len(runs), false_alert_run_fraction=float(np.mean([r["fa_any"] for r in runs])),
                     false_alert_window_rate=float(np.mean([r["fa_window_rate"] for r in runs])))
            if SCEN[name]["fault"]:
                e.update(detection_rate=len(lat) / len(runs), median_latency_windows=float(np.median(lat)) if lat else None,
                         median_severity_at_detection=float(np.median(sev)) if sev else None)
            if "glitch" in SCEN[name]: e["glitch_alert_rate"] = float(np.mean([r["glitch_alert_rate"] for r in runs]))
            summary[name][m] = e
    out = dict(meta=dict(seeds=N_SEEDS, seed0=SEED0, windows=T, commissioning_windows=150, benign_gain_drift=DRIFT, window_ms=1000.0 * vs.N / vs.FS,
                         DATA_ORIGIN="SIMULATED (physics-informed synthetic vibration; not measured)"),
               timing=dict(feature_extract_us_median=float(np.median([t["feature_extract_us_per_window"] for t in timings])),
                           monitor_update_us_median=float(np.median([t["monitor_update_us"] for t in timings]))),
               audit=dict(all_verified=all(a["audit_verify"] == 0 for a in audits), entries_median=float(np.median([a["audit_entries"] for a in audits]))),
               summary=summary)
    json.dump(out, open(OUT, "w"), indent=1); print("saved", OUT)
