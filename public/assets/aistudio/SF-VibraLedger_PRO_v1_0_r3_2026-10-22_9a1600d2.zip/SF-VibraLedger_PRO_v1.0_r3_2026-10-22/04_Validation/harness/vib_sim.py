"""Physics-informed SYNTHETIC vibration simulator (3 accelerometer channels) - used ONLY to exercise the pipeline.
It is NOT measured machine data. Every result derived from it must be labelled 'simulated'."""
import numpy as np, math

FS = 10240; N = 2048
MODES = [dict(rpm=1485, gain=1.00), dict(rpm=1478, gain=1.25), dict(rpm=1470, gain=1.60)]  # three load levels
CH_MIX = np.array([[1.0, 0.9, 0.7], [0.8, 1.0, 0.6], [0.6, 0.7, 1.0]])   # per-channel weight of the 3 harmonics
H_AMP = np.array([1.0, 0.30, 0.15])          # relative 1x,2x,3x amplitudes (healthy)
COUNTS = 3500.0                              # ADC counts per unit amplitude (16-bit, +-32767 full scale)
T = np.arange(N) / FS

def window(rng, mode, drift_gain=1.0, fault=None, sev=0.0, glitch=None):
    m = MODES[mode]; f1 = m["rpm"] / 60.0
    g = m["gain"] * drift_gain * math.exp(rng.normal(0, 0.02))            # window-to-window process variation
    x = np.zeros((3, N))
    a = H_AMP.copy()
    sub = 0.0
    if fault == "imbalance": a[0] *= (1.0 + 1.5 * sev)
    if fault == "looseness": a[1:] *= (1.0 + 3.0 * sev); sub = 0.30 * sev
    for c in range(3):
        ph = rng.uniform(0, 2 * math.pi, 4)
        for h in range(3):
            x[c] += g * CH_MIX[c, h] * a[h] * np.sin(2 * math.pi * f1 * (h + 1) * T + ph[h])
        if sub: x[c] += g * sub * CH_MIX[c, 0] * np.sin(2 * math.pi * f1 * 0.5 * T + ph[3])
        x[c] += rng.normal(0, 0.35 * g ** 0.5, N)                          # broadband noise (grows mildly with load)
    if fault == "bearing" and sev > 0:
        bpfo = 3.58 * f1; period = FS / bpfo; amp = 2.6 * sev * g
        t0 = rng.uniform(0, period)
        k = np.arange(N)
        while t0 < N:
            i0 = int(t0 + rng.normal(0, 0.008 * period)); t0 += period
            if i0 < 0 or i0 >= N: continue
            n = np.arange(0, min(N - i0, 160)); ring = np.exp(-n / (0.0015 * FS)) * np.sin(2 * math.pi * 3100.0 * n / FS)
            for c in range(3): x[c, i0:i0 + len(n)] += amp * CH_MIX[c, 0] * ring * rng.uniform(0.85, 1.15)
    x = x * COUNTS
    if glitch == "flatline": x[1, :] = 0.0
    if glitch == "dropout": x[1, 300:1100] = x[1, 300]
    return np.clip(np.round(x), -32767, 32767).astype(np.int32)
