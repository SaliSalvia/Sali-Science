"""Public-data experiments with the REAL compiled SF-VibraLedger core (through libsfvibraledger.so).
Datasets: scikit-learn bundled wine / breast_cancer / digits (real measurements, NOT industrial data).
Drift and poisoning are injected on top of the real features and are therefore labelled SEMI-SYNTHETIC."""
import json, sys, numpy as np, ctypes as C
from sklearn.datasets import load_wine, load_breast_cancer, load_digits
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.neighbors import KNeighborsClassifier
import xs_bind as xb

N_SEEDS = int(sys.argv[1]) if len(sys.argv) > 1 else 20
OUT = sys.argv[2] if len(sys.argv) > 2 else "../results/real_data_results.json"
Q = 1024
VARIANTS = {
    "frozen":        None,                                                   # seeded, never learns
    "naive":         dict(learn_margin=0, learn_slack=0, min_trust_learn=0, trust_cost=0),
    "evidence_only": dict(min_trust_learn=0, trust_cost=0),                  # gate on, trust ledger off
    "trust_only":    dict(learn_margin=0, learn_slack=0),                    # trust ledger on, evidence off
    "gated_trust":   dict(),                                                 # shipped defaults
}

def load(name):
    if name == "wine": d = load_wine()
    elif name == "breast_cancer": d = load_breast_cancer()
    else: d = load_digits()
    X, y = d.data.astype(float), d.target.astype(int)
    if name == "digits8": m = y < 8; X, y = X[m], y[m]          # core capacity: 8 classes
    return X, y

def build(X, y, seed):
    ss = StratifiedShuffleSplit(n_splits=1, train_size=0.15, random_state=seed); si, ri = next(ss.split(X, y))
    ss2 = StratifiedShuffleSplit(n_splits=1, train_size=0.65, random_state=seed); sti, tei = next(ss2.split(X[ri], y[ri]))
    sc = StandardScaler().fit(X[si]); Z = lambda A: sc.transform(A)
    Zs = Z(X[si]); dims = X.shape[1]
    if dims > 16:
        pca = PCA(n_components=16, random_state=0).fit(Zs); T = lambda A: pca.transform(A)
    else: T = lambda A: A
    a = T(Zs); s0 = a[:, 0].std()
    conv = lambda A: np.clip(np.round(T(Z(A)) / s0 * Q), -2e9, 2e9).astype(np.int32)
    return conv(X[si]), y[si], conv(X[ri][sti]), y[ri][sti], conv(X[ri][tei]), y[ri][tei], conv

def make_core(Xs, ys, ncls, params):
    dims = Xs.shape[1]; mon = xb.Monitor(dims=dims, classes=ncls, ppc=1)
    for d in range(dims): xb.L.xs_core_setnorm(mon.h, d, 0, Q)
    if params:
        for k, v in params.items(): mon.set(k, v)
    for c in range(ncls):
        R = Xs[ys == c].astype(float); ctr = R.mean(axis=0); mad = np.maximum(np.abs(R - ctr).mean(axis=0), 256.0)
        ci = np.round(ctr).astype(np.int32); si = np.round(mad).astype(np.uint32)
        xb.L.xs_core_seed(mon.h, c, 0, ci.ctypes.data_as(C.POINTER(C.c_int32)), si.ctypes.data_as(C.POINTER(C.c_uint32)), 1, 0, len(R))
        d = np.array([np.sqrt(float(xb.L.xs_core_dist(mon.h, c, 0, r.astype(np.int32).ctypes.data_as(C.POINTER(C.c_int32))))) for r in R])
        rm = d.mean() * 1.10; rmad = np.abs(d - d.mean()).mean() * 1.10
        xb.L.xs_core_seed(mon.h, c, 0, ci.ctypes.data_as(C.POINTER(C.c_int32)), si.ctypes.data_as(C.POINTER(C.c_uint32)), max(1, int(round(rm))), int(round(rmad)), len(R))
    return mon

def process(mon, x, learn):
    xa = np.ascontiguousarray(x, dtype=np.int32); out = (C.c_int64 * 16)()
    xb.L.xs_core_process(mon.h, xa.ctypes.data_as(C.POINTER(C.c_int32)), 1024, out)
    pred = int(out[1]) if out[0] == 0 else 255
    upd = 0
    if learn and out[3]: upd = 1 if xb.L.xs_core_learn(mon.h, xa.ctypes.data_as(C.POINTER(C.c_int32))) == 0 else 0
    return pred, upd

def evaluate(mon, Xt, yt):
    p = np.array([process(mon, x, False)[0] for x in Xt]); acc = float(np.mean(p == yt)); ans = p != 255
    return acc, float(ans.mean()), float(np.mean(p[ans] == yt[ans])) if ans.any() else float("nan")

def centers(mon, ncls, dims):
    buf = (C.c_int32 * 16)(); out = []
    for c in range(ncls): xb.L.xs_core_center(mon.h, c, 0, buf); out.append(np.array(buf[:dims], dtype=float))
    return np.array(out)

def static_experiment(name, seeds):
    X, y = load(name); ncls = int(y.max()) + 1; res = {v: dict(test_acc=[], answered=[], acc_on_answered=[], updates=[]) for v in VARIANTS}; knn = []
    for s in range(seeds):
        Xs, ys, Xa, ya, Xt, yt, _ = build(X, y, s); rng = np.random.default_rng(s)
        knn.append(KNeighborsClassifier(n_neighbors=5).fit(Xs.astype(float), ys).score(Xt.astype(float), yt))
        for v, p in VARIANTS.items():
            mon = make_core(Xs, ys, ncls, p); upd = 0
            for i in rng.permutation(len(Xa)): upd += process(mon, Xa[i], v != "frozen")[1]
            a, ans, aa = evaluate(mon, Xt, yt)
            res[v]["test_acc"].append(a); res[v]["answered"].append(ans); res[v]["acc_on_answered"].append(aa); res[v]["updates"].append(upd)
    return dict(dataset=name, classes=ncls, seeds=seeds, knn5_test_acc=[float(np.mean(knn)), float(np.std(knn))],
                variants={v: {k: [float(np.nanmean(a)), float(np.nanstd(a))] for k, a in r.items()} for v, r in res.items()})

def drift_poison_experiment(name, seeds, drift_sigma=1.5, poison_rate=0.20, lam=0.7):
    X, y = load(name); ncls = int(y.max()) + 1
    res = {v: dict(final_acc=[], acc_on_answered=[], answered=[], updates=[], poison_updates=[], poison_share=[], displacement=[]) for v in VARIANTS}; knn_final = []; base_disp = []
    for s in range(seeds):
        Xs, ys, Xa, ya, Xt, yt, _ = build(X, y, s); rng = np.random.default_rng(10_000 + s); dims = Xs.shape[1]
        u = rng.normal(size=dims); u /= np.linalg.norm(u)
        order = rng.permutation(len(Xa)); T = len(order)
        # stream: real feature vectors + linearly growing covariate drift + boundary-pushing poison samples
        stream = []
        for t, i in enumerate(order):
            off = (t / max(1, T - 1)) * drift_sigma * Q * u
            if rng.random() < poison_rate:
                j = rng.choice(np.where(ya != ya[i])[0]); x = lam * Xa[i].astype(float) + (1 - lam) * Xa[j].astype(float) + off
                stream.append((np.round(x).astype(np.int32), int(ya[i]), True))
            else: stream.append((np.round(Xa[i].astype(float) + off).astype(np.int32), int(ya[i]), False))
        tail0 = int(0.7 * T)
        knn = KNeighborsClassifier(n_neighbors=5).fit(Xs.astype(float), ys)
        clean_tail = [(x, l) for (x, l, p) in stream[tail0:] if not p]
        knn_final.append(float(np.mean(knn.predict(np.array([c[0] for c in clean_tail], dtype=float)) == np.array([c[1] for c in clean_tail]))))
        for v, p in VARIANTS.items():
            mon = make_core(Xs, ys, ncls, p); c0 = centers(mon, ncls, dims); upd = pu = 0; correct = tot = ans = ansok = 0
            for t, (x, lab, pois) in enumerate(stream):
                pred, du = process(mon, x, v != "frozen"); upd += du; pu += du if pois else 0
                if t >= tail0 and not pois:
                    tot += 1; correct += (pred == lab)
                    if pred != 255: ans += 1; ansok += (pred == lab)
            c1 = centers(mon, ncls, dims)
            res[v]["final_acc"].append(correct / max(1, tot)); res[v]["answered"].append(ans / max(1, tot)); res[v]["acc_on_answered"].append(ansok / ans if ans else 0.0); res[v]["updates"].append(upd); res[v]["poison_updates"].append(pu)
            res[v]["poison_share"].append(pu / upd if upd else 0.0)
            res[v]["displacement"].append(float(np.mean(np.linalg.norm(c1 - c0, axis=1)) / Q))
    return dict(dataset=name, seeds=seeds, drift_total_sigma=drift_sigma, poison_rate=poison_rate, poison_mix_lambda=lam,
                knn5_frozen_acc_last30pct=[float(np.mean(knn_final)), float(np.std(knn_final))],
                variants={v: {k: [float(np.mean(a)), float(np.std(a))] for k, a in r.items()} for v, r in res.items()})

if __name__ == "__main__":
    out = dict(meta=dict(seeds=N_SEEDS, DATA_ORIGIN="REAL public datasets (scikit-learn bundled), non-industrial; drift/poison injected = SEMI-SYNTHETIC"), static={}, drift_poison={})
    for name in ("wine", "breast_cancer", "digits8"):
        out["static"][name] = static_experiment(name, N_SEEDS); print("static", name, flush=True)
        out["drift_poison"][name] = drift_poison_experiment(name, N_SEEDS); print("drift+poison", name, flush=True)
    json.dump(out, open(OUT, "w"), indent=1); print("saved", OUT)
