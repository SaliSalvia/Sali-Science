"""Same seeds must give byte-identical benchmark results (timing fields excluded)."""
import json, subprocess, sys, hashlib, os
here = os.path.dirname(os.path.abspath(__file__)); hs = []
for i in range(2):
    out = "/tmp/determinism_%d.json" % i
    subprocess.check_call([sys.executable, "bench_vibration.py", "2", "500", out], cwd=here, stdout=subprocess.DEVNULL)
    d = json.load(open(out)); d.pop("timing", None); hs.append(hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest())
print("run A sha256:", hs[0]); print("run B sha256:", hs[1])
if hs[0] != hs[1]: print("DETERMINISM FAIL"); sys.exit(1)
print("DETERMINISM PASS")
