---
title: "On-target validation record - Cortex-M3 (FIT IoT-LAB m3)"
subtitle: "Package revision r3, 2026-10-22 - read with KNOWN_LIMITATIONS.md"
---

## 1. Summary

The embedded subset of SF-VibraLedger (Core, Wire, AuditLog, Features, Monitor - the shipped sources, **unmodified**) was built with arm-none-eabi-gcc and run on one real microcontroller. On the 210-window **simulated** demo recording it reproduced the host's results **bit-for-bit**: the status of every window, the hash of every output field, the integer feature extraction from raw samples, the HMAC-SHA256 audit chain head, and the rejection of tampered, wrong-key and truncated model blobs. Timing was measured with the core cycle counter after its clock had been confirmed against an independent timer.

| Item | Result |
|---|---|
| Platform | FIT IoT-LAB Grenoble, `m3` open node (STM32F103, Cortex-M3, 72 MHz; board documentation: 512 KiB flash, 64 KiB RAM) |
| Toolchain / OS | arm-none-eabi-gcc 9.3.1 20200408 (GNU Arm Embedded Toolchain 9-2020-q2-update); RIOT 2026.10-devel-726-g5732291def (build used RIOT's default flags) |
| Firmware under test | `sfvl_hwtest` (this package, `hardware_m3/sfvl_hwtest_v5_3`); ELF sha256 `88bd7416a0d9a32e344a80969761ad8e939e995f9f5e5b357103f4ae50721e4d`; source hash `782db815e139620606476f28e60489bdae8a3949d8019100f7c249ad10023a38` |
| Correctness | 28 of 28 on-device checks PASS (5 hardware captures: 5 of 5) |
| Timing | `TIMING_VALID: yes`; core clock measured 72.11 MHz vs nominal 72.00 MHz |
| Build repeatability | two clean builds in the same environment: byte-identical, and identical to the ELF that ran |

## 2. Claim boundary (read first)

**What this shows:** on this Cortex-M3 the integer-only core gives the same decisions, features and audit chain as on x86-64, within the test described here, and costs the measured cycles.

**What it does not show:**

* Real machine data. The input was the shipped **simulated** 3-channel recording; no sensor or ADC was involved. Raw samples for 6 windows (all four statuses) and pre-extracted features for 210 windows were embedded in the firmware.
* Any other MCU, clock, compiler or optimisation level; behaviour with interrupts masked or under a loaded RTOS.
* Whole-system latency: only single functions were timed (see section 5).
* Power loss during model activation, key storage/provisioning, long-duration soak, EMC/temperature.
* A formal reproducible-build proof (section 7).

Allowed wording example: *"MEASURED ON TARGET (STM32F103 / Cortex-M3, 72 MHz, FIT IoT-LAB m3): SFVLM_Update 597 us median (1,221 us with an audit entry); SFVLF_Extract 10.9 ms per 2048-sample channel window."* Do not drop the platform name.

## 3. Method

1. **Host reference** (`hardware_m3/sfvl_hwtest_v5_3/host_reference/export_tool.c`): commissions the model exactly like `sfvibraledger_eval` (commissioning uses libm/doubles and is host-only by design), serialises it with `SFVL_WireSerialize`, replays the 210 monitoring windows on a monitor loaded only from that blob, and emits a C header with: the authenticated wire blob (5558 B), pre-extracted feature vectors and qualities, the expected status of every window, expected counts and first-alert window, a hash over all output fields, the 4 audit export lines and the 32-byte audit chain head, and 6 windows of raw int16 samples (3 channels x 2048). The header is reproducible byte-for-byte from the shipped package.
2. **Firmware** (`main.c`, RIOT application): loads the blob (`SFVL_WireStageToStore`), arms the monitor, replays the windows through the real `SFVLM_Update`, runs the real `SFVLF_Extract`/`SFVLF_ToModelVector` on the raw samples, and compares everything with the host values. It prints `CHECK <name>: PASS|FAIL` lines and a declared total.
3. **Runner** (`run_hwtest.sh`): forced rebuild, reserve/reuse an `m3` node, flash with `iotlab-node --flash`, open the serial port first and reset afterwards (the program runs once and exits, so a late `nc` misses it), judge the last run block, record hashes. `reanalyze.sh` re-derives the verdict from saved logs; `repro_check.sh` builds twice from clean.

## 4. Correctness results (28 checks)

Embedded data intact (hashes of feature, quality and raw-sample tables) - wire format: pristine blob accepted; payload bit flip, tag bit flip, wrong key and 1-byte truncation rejected (status codes identical to the host) - integer feature extraction from raw samples bit-identical to the host for 6 windows x 3 channels (features and quality) - three independent replays from a fresh load: status sequence, counts (HEALTHY 103, WATCH 13, WARNING 6, ALARM 88), first alert (index 116 of the monitoring stream = window 206 of the recording), and the hash of every output field (`0x14d1c1a2`) identical to the host - audit chain: count, verification, wrong-key rejection, tampered entry detected, exported lines and chain head identical to the host - learn counters identical - determinism across runs - stack headroom >= 25 %.

## 5. Timing (valid; conditions matter)

Counter: Cortex-M3 DWT `CYCCNT`. At start the firmware checks the counter (read overhead 1 cycle; a busy loop advances it) and measures the clock against RIOT's `ztimer_msec`: 3 x 100 ms = 7,211,123 / 7,211,125 / 7,211,328 cycles, i.e. 72.11 MHz against the nominal 72.00 MHz (0.15 %, consistent with the sleep wake-up latency). The check is only as independent as the hardware timer behind `ztimer_msec`. Microseconds below use 72 MHz.

| Function (calls) | median cycles | median time | min / p95 / max time |
|---|---|---|---|
| `SFVLM_Update`, no audit entry (618) | 43,059 | 597 us | 468 / 800 / 808 us |
| `SFVLM_Update`, audit entry appended - HMAC-SHA256 (12) | 88,071 | 1,221 us | 1,114 / 1,339 / 1,339 us |
| `SFVLF_Extract`, 1 channel x 2048 samples (18) | 789,273 | 10,945 us | 10,872 / 11,010 / 11,010 us |
| `SFVL_WireStageToStore`, 5558-byte blob (3) | 911,757 | 12,643 us | all equal |

Typical CPU per 200 ms window (3 x Extract + Update, medians): 33.4 ms = **16.7 % of one core**; `SFVLF_Extract` is more than 98 % of it. Five hardware captures gave identical medians in all four rows. Caveats: the counter-read overhead is included; RTOS-tick interrupts are not masked, so p95/max can contain them (min and median are the stable figures); `SFVLM_Update` time depends on the data path (min 468 us vs max 808 us without an audit entry); `WireStageToStore` has only 3 samples; functions were timed one by one, not end to end.

## 6. Memory and stack

`sizeof` on ARM: `SFVLM_Monitor` 8104 B (8112 B on x86-64), `SFVL_WireStore` 11240 B, `SFVL_Model` 5616 B, `SFVLAL_Log` 2128 B. The complete test firmware (RIOT + library + 72 KB of embedded raw samples + tables) is 121,352 B of flash and 46,216 B of static RAM (including a 12 KB main stack); these are **not** product footprint numbers.

**Stack:** `SFVL_WireStageToStore` keeps a whole `SFVL_Model` (~5.6 KB) on the stack. The first silicon run HardFaulted at the first successful stage with RIOT's default ~2 KB main stack (rejected blobs return before touching that frame, so the first four negative tests passed). With a 12,288 B stack the worst observed use was 7,108 B (free minimum 5,180 B), measured by scanning RIOT's stack paint. Integrators should budget **>= 8 KB** for the calling thread. Staging directly into the inactive slot would remove the requirement; the shipped code was deliberately left unchanged.

## 7. Build repeatability

`repro_check.sh` deletes `bin/<board>` (RIOT objects included), builds twice with identical arguments and compares. (a) Release firmware (`HWT_CYCLES=0 HWT_STACKINFO=1`): A = B = original release ELF `1c612565...8171`. (b) Firmware under test (default arguments): A = B = `88bd7416...1e4d`, flashable image `bc7f665f...60e1`. Limits: same machine, paths and toolchain; each build printed 22-24 clock-skew warnings (NFS server vs frontend clock) - with a full clean and identical results there is no sign of an incomplete build, but it is not a formal reproducible-build proof.

## 8. Documents NOT updated in r2/r3 (decide before publishing)

Edited in r2 (r3 only corrects the run history and records the evidence archive): `KNOWN_LIMITATIONS.md` (both copies), `README_EN/FA.md`, `Integration_Guide.md`, `MANIFEST.md`. The following still say that nothing was run on a microcontroller (they understate, they do not overstate) and were left untouched because they are narrative reports, patent documents or flattened marketing pieces:
`04_Validation/Test_Evidence_Report_EN` and `Test_Evidence_Summary_FA` (physical machines / microcontroller targets "not covered"; timing "host numbers"), `02_Paper_Q1/Manuscript_EN` (states no microcontroller measurements; a short on-target section could be added), `00_START_HERE/Decision_Report_FA`, `05_Marketing/OnePager_EN/FA` and `Poster_EN/FA` (status box: "not yet validated ... on a microcontroller"; roadmap: "microcontroller timing"). Patent texts mention microcontrollers only as embodiments. Prefer to regenerate them from their sources when you next edit them.

## 9. History of on-target runs (including failures)

| Date | Experiment / node | Firmware (ELF sha256) | Outcome |
|---|---|---|---|
| 2026-10-11 09:38 and 09:39 | 453341 / m3-10 (two runs) | v2 (`366ea6d7...`, RIOT's default main stack) | 6 checks passed (2 data-integrity + 4 wire rejections), then **HardFault** at the first successful `SFVL_WireStageToStore` (stack overflow); output ended at "Context before hardfault" |
| 2026-10-11 20:46 | 453444 / m3-7 | v3 (`d490c9e1...`, 12 KB stack) | 23/23 PASS (no timing, no stack introspection in that build) |
| 2026-10-11 21:20 | 453451 / m3-10 | release firmware (`1c612565...`, 12 KB stack, no cycle counter in this build) | 25/25 PASS; stack used_max 6,992 B of 12,288 B |
| 2026-10-17 12:48 | 455502 / m3-100 | v5.1 (`92ecaa4d...`) | 26/26 PASS; `TIMING_VALID: partial` (the full build failed: `thread_measure_stack_free` pointer-type error, so the ztimer clock check was not built) |
| 2026-10-17 21:38 | 455517 / m3-100 | v5.2 (`88bd7416...`) | **28/28 PASS, `TIMING_VALID: yes`**; 5 captures identical |

Other findings during the work: the first runner versions missed the one-shot output (serial attached after the program had finished); the IoT-LAB serial forwarder serves one client at a time and needs seconds to release the port; the v5.2 runner mis-counted checks when the capture began with the tail of the post-flash run (fixed in v5.3, which judges only the last run block).

## 10. Repeating the test

See `hardware_m3/sfvl_hwtest_v5_3/README.md`. The raw logs and ELFs are in the evidence archive `evidence_20261022.tar.gz` (SHA-256 `0cbb64cc7815bfce28d149e08199720a7101741dac099c322c1e94df009cd574`, kept outside this package); its identity, contents, run list and the cross-checks made are in `hardware_m3/EVIDENCE_ARCHIVE_RECORD_2026-10-22.md`, per-file hashes in `hardware_m3/EVIDENCE_ARCHIVE_MANIFEST_20261022.txt`. Transcribed excerpts: `hardware_m3/evidence_excerpts_2026-10-18.txt`. Packing helper for future runs: `hardware_m3/collect_evidence.sh`.
