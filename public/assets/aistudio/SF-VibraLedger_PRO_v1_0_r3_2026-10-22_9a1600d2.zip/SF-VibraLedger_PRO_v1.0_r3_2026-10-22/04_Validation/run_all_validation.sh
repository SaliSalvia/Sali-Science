#!/usr/bin/env bash
# SF-VibraLedger PRO - one-file validation runner.
#   ./run_all_validation.sh            -> DRY RUN: prints what would be built/run (default, changes nothing)
#   ./run_all_validation.sh --apply    -> builds in ./04_Validation/build, runs everything, writes ./04_Validation/logs and ./04_Validation/results
#   options: --apply --seeds N (benchmark seeds, default 20)   --skip-python (C tests only)
# Requirements: gcc (C11), python3 with numpy + scikit-learn. No network needed. Exit code 0 only if EVERY step passes.
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; SRC="$ROOT/07_Source"; VAL="$ROOT/04_Validation"; LOG="$VAL/logs"; BLD="$VAL/build"
APPLY=0; SEEDS=20; PY=1
while [ $# -gt 0 ]; do case "$1" in --apply) APPLY=1;; --seeds) shift; SEEDS="$1";; --skip-python) PY=0;; *) echo "unknown option $1"; exit 2;; esac; shift; done
CF="-std=c11 -Wall -Wextra -Werror -O2"; INC="-I$SRC/Core -I$SRC/Audit -I$SRC/Features -I$SRC/Monitor -I$SRC/Host -I$SRC/Tests"
SAN="-std=c11 -Wall -Wextra -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all"
CORE="$SRC/Core/SFVibraLedger_Core.c"; WIRE="$SRC/Core/SFVibraLedger_Wire.c"; XCAL="$SRC/Core/SFVibraLedger_XCal.c"; AUD="$SRC/Audit/SFVibraLedger_AuditLog.c"
FEAT="$SRC/Features/SFVibraLedger_Features.c"; MON="$SRC/Monitor/SFVibraLedger_Monitor.c"; COM="$SRC/Host/SFVibraLedger_Commission.c"
# name | sources needed
TESTS=(
 "core_wire_xcal|$CORE $WIRE $XCAL" "core_strict|$CORE $WIRE" "generation_coupling|$CORE $WIRE" "security_audit|$CORE $WIRE" "promote_consistency|$CORE" "boundary_stability|$CORE"
 "auditlog|$AUD" "features|$FEAT" "monitor|$CORE $AUD $MON $COM" "wire_authfuzz|$CORE $WIRE" "wire_fuzz|$CORE $WIRE" "soak_core|$CORE"
 "fuzz_soak|$CORE $AUD $FEAT $MON $COM" )
if [ $APPLY -eq 0 ]; then
  echo "DRY RUN (nothing executed). With --apply this script will:"
  echo "  1. build libsfvibraledger.so and sfvibraledger_eval (strict: -Wall -Wextra -Werror)"
  for t in "${TESTS[@]}"; do echo "  2. compile+run test_${t%%|*}.c natively AND under AddressSanitizer+UBSan"; done
  echo "  3. C99 -Wpedantic compile of the embedded subset + undefined-symbol audit + size report"
  [ $PY -eq 1 ] && echo "  4. python: features-vs-numpy, determinism, simulated-vibration benchmark ($SEEDS seeds), public-data experiments ($SEEDS seeds)"
  echo "  5. write logs to $LOG, results to $VAL/results, SHA-256 of every result file"; exit 0
fi
mkdir -p "$LOG" "$BLD" "$VAL/results"; : > "$LOG/SUMMARY.txt"; FAIL=0
say() { echo "$@" | tee -a "$LOG/SUMMARY.txt"; }
step() { # name, command...
  local n="$1"; shift; if "$@" > "$LOG/$n.log" 2>&1; then say "PASS  $n"; else say "FAIL  $n  (see logs/$n.log)"; FAIL=1; fi; }
say "SF-VibraLedger PRO validation  $(date -u +%Y-%m-%dT%H:%M:%SZ)"; say "host: $(uname -srm) | $(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2 | xargs) | $(gcc --version | head -1)"
step build_lib_and_cli make -C "$SRC" all
for t in "${TESTS[@]}"; do n="${t%%|*}"; s="${t#*|}"
  step "native_$n"  bash -c "gcc $CF $INC $SRC/Tests/test_$n.c $s -o $BLD/n_$n -lm && $BLD/n_$n"
  step "sanitized_$n" bash -c "gcc $SAN $INC $SRC/Tests/test_$n.c $s -o $BLD/s_$n -lm && $BLD/s_$n"
done
step embedded_c99_pedantic bash -c "for f in $CORE $WIRE $XCAL $AUD $FEAT $MON; do gcc -std=c99 -Wall -Wextra -Wpedantic -Werror -Os $INC -c \$f -o $BLD/e_\$(basename \$f .c).o || exit 1; done; nm -u $BLD/e_*.o | grep -v ':' | sort -u > $LOG/embedded_undefined_symbols.txt; size $BLD/e_*.o | tee $LOG/embedded_size_x86_64_Os.txt"
if [ $PY -eq 1 ]; then
  cd "$VAL/harness" || exit 2
  step py_features_vs_numpy python3 check_features_vs_numpy.py
  step py_determinism python3 check_determinism.py
  step py_vibration_benchmark python3 bench_vibration.py "$SEEDS" 0 ../results/bench_vibration_results.json
  step py_public_data_experiments python3 real_data_experiments.py "$SEEDS" ../results/real_data_results.json
  python3 - > "$LOG/struct_sizes.txt" <<'PYEOF'
import xs_bind as xb; print("sizeof(SFVL_Model)=%d bytes" % xb.L.xs_sizeof_model()); print("sizeof(SFVLM_Monitor incl. model + audit log + supervision)=%d bytes" % xb.L.xs_sizeof_monitor())
PYEOF
fi
cd "$VAL/results" && sha256sum *.json > SHA256SUMS.txt 2>/dev/null; say ""
if [ $FAIL -eq 0 ]; then say "ALL_VALIDATION_STEPS_PASSED"; exit 0; else say "SOME_STEPS_FAILED"; exit 1; fi
