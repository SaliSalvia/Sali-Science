---
title: "Core Fix Report (BUG-1, BUG-2) and Design Changes"
subtitle: "Found during deep review and benchmarking of SF-VibraLedger FINAL MASTER; fixed in SF-VibraLedger PRO v1.0"
---

## BUG-1 — promoted unknown-state prototype was too tight

**Symptom.** After an operator promoted a matured unknown-state candidate into a class, the new prototype rejected most fresh samples of the very cluster that formed it.

**Cause.** The unknown pool joins samples with per-dimension scale 512, but `SFVL_PromoteUnknown` created the prototype with scale 256 (same threshold): the prototype's metric was 4× stricter than the criterion that formed the cluster.

**Reproduction (`07_Source/Tests/repro_promote_scale.c`, 4 dimensions, 1000 fresh samples, same seed).**

| cluster spread (normalised units) | acceptance BEFORE | acceptance AFTER |
|---|---|---|
| 0.1 | 99.4 % | 100 % |
| 0.3 | **17.2 %** | **81.2 %** |
| 0.5 | 1.2 % | 17.5 % (limited by the join threshold itself — a documented tuning parameter, set by the Monitor proportional to D) |

**Fix.** One shared constant `SFVL_UNKNOWN_SCALE = 512` used by joining and by promotion. **Regression test** `test_promote_consistency.c` (requires ≥ 98 % at 0.1 and ≥ 70 % at 0.3); on the original behaviour it fails (16.3 %).

## BUG-2 — radius statistic measured after the centre had moved

**Symptom.** In the simulated-vibration benchmark, benign runs (3 operating modes, 6 % gain drift) produced false WARNING episodes.

**Cause.** `SFVL_FeedbackLearnGated` updated the prototype centre toward the sample and then measured the sample's distance to the *updated* prototype for the radius statistics. That distance is smaller than what a fresh sample will see, so the radius mean/MAD — and hence the acceptance threshold — were biased low by roughly one learning-rate step per update.

**Fix.** Use the pre-update distance `now_d2` (already computed for the slack check).

**Evidence (controlled A/B, identical code except this line, 30 development seeds 900–929, 1400 windows each, benign scenario).**

| variant | runs with ≥ 1 false alert | false-alert windows |
|---|---|---|
| radius after update (original) | 8 / 30 | 93 |
| radius before update (fixed) | 2 / 30 | 44 |

The fix **reduces, not eliminates**, false alerts. The remaining episodes are stale prototypes of operating modes not visited for a long time while a benign gain drift accumulates (see `KNOWN_LIMITATIONS.md`). The isolated stationary-Gaussian test (`test_boundary_stability.c`) does *not* discriminate the two variants (radius ratio 0.963 vs 0.967) and is kept only as a stability test.

**Honesty note on method.** The dev seeds (900+) were used to diagnose and to choose between variants; the reported benchmark uses different seeds (0–19), and no benchmark parameter was tuned on them.

## Design changes (not bugs)

* Prototype scales seeded by commissioning are the **mean absolute deviation** of the members (the statistic the online update tracks); seeding with the standard deviation made the metric jump (≈ 1.25×) at the first learning update.
* `SFVL_SeedPrototypeFull` (explicit per-dimension scales and radius statistics) added for host commissioning.
* Base learning rate is left at 102/1024: raising it (256, 400) made the per-dimension scale collapse and the boundary unstable in the drift scenario.
* Wire format unchanged (still 5558 bytes for the 8-dimension reference example); existing wire tests pass unchanged.
