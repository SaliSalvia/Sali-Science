#!/usr/bin/env python3
"""Convert a MATLAB .mat vibration recording (e.g. CWRU bearing data) to the CSV format used by sfvibraledger_eval.
usage: mat_to_csv.py file.mat out.csv [--fs 12000]
Channels are the arrays whose names end in _DE_time / _FE_time / _BA_time; if none exist, every 1-D array with > 1000 samples."""
import sys, numpy as np
from scipy.io import loadmat
def channels(path):
    m = loadmat(path); out = {}
    for k, v in m.items():
        if k.startswith("__"): continue
        a = np.asarray(v).squeeze()
        if a.ndim == 1 and a.size > 1000 and any(k.endswith(s) for s in ("_DE_time", "_FE_time", "_BA_time")): out[k] = a.astype(float)
    if not out:
        for k, v in m.items():
            a = np.asarray(v).squeeze() if not k.startswith("__") else None
            if a is not None and a.ndim == 1 and a.size > 1000 and a.dtype.kind in "fiu": out[k] = a.astype(float)
    return out
if __name__ == "__main__":
    if len(sys.argv) < 3: print(__doc__); sys.exit(2)
    fs = float(sys.argv[sys.argv.index("--fs") + 1]) if "--fs" in sys.argv else 12000.0
    ch = channels(sys.argv[1]); assert ch, "no vibration channel found"
    n = min(len(v) for v in ch.values()); names = sorted(ch)
    with open(sys.argv[2], "w") as f:
        f.write("time_s," + ",".join(names) + "\n")
        for i in range(n): f.write("%.6f,%s\n" % (i / fs, ",".join("%.6f" % ch[k][i] for k in names)))
    print("wrote %s: %d rows, channels %s (scale factors are NOT applied: sfvibraledger works on ratios)" % (sys.argv[2], n, names))
