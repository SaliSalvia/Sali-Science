#!/usr/bin/env python3
"""REAL-DATA VALIDATION HARNESS for public bearing recordings (CWRU-style .mat files). NOT RUN by the package author on real
data (no network in the build environment) - it is shipped so that the real-data evidence gap can be closed on your machine.

usage:
  cwru_experiment.py --normal 97.mat 98.mat 99.mat 100.mat --fault 105.mat [--fault 118.mat ...] [--fs 12000] [--window 2048]
Each --normal file is one operating mode (e.g. motor load 0..3 hp); the first 60% of its windows commission the model (time order),
the last 40% measure false alerts; each --fault file is then monitored after that healthy context.
Prints, per fault file: false-alert rate on held-out normal windows, alert rate on fault windows, latency (windows) to first alert,
and the same for a simple RMS alarm-level baseline. Uses the same compiled C library as every other experiment."""
import sys, argparse, json, numpy as np
sys.path.insert(0, __file__.rsplit("/", 1)[0] + "/../harness")
import xs_bind as xb
from mat_to_csv import channels

def windows(x, n): return [np.round(x[i:i + n]).astype(np.int64) for i in range(0, len(x) - n + 1, n)]
def feat(w, fs_full):
    v, raw, q = xb.features(w, fs_full=fs_full, coeffs=[]); return v, q, int(raw[1])

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--normal", nargs="+", required=True); ap.add_argument("--fault", nargs="+", required=True, action="extend")
    ap.add_argument("--fs", type=float, default=12000.0); ap.add_argument("--window", type=int, default=2048); ap.add_argument("--channel", default="DE"); a = ap.parse_args()
    def load(path):
        ch = channels(path); key = [k for k in ch if k.endswith("_%s_time" % a.channel)] or list(ch)
        x = ch[key[0]]; x = x - x.mean(); s = 20000.0 / max(1.0, np.abs(x).max()) if np.abs(x).max() > 3e4 or np.abs(x).max() < 30 else 1.0
        return x * s
    normals = [windows(load(p), a.window) for p in a.normal]
    comm = []; held = []
    for W in normals: k = int(0.6 * len(W)); comm += W[:k]; held += W[k:]
    F = []; Q = []; R = []
    for w in comm: v, q, r = feat(w, 32767); F.append(v); Q.append(q); R.append(r)
    res = {}
    for fpath in a.fault:
        mon = xb.Monitor(dims=len(F[0]), classes=1, ppc=4); rc, rep = mon.commission(np.array(F), np.array(Q)); assert rc == 0, "commissioning failed rc=%d" % rc
        thr = 1.25 * max(R)
        def run(ws):
            st = []; rr = 0
            for w in ws:
                v, q, r = feat(w, 32767); o = mon.update(v, q); rr = rr + 1 if r > thr else 0; st.append((o["status"] >= 3, rr >= 3))
            return np.array(st)
        h = run(held); fw = windows(load(fpath), a.window); s = run(fw)
        def lat(col): idx = np.where(s[:, col])[0]; return int(idx[0]) if len(idx) else None
        res[fpath] = dict(modes_found=rep[2], held_out_normal_windows=len(h), false_alert_rate_xsf=float(h[:, 0].mean()), false_alert_rate_rms=float(h[:, 1].mean()),
                          fault_windows=len(fw), alert_rate_xsf=float(s[:, 0].mean()), alert_rate_rms=float(s[:, 1].mean()), latency_xsf=lat(0), latency_rms=lat(1))
        print(fpath, json.dumps(res[fpath]))
    return res
if __name__ == "__main__": main()
