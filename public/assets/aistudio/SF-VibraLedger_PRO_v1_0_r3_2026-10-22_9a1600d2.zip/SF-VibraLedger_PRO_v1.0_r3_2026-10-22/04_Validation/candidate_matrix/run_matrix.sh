#!/bin/bash
# Candidate-lineage matrix: compile (strict) + run each tests set; record pass/fail
S=/home/claude/src
out=results.tsv; : > $out
try() { # name dir cflags tests... -- srcs...
  local name="$1"; local dir="$2"; shift 2
  local tests=(); local srcs=(); local mode=t
  for a in "$@"; do if [ "$a" = "--" ]; then mode=s; continue; fi; if [ $mode = t ]; then tests+=("$a"); else srcs+=("$a"); fi; done
  for t in "${tests[@]}"; do
    bin=/tmp/m_$$_$RANDOM
    if (cd "$dir" && gcc -std=c11 -Wall -Wextra -O2 "${srcs[@]}" "$t" -o $bin -lm 2>/tmp/cc_err.txt); then
      if (cd "$dir" && timeout 120 $bin >/tmp/run_out.txt 2>&1); then r=PASS; else r="FAIL(exit)"; fi
      warn=$(grep -c warning /tmp/cc_err.txt)
    else r="BUILD_FAIL"; warn=NA; fi
    echo -e "$name\t$t\t$r\twarnings=$warn\t$(tail -1 /tmp/run_out.txt | cut -c1-90)" | tee -a $out
    rm -f $bin
  done
}
# A: X-SFense FINAL MASTER
A=/home/claude/work/base/Core
try "A_XSFense_FINAL" $A test_xsfense_final.c -- XSFense_Core.c XSFense_Wire.c XSFense_XCal.c
try "A_XSFense_FINAL" /home/claude/work/base/Validation/tests final_security_functional_audit.c -- ../../Core/XSFense_Core.c ../../Core/XSFense_Wire.c ../../Core/XSFense_XCal.c
# B: SFense consolidated main (branch C)
M=$S/SFense_FINAL_CONSOLIDATED_2026-09-17__1__1/SFense_FINAL_CONSOLIDATED/Core/Main
try "B_SFense_Main" $M SFense_Unit_Tests.c SFense_Adversarial_Audit.c SFense_Rollback_Tests.c SFense_V2_Additions_Tests.c -- SFense_Core.c SFense_Wire.c SFense_XCal.c
# C: SFBrain Trust Ledger fork
F=$S/SFense_FINAL_CONSOLIDATED_2026-09-17__1__1/SFense_FINAL_CONSOLIDATED/Core/Alternate_Forks/2_TrustLedger_AuditLog_from_SFBrain
try "C_SFBrain_TL_V2" $F SFBrain_Core_V2_TrustLedger_Unit_Tests.c -- SFBrain_Core_V2_TrustLedger.c
try "C_SFBrain_AuditLog" $F SFBrain_AuditLog_Unit_Tests.c -- SFBrain_AuditLog.c
try "C_SFBrain_V1" $F SFBrain_Core_V1_Unit_Tests.c SFBrain_Core_V1_Adversarial_Audit.c -- SFBrain_Core_V1.c SFBrain_Wire.c SFBrain_XCal.c
# D: stage-token coupling (B)
G=$S/SFense_FINAL_CONSOLIDATED_2026-09-17__1__1/SFense_FINAL_CONSOLIDATED/Core/Alternate_Forks/1_StageTokenCoupling_from_B
try "D_StageTokenCoupling" $G SF_Universal_AI_V.FINAL_Unit_Tests.c SF_Universal_AI_V.FINAL_Adversarial_Audit.c -- SF_Universal_AI_V.FINAL.c SF2_Wire_V.FINAL.c SF2_XCal_V.FINAL.c
# E: seed prototype (E)
H=$S/SFense_FINAL_CONSOLIDATED_2026-09-17__1__1/SFense_FINAL_CONSOLIDATED/Core/Alternate_Forks/3_SeedPrototype_from_SFense_E
try "E_SeedPrototype" $H SFense_V.FINAL_Unit_Tests.c SFense_V.FINAL_Adversarial_Audit.c -- SFense_V.FINAL.c SF2_Wire_V.FINAL.c SF2_XCal_V.FINAL.c
# F: V2.1.1 patched + V2.1
P=$S/SF_Universal_AI_Complete_Project__1_/Code/V2.1.1_Patched
try "F_V2.1.1_Patched" $P test_v2_1.c overflow_test.c -- SF_Universal_AI_v2_1.c SF2_Wire_v2.c SF2_XCal.c
Q=$S/SF_Universal_AI_V2_1_Upgrade_Package/Code
try "G_V2.1_original" $Q test_v2_1.c -- SF_Universal_AI_v2_1.c SF2_Wire_v2.c SF2_XCal.c
# H: V1 legacy
L=$S/SF_Universal_AI_Complete_Package-1/Code
try "H_V1_legacy" $L test_wire.c test_sha256.c test_transport.c -- SF_Universal_AI.c SF_Wire.c
