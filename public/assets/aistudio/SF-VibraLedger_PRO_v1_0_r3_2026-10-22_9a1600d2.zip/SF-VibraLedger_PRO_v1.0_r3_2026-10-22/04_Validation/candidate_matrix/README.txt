Provenance record. results.tsv = compile (gcc -std=c11 -Wall -Wextra -O2, 0 warnings) + run of all 20 test programs of the 8 code lineages found in the 13 uploaded archives, executed 2026-09-19.
run_matrix.sh contains absolute paths of the analysis sandbox (the uploaded archives are not part of this package), so it documents the method but cannot be re-run here.
