# Evaluator Guide — running SF-VibraLedger on your own recordings

`sfvibraledger_eval` is a **local, read-only** command-line tool. It reads your CSV, prints a summary and (optionally) writes one CSV row per window and the audit log. Nothing is sent anywhere.

## 1. Input
* CSV, one row per sample, one column per sensor channel (optionally a leading time column: `--skip-cols 1`). A header line is skipped automatically. Numbers may be raw ADC counts, g or mm/s — only ratios matter, but use one consistent unit.
* Sampling rate `--fs` in Hz. Window `--window` (default 2048 samples; 16…4096). Use windows that contain several shaft revolutions.
* At most 16 model dimensions: `channels × (3 + number of tone frequencies)`. Example: 3 channels × (3 + 2 tones) = 15.
* `--freqs f1,f2` (optional, up to 4): tone frequencies to track, typically 1× and 2× shaft speed in Hz (rpm/60). Without it only RMS, crest factor and kurtosis are used.

## 2. Commissioning segment
`--calib-windows N` = the first N windows (**time-ordered**) are taken as HEALTHY reference. They must contain **every operating mode that should count as normal** (e.g. all load levels), for a few tens of windows each; at least 30 good-quality windows in total. Hint: 30 windows per mode is comfortable.

## 3. Run
```
07_Source/sfvibraledger_eval --input rec.csv --fs 10240 --calib-windows 90 --freqs 24.67,49.33 --skip-cols 1 \
                       --out result.csv --audit audit.txt
```
Add `--no-adapt` to see the behaviour without any adaptation. Try both on the same file — the difference is the honest picture of what adaptation does for you.

## 4. Reading the result
| Status | Meaning |
|---|---|
| HEALTHY | inside the boundary of a learned mode |
| WATCH | near the boundary, or a first out-of-boundary window |
| WARNING | ≥ 3 consecutive windows outside every learned mode |
| ALARM | ≥ 3 consecutive windows far outside (deviation ratio > 2) |
| TRANSIENT | signal-integrity problem (flat-line, clipping, drop-out): nothing is judged or learned |
| DRIFT_LIMIT | cumulative adaptation reached its envelope: a human should look and re-commission |

`deviation_q` is distance / boundary × 1024 (1024 = on the boundary). `audit.txt` lists adaptation checkpoints and escalations; the tool verifies the hash chain and prints OK/FAILED.

## 5. What a fair evaluation looks like
* Use a recording with a **known** event and a healthy stretch that you labelled independently.
* Report false alerts in the healthy stretch and latency to the event; compare with your current alarm level on the same data.
* Do **not** conclude anything about other machine classes from one recording.

## 6. Limits you should know
See `04_Validation/KNOWN_LIMITATIONS.md`: impulsive bearing faults need envelope features (not implemented); very slow faults can be absorbed by adaptation; a rarely visited operating mode can raise a false WARNING after long benign drift.
