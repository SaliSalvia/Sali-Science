# Commissioning Guide

1. **Record healthy data in every normal mode**, in time order, e.g. 30+ windows at each load level, with the machine warmed up. Keep the raw file.
2. **Check quality:** no clipping, no dropped samples (the tool reports TRANSIENT windows; they are excluded from commissioning).
3. **Choose tones:** 1× and 2× shaft speed (rpm/60 Hz) are a good start; more tones use more dimensions (max 16 in total).
4. **Run** `sfvibraledger_eval` with `--calib-windows` covering exactly the healthy segment. The console shows how many operating modes were found: it should equal the number of load/speed regimes you recorded. If it does not, the modes are too similar (fine) or the segment is not time-ordered (fix).
5. **Set the drift envelope by policy.** Default 2 commissioned radii. Smaller = flags slow change earlier but tolerates less benign drift; larger = the opposite. Decide from a few weeks of recordings of the same asset class, not from this package.
6. **Re-commission** after maintenance, sensor replacement, or any DRIFT_LIMIT that a human judges benign.
7. **Never** commission on data that may already contain a developing fault.
