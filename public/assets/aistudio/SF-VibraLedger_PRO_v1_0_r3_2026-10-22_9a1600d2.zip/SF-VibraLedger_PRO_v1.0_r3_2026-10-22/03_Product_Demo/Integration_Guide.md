# Integration Guide (microcontroller / PLC / gateway)

**Status: host-tested, plus one hardware validation.** The embedded subset compiles as strict C99 (`-Wpedantic -Werror`) and needs no libm and no heap. It has been built with arm-none-eabi-gcc and run on one real microcontroller (STM32F103 / Cortex-M3, FIT IoT-LAB `m3` node, RIOT) where its decisions, integer feature extraction and audit chain were bit-identical to the host — see `04_Validation/HARDWARE_VALIDATION_M3.md`. Other targets are untested: expect to measure cycles and RAM on yours.

## Files
`07_Source/Core` (model, classifier, wire, calibration, SHA-256/HMAC header), `Audit` (hash-chained log), `Features`, `Monitor`. **Host only:** `Host/` (commissioning, CLI, Python shim) and `Tests/`.

## Runtime sequence
1. `SFVLM_Init(&mon, dims, 1, 4, NULL, key, key_len)`; then load a commissioned model into `mon.model` (produced on a host by `SFVLC_Commission`, exported with `SFVL_WireSerialize`, imported on the device with `SFVL_WireStageToStore` and the shared key) and call `SFVLM_Arm(&mon)`.
2. Per window: fill `SFVLF_Config` once (`full_scale`, tone coefficients Q22 = 2·cos(2πf/fs)·2²², `min_rms`); call `SFVLF_Extract` for each channel, `SFVLF_ToModelVector` to obtain the log-domain features, take the minimum `quality_q` over channels, then `SFVLM_Update(&mon, vec, quality, &out)`.
3. Act on `out.status` (see Evaluator Guide). `out.health_q`, `out.deviation_q`, `out.drift_q` are available for trending.
4. Export the audit ring occasionally (`SFVLAL_ExportLine` uses `snprintf`; the hash chain itself does not) and verify with `SFVLAL_Verify`.

## Memory (host x86-64 measurement)
`sizeof(SFVLM_Monitor)` = 8112 B (model 5616 B + 32-entry audit ring + supervision); code ≈ 18 kB with `-Os` (core 4.9, wire 4.7, audit 3.4, monitor 2.3, features 1.6, calibration 1.2). Reduce with `-DSFVLAL_CAPACITY=8` and by dropping Wire if you never update remotely. Cortex-M3 (measured, FIT IoT-LAB `m3`, 72 MHz): `sizeof(SFVLM_Monitor)` = 8104 B (8112 B on x86-64), `SFVL_WireStore` 11240 B, `SFVLAL_Log` 2128 B, wire blob 5558 B; median cycles `SFVLM_Update` 43,059 (88,071 when an audit entry is appended — HMAC-SHA256), `SFVLF_Extract` 789,273 per 2048-sample channel window, `SFVL_WireStageToStore` 911,757. See the measurement conditions and caveats in `HARDWARE_VALIDATION_M3.md`; other MCUs: **not measured**.

## Things you must decide
* **Stack:** `SFVL_WireStageToStore` keeps a whole `SFVL_Model` (~5.6 KB) on the stack (≈ 6.5 KB deep with HMAC). On the first silicon run, RIOT's default ~2 KB main-thread stack overflowed and HardFaulted at the first *successful* stage (rejected blobs return before touching that frame, so they pass). Budget **≥ 8 KB of stack for the thread that calls it** (observed worst case in the test firmware: 7,108 B used of 12,288 B). Staging directly into the inactive slot would remove this requirement (not done; the shipped code is unchanged).
* **Key management:** the HMAC key is supplied by you (storage, provisioning, rotation are out of scope).
* **Time base:** one `SFVLM_Update` = one epoch; trust decay is per epoch, so the window rate defines how fast trust decays.
* **Endianness:** the wire format is field-wise explicit; the audit chain hashes native-endian fields and is therefore per-device.
* **Persistence:** store `mon.model` (through the two-slot wire store) after DRIFT_LIMIT or at intervals if you want adaptation to survive reboots.
* **Commissioning is a host step.** Re-commissioning after a DRIFT_LIMIT is a deliberate human action by design.

## Porting checklist
Build with your toolchain at `-Os`; run `07_Source/Tests` on a host first; run `test_features` against your ADC scaling; measure worst-case `SFVLM_Update` and `SFVLF_Extract` cycles for your window length; test power-loss during model activation.
