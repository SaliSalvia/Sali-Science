# Manifest — SF-VibraLedger PRO v1.0 FINAL (2026-09-19), revision r3 (2026-10-22)

**r3 (2026-10-22) corrects the run history in `HARDWARE_VALIDATION_M3.md` (6 checks passed before the first HardFault, not 5; adds the run of the release ELF) and records the evidence archive (`hardware_m3/EVIDENCE_ARCHIVE_RECORD_2026-10-22.md`). r2 changes (documentation and evidence only):** adds `04_Validation/HARDWARE_VALIDATION_M3.md` and `04_Validation/hardware_m3/` (on-target test firmware, scripts, evidence excerpts); updates the status statements in `KNOWN_LIMITATIONS.md` (both copies), `README_EN/FA.md`, `Integration_Guide.md` and this manifest. **`07_Source` and every other file are byte-identical to r1.** Narrative reports (docx/pdf), the marketing PDFs and the patent documents were NOT edited: see the list in `HARDWARE_VALIDATION_M3.md` section 8.

| Folder | Contents |
|---|---|
| 00_START_HERE | README (EN/FA), **Decision_Report_FA** (which version is best, findings, revenue path, to-do), KNOWN_LIMITATIONS |
| 01_Patent | Patent_Application_FULL_FA (IRIPO-style, Persian), Patent_Specification_FULL_EN, Claim_Support_Matrix, Prior_Art_and_Risk_Assessment, Filing_Disclosure_Publication_Sequence, IRIPO_UPLOAD_CHECKLIST, Drawings/FIG1-5, Carried_Over/ (older files, reference only) |
| 02_Paper_Q1 | Manuscript_EN (docx/pdf), Submission_Kit.md (highlights, cover letter, journals, real-data requirement, checklist), figures/ |
| 03_Product_Demo | Evaluator_Guide, Integration_Guide, Commissioning_Guide, Demo_Report.html, sample_data (SIMULATED), outputs, bin (prebuilt Linux x86-64 evaluator) |
| 04_Validation | **HARDWARE_VALIDATION_M3.md** (r3: on-target validation record), **hardware_m3/** (r3: test firmware, scripts, evidence record), run_all_validation.sh (dry-run default, --apply to execute), harness/ (Python, ctypes to the real C library), tools/ (mat_to_csv, cwru_experiment), logs/, results/ (JSON + SHA256), candidate_matrix/, Test_Evidence_Report_EN, Test_Evidence_Summary_FA, BUGFIX_REPORT, KNOWN_LIMITATIONS |
| 05_Marketing | OnePager_EN/FA (A4), Poster_EN/FA (A2), Marketing_Rules |
| 06_Commercial_Legal | Pilot_Offer_and_30_Day_Plan, Carried_Over_Templates/ (NDA, trial agreement, EULA — not legally reviewed) |
| 07_Source | Core (model, wire, calibration), Audit, Features, Monitor, Host (commissioning, CLI, Python shim), Tests, Makefile |
| SHA256SUMS.txt | checksum of every file in this package (verify with `sha256sum -c SHA256SUMS.txt`) |

Data origin labels used everywhere: SIMULATED (physics-informed generator), PUBLIC DATA (scikit-learn bundled, non-industrial, drift/poison injected), MEASURED ON HOST (x86-64), MEASURED ON TARGET (one Cortex-M3, r2). Nothing was measured on a physical machine (industrial equipment).
