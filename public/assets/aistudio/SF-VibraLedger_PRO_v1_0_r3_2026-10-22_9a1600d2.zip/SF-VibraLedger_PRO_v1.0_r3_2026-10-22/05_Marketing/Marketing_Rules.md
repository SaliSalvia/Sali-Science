# Marketing rules for this package
1. Do not distribute any marketing material before the priority application is filed unless the recipient is under NDA; the one-page sheet and poster describe the mechanisms at a high level.
2. Add "Patent pending" only after filing (and only if true).
3. Fill the contact placeholders [e-mail] / [phone] in the PDFs (edit in your own tool or ask for a regenerated PDF).
4. Keep the SIMULATED / PUBLIC DATA labels on every chart. Do not crop them.
5. Do not add: ROI, downtime reduction, "AI-powered predictive maintenance guaranteed", certifications, or accuracy figures for real machines.
6. Search the trademark register for "SF-VibraLedger" before printing the poster.
