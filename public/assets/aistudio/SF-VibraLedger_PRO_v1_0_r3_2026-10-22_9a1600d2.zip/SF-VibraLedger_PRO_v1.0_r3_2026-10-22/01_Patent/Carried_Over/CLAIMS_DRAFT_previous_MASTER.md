# X-SFense — Claims Draft for Counsel Review

## Claim 1 — method
A method performed by an embedded industrial computing device for adaptive classification of streaming sensor-derived feature vectors, comprising: maintaining a bounded plurality of reference prototypes; determining a classification result and distance-related evidence for an incoming feature vector; maintaining, for each reference prototype, a bounded trust value associated with an epoch value; decaying the trust value as a function of elapsed processing epochs; determining whether a plurality of independent evidence conditions are satisfied; generating an adaptation authorization token only when the plurality of evidence conditions and a minimum trust condition are satisfied; binding the token to a current model generation and a fingerprint of the incoming feature vector; receiving or otherwise obtaining a validated feature vector; verifying the token, model generation, fingerprint, sensor-quality condition and a current trust condition; and updating the selected reference prototype only after the verification succeeds.

## Claim 2
The method of claim 1, wherein the independent evidence conditions include temporal consistency, classification margin, threshold slack and sensor quality.

## Claim 3
The method of claim 1, wherein successful adaptation reduces the trust value by an adaptation cost while accepted non-adaptation confirmations can increase the trust value subject to a bounded maximum.

## Claim 4
The method of claim 1, wherein trust decay is calculated in constant time from the current epoch, a stored trust epoch and a configured decay amount.

## Claim 5
The method of claim 1, further comprising storing rejected or unrecognized feature vectors in a bounded unknown-state prototype pool and promoting an unknown-state prototype only after a configured maturity count.

## Claim 6
The method of claim 1, further comprising receiving a commissioning-time trusted prototype seed containing a class, prototype slot, center, radius and initial hit count.

## Claim 7
The method of claim 1, further comprising serializing model state into a versioned representation, authenticating the representation with HMAC-SHA256, rejecting an authenticated state whose model generation is not greater than the active model generation, and performing model self-test before activation.

## Claim 8
The method of claim 1, wherein the processing uses fixed-point arithmetic and statically bounded memory and does not require continuous storage of raw sensor samples.

## Claim 9 — device
An embedded industrial monitoring device comprising a processor, memory storing bounded prototype state and executable instructions configured to perform the method of any preceding claim.

## Claim 10 — system
An industrial condition-monitoring system comprising one or more sensors, an edge computing device configured to perform the method of any preceding claim, and an output interface configured to provide an anomaly, health or maintenance-relevant decision.

**Counsel review required before filing.**
