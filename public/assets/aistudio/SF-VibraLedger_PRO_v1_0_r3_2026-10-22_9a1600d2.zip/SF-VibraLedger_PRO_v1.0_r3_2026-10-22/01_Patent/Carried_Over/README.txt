Files carried over UNCHANGED from the previous master package (XSFense_FINAL_MASTER, 2026-09-18) for reference.
They describe the OLDER, thinner application (no Trust Ledger, ~350 Persian words). Do NOT file them; file the documents in ../ instead.
OFFICIAL_FILING_REQUIREMENTS_2026.md was written earlier and must be re-verified against the current official portal (fees, formats, forms).
