# Official filing requirements checked 2026-09-18

This project package is a technical filing-preparation package, not legal advice and not a guarantee of patentability.

WIPO PCT: request, description, claim(s), drawings where necessary, and abstract. The description must disclose the invention clearly and completely enough for a skilled person to carry it out. The abstract should be concise and technical.

EPO 2026: application documents include request, description, claims, drawings where referred to/needed, and abstract. For DOCX filing, the application body can be a single document containing description, claims, abstract and drawings where applicable, with the prescribed headings.

Official sources checked:
- WIPO PCT Applicant's Guide (valid April 23, 2026)
- WIPO PCT Rules 5, 8, 11
- EPO Guidelines 2026, Part F and DOCX filing notice

The actual receiving-office forms, applicant/inventor particulars, signatures, fees, priority data and representation requirements must be completed by the applicant/attorney at filing time.
