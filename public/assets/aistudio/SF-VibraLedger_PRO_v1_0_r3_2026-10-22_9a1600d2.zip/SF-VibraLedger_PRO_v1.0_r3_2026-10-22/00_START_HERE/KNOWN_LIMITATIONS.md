---
title: "Known Limitations and Claims Boundary"
subtitle: "Read before quoting any number from this package"
---

## What is proven, what is not

| Statement | Status |
|---|---|
| The C code builds warning-free (C11 and C99 pedantic for the embedded subset) and every test passes natively and under ASan+UBSan | **Measured** (04_Validation/logs) |
| Results are deterministic (same seeds ⇒ identical benchmark output) | **Measured** |
| Feature extractor agrees with float64 numpy (RMS 0.2 %, kurtosis 0.3 %, tone 0.9 % max error, 300 windows) | **Measured** |
| Detection / false-alert numbers in the vibration benchmark | **Simulated data** (physics-informed generator, not machine recordings) |
| Accuracy numbers on wine / breast-cancer / digits | **Real public data, non-industrial**, with injected drift/poisoning (semi-synthetic) |
| Performance on real machines, downtime reduction, ROI | **NOT MEASURED** |
| Behaviour of the embedded subset on a microcontroller | **MEASURED ON TARGET, one platform**: FIT IoT-LAB `m3` node (STM32F103, Cortex-M3, 72 MHz), RIOT 2026.10-devel, arm-none-eabi-gcc 9.3.1. 28 on-device checks pass: decisions, integer feature extraction, audit chain and wire-format rejection are bit-identical to the host (04_Validation/HARDWARE_VALIDATION_M3.md) |
| Timing / memory on that Cortex-M3 | **MEASURED ON TARGET** (cycle counter, clock confirmed against an independent timer to 0.15 %): `SFVLM_Update` 597 µs median (1,221 µs when an audit entry is appended), `SFVLF_Extract` 10.9 ms per 2048-sample channel window, ≈ 16.7 % of one core for a 200 ms window with 3 channels; `sizeof(SFVLM_Monitor)` = 8104 B on ARM. Needs ≥ 8 KB of stack for the caller of `SFVL_WireStageToStore` |
| Any other microcontroller, real sensor/ADC input, power loss during model activation, long-duration soak on target | **NOT MEASURED** |
| Security of key handling | **Out of scope**: keys are supplied by the integrator |

## Technical limitations found by the benchmarks

1. **Impulsive bearing faults** are detected no earlier than a simple z-score baseline (median severity 0.66 vs 0.67); an RMS alarm level misses them completely. Envelope-spectrum (demodulation) features would be needed; not implemented.
2. **Adaptation delays detection of very slow faults** (imbalance ramp over 1000 windows: flagged at severity 0.10 with adaptation vs 0.036 without). The cumulative-drift envelope (default 2 commissioned radii) is a policy parameter that can only be set correctly from real recordings of the asset class.
3. **Stale operating modes:** a mode not visited for a long time while a benign gain drift accumulates can raise a false WARNING when it is revisited (benign runs with ≥ 1 false episode: 20 % of 1400-window runs; 0.3 % of windows).
4. **Evidence gate and Trust Ledger do not filter poisoned samples** that lie inside a prototype's boundary (≈ 22–25 % of updates were caused by injected samples at a 20 % injection rate). They rate-limit updates (1.2–2.6× fewer). **Unrestricted multi-class self-training is unsafe** (breast-cancer accuracy 0.89 → 0.55). The Monitor therefore adapts only healthy-class prototypes and only under the drift envelope.
5. In the simulated benchmark, ungated adaptation had *fewer* false alerts than gated adaptation and identical detection latency; the value of the gate/ledger in this package is bounded, auditable adaptation, **not** better detection.
6. Commissioning requires time-ordered healthy windows containing every operating mode that must count as normal, and ≥ 30 good-quality windows.
7. Up to 16 model dimensions, 8 classes, 4 prototypes/class (compile-time).
8. `sfvibraledger_eval` handles windows of 16…4096 samples; sample magnitudes must be below 2³⁰.

## Marketing rule

Every performance sentence must carry its data origin (SIMULATED / PUBLIC DATA / MEASURED ON HOST / MEASURED ON TARGET, naming the platform). Do not write "reduces downtime", "certified", "ISO-compliant", "AI-powered predictive maintenance guaranteed" or any ROI figure until independently measured on the customer's equipment.
