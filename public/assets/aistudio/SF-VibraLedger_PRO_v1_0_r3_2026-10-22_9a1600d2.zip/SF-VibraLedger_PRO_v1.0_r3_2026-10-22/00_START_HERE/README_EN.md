# SF-VibraLedger PRO v1.0 — Final package (2026-09-19)

Deterministic, integer-only edge condition-monitoring stack: window features → multi-mode reference model → evidence-gated, trust-budgeted adaptation → cumulative-drift supervision → tamper-evident audit log, with an authenticated model lifecycle.

**Every performance number in this package carries its data origin (SIMULATED / PUBLIC DATA / MEASURED ON HOST / MEASURED ON TARGET). Nothing has been measured on a physical machine (industrial equipment). The embedded subset has been run and timed on one real microcontroller, a Cortex-M3 — see `04_Validation/HARDWARE_VALIDATION_M3.md` (revision r3).** Read `04_Validation/KNOWN_LIMITATIONS.md` before quoting any number.

## Start here
1. `00_START_HERE/Decision_Report_FA.pdf` — which of the 13 uploaded versions is best, what was found and fixed, the honest revenue path, what only you can do (Persian).
2. `04_Validation/Test_Evidence_Report_EN.pdf` — what was actually run, with results.
3. `01_Patent/` — full specification (EN, FA), claims, claim-support matrix, prior-art risk, filing sequence, drawings. **File before you disclose anything** (manuscript, source, demo binaries).
4. `02_Paper_Q1/` — manuscript draft + submission kit (needs real-data results first; harness provided).
5. `03_Product_Demo/` — evaluator guide, simulated sample data, outputs, prebuilt Linux binary, integration and commissioning guides.
6. `05_Marketing/` — one-page sheet and A2 poster, English and Persian. `06_Commercial_Legal/` — pilot offer, 30-day plan, carried-over NDA / trial / licence templates (not re-reviewed).
7. `07_Source/` — C sources (Core, Audit, Features, Monitor, Host, Tests, Makefile).

## Verify (Linux, gcc, python3 + numpy + scikit-learn + scipy; no network)
```
cd 04_Validation
./run_all_validation.sh            # DRY RUN (default): prints the plan, changes nothing
./run_all_validation.sh --apply    # builds, runs every test natively + under ASan/UBSan, benchmarks, writes logs/ and results/
```
Evaluate your own recording (`make -C 07_Source` builds the tool; a Linux x86-64 binary is in `03_Product_Demo/bin/`):
```
07_Source/sfvibraledger_eval --input your.csv --fs 10240 --calib-windows 90 --freqs 24.7,49.4 --skip-cols 1 --out result.csv
```
Integrity: `SHA256SUMS.txt` in the package root.

## Marketing rule
"Patent pending" may be printed only after the application is filed. Every performance sentence must state SIMULATED / PUBLIC DATA / MEASURED ON HOST.
